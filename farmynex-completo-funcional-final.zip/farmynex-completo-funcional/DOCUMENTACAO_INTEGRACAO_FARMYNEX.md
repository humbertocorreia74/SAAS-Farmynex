# Documentação Completa - Integração Farmynex

**Versão:** 1.0.0  
**Data:** 9 de dezembro de 2024  
**Autor:** Manus AI  

## Sumário Executivo

Este documento apresenta a implementação completa da integração do aplicativo Farmynex com planos de assinatura Stripe e módulos de integrações externas com órgãos governamentais brasileiros. O projeto inclui um painel React para gerenciamento de planos, APIs móveis otimizadas e integrações com ANVISA, SNGPC/SNCM, Receita Federal, CNES, Procon, SERASA, SEFAZ e OpenHealth/SBIS.

A solução desenvolvida oferece uma arquitetura robusta e escalável, permitindo que farmácias e redes farmacêuticas tenham acesso a um sistema completo de gestão com conformidade regulatória e integração financeira moderna.

## Índice

1. [Visão Geral da Arquitetura](#visão-geral-da-arquitetura)
2. [Integração com Stripe](#integração-com-stripe)
3. [Painel React de Gerenciamento](#painel-react-de-gerenciamento)
4. [Integrações Governamentais](#integrações-governamentais)
5. [Módulo Mobile](#módulo-mobile)
6. [Configuração e Instalação](#configuração-e-instalação)
7. [Endpoints da API](#endpoints-da-api)
8. [Exemplos de Uso](#exemplos-de-uso)
9. [Segurança e Conformidade](#segurança-e-conformidade)
10. [Monitoramento e Logs](#monitoramento-e-logs)
11. [Troubleshooting](#troubleshooting)
12. [Roadmap e Próximos Passos](#roadmap-e-próximos-passos)

## Visão Geral da Arquitetura

### Componentes Principais

A arquitetura do Farmynex integrado é composta por quatro camadas principais que trabalham em conjunto para fornecer uma solução completa e escalável para o setor farmacêutico brasileiro.

**Backend NestJS:** O núcleo da aplicação utiliza o framework NestJS, proporcionando uma arquitetura modular e type-safe. O backend gerencia toda a lógica de negócio, autenticação, autorização e comunicação com serviços externos. A escolha do NestJS permite uma estrutura bem organizada com decorators, dependency injection e suporte nativo ao TypeScript, facilitando a manutenção e evolução do código.

**Frontend React:** O painel administrativo foi desenvolvido em React com Tailwind CSS, oferecendo uma interface moderna e responsiva para gerenciamento de planos de assinatura. O painel permite visualização de métricas, gestão de usuários, configuração de planos e monitoramento de integrações em tempo real.

**APIs Móveis:** Um conjunto especializado de endpoints otimizados para aplicações móveis, incluindo autenticação por dispositivo, sincronização offline e push notifications. As APIs móveis foram projetadas considerando limitações de conectividade e necessidades específicas de aplicativos farmacêuticos em campo.

**Integrações Externas:** Módulos especializados para comunicação com órgãos reguladores e serviços governamentais brasileiros, garantindo conformidade legal e acesso a dados oficiais necessários para operação farmacêutica.

### Tecnologias Utilizadas

O stack tecnológico foi cuidadosamente selecionado para garantir performance, escalabilidade e facilidade de manutenção:

- **Backend:** NestJS 10.x com TypeScript, TypeORM para ORM, Passport.js para autenticação
- **Frontend:** React 18.x, Tailwind CSS 3.x, Vite para build otimizado
- **Banco de Dados:** SQLite para desenvolvimento, PostgreSQL recomendado para produção
- **Pagamentos:** Stripe API v2025-06-30.basil com suporte a PIX e boleto
- **Autenticação:** JWT com refresh tokens e sessões por dispositivo
- **Documentação:** Swagger/OpenAPI 3.0 para documentação automática da API

### Padrões Arquiteturais

A aplicação segue padrões estabelecidos da indústria para garantir qualidade e manutenibilidade:

**Domain-Driven Design (DDD):** Cada módulo representa um domínio específico do negócio farmacêutico, com boundaries bem definidos e responsabilidades claras.

**Repository Pattern:** Abstração da camada de dados através de repositories, facilitando testes e mudanças de banco de dados.

**Service Layer:** Lógica de negócio encapsulada em services especializados, promovendo reutilização e testabilidade.

**Event-Driven Architecture:** Comunicação assíncrona entre módulos através de eventos, permitindo baixo acoplamento e alta coesão.




## Integração com Stripe

### Configuração dos Planos de Assinatura

A integração com o Stripe foi implementada para suportar múltiplos planos de assinatura, atendendo diferentes perfis de farmácias e redes farmacêuticas. O sistema oferece flexibilidade tanto para assinaturas mensais quanto anuais, com descontos progressivos para contratos de longo prazo.

**Planos Disponíveis:**

O sistema oferece três categorias principais de planos, cada uma com variações mensais e anuais:

**Plano Básico (R$ 29,99/mês):** Desenvolvido especificamente para farmácias pequenas e independentes que estão iniciando sua jornada digital. Este plano inclui funcionalidades essenciais como gestão básica de estoque, sistema de vendas simplificado, relatórios fundamentais e suporte via email. É ideal para estabelecimentos com até 50 produtos cadastrados e volume de vendas de até 100 transações mensais.

**Plano Profissional (R$ 59,99/mês):** Direcionado para farmácias em crescimento que necessitam de funcionalidades mais avançadas. Inclui gestão completa de estoque com alertas automáticos, sistema de vendas avançado com múltiplas formas de pagamento, relatórios detalhados com análises de tendências, integração com fornecedores para reposição automática e suporte prioritário. Suporta até 500 produtos e 1000 transações mensais.

**Plano Empresarial (R$ 99,99/mês):** Projetado para redes de farmácias e grandes estabelecimentos que requerem funcionalidades corporativas. Oferece gestão multi-loja com sincronização em tempo real, analytics avançados com dashboards executivos, API completa para integrações personalizadas, módulos de integrações com sistemas externos, suporte 24/7 e treinamento especializado incluído.

**Vantagens dos Planos Anuais:**

Todos os planos oferecem desconto significativo para assinaturas anuais, equivalente a dois meses gratuitos. Esta estratégia incentiva a fidelização de clientes e proporciona previsibilidade de receita para o negócio.

### Implementação Técnica

A implementação da integração Stripe segue as melhores práticas de segurança e usabilidade, garantindo uma experiência fluida para os usuários finais.

**Checkout Sessions:** O sistema utiliza Stripe Checkout Sessions para processar pagamentos de forma segura. Cada sessão é criada dinamicamente com base no plano selecionado, incluindo metadados específicos para rastreamento e análise posterior. O checkout suporta múltiplos métodos de pagamento, incluindo cartões de crédito/débito e boleto bancário, atendendo às preferências do mercado brasileiro.

**Webhooks e Eventos:** A comunicação bidirecional com o Stripe é mantida através de webhooks configurados para capturar eventos críticos como conclusão de pagamento, falhas de cobrança, atualizações de assinatura e cancelamentos. Cada webhook é processado de forma assíncrona e inclui mecanismos de retry para garantir a entrega confiável de eventos.

**Gerenciamento de Assinaturas:** O sistema oferece funcionalidades completas para gerenciamento do ciclo de vida das assinaturas, incluindo upgrades e downgrades de planos com cálculo proporcional automático, pausas temporárias para casos especiais, cancelamentos com diferentes políticas de reembolso e reativações simplificadas.

**Portal do Cliente:** Integração com o Stripe Customer Portal permite que os usuários gerenciem suas próprias assinaturas, atualizem métodos de pagamento, visualizem histórico de faturas e façam alterações de planos sem necessidade de intervenção do suporte técnico.

### Segurança e Conformidade

A implementação segue rigorosamente os padrões de segurança PCI DSS, garantindo que dados sensíveis de pagamento nunca trafeguem pelos servidores da aplicação. Todas as transações são processadas diretamente nos servidores seguros do Stripe, mantendo a conformidade regulatória e reduzindo riscos de segurança.

**Criptografia e Tokens:** Utilização de tokens seguros para representar métodos de pagamento, eliminando a necessidade de armazenar dados de cartão. Todas as comunicações com a API Stripe são realizadas através de HTTPS com certificados SSL/TLS atualizados.

**Auditoria e Logs:** Sistema completo de auditoria que registra todas as transações, tentativas de pagamento, alterações de planos e eventos de webhook. Os logs são estruturados e incluem timestamps precisos, identificadores únicos e contexto suficiente para investigações futuras.

### Métricas e Analytics

O módulo Stripe inclui dashboards abrangentes para monitoramento de métricas financeiras e operacionais:

**Métricas de Receita:** Acompanhamento em tempo real de MRR (Monthly Recurring Revenue), ARR (Annual Recurring Revenue), churn rate, lifetime value dos clientes e taxa de conversão por plano.

**Análise de Comportamento:** Insights sobre preferências de planos, padrões de upgrade/downgrade, sazonalidade de assinaturas e efetividade de campanhas promocionais.

**Relatórios Financeiros:** Geração automática de relatórios financeiros compatíveis com sistemas contábeis brasileiros, incluindo discriminação de impostos e conformidade com legislação fiscal.


## Painel React de Gerenciamento

### Interface de Usuário Moderna

O painel de gerenciamento foi desenvolvido utilizando React 18 com Tailwind CSS, proporcionando uma experiência de usuário moderna, responsiva e intuitiva. A interface foi projetada seguindo princípios de design centrado no usuário, com foco na usabilidade e eficiência operacional.

**Design System Consistente:** Implementação de um design system robusto com componentes reutilizáveis, paleta de cores harmoniosa e tipografia otimizada para legibilidade. Todos os componentes seguem padrões de acessibilidade WCAG 2.1, garantindo usabilidade para usuários com diferentes necessidades.

**Responsividade Total:** O painel adapta-se perfeitamente a diferentes tamanhos de tela, desde smartphones até monitores ultrawide. A navegação é otimizada para touch em dispositivos móveis, mantendo a funcionalidade completa em todas as plataformas.

### Funcionalidades Principais

**Dashboard Executivo:** Visão consolidada de métricas críticas do negócio, incluindo receita recorrente, distribuição de planos, taxa de churn e crescimento mensal. Gráficos interativos permitem drill-down para análises detalhadas e identificação de tendências.

**Gerenciamento de Planos:** Interface intuitiva para visualização e comparação de todos os planos disponíveis. Administradores podem monitorar a popularidade de cada plano, analisar conversões e identificar oportunidades de otimização de preços.

**Gestão de Assinaturas:** Painel completo para gerenciamento do ciclo de vida das assinaturas, incluindo visualização de status, histórico de pagamentos, alterações de planos e comunicação com clientes. Funcionalidades de busca e filtros avançados facilitam a localização de assinaturas específicas.

**Análise de Faturamento:** Módulo dedicado para análise financeira com relatórios detalhados de receita, previsões de faturamento, análise de cohort e métricas de retenção. Exportação de dados em múltiplos formatos para integração com sistemas contábeis.

### Componentes Técnicos

**Gerenciamento de Estado:** Utilização do Context API do React para gerenciamento de estado global, proporcionando performance otimizada e facilidade de manutenção. Estados locais são gerenciados com hooks customizados para funcionalidades específicas.

**Comunicação com API:** Implementação de um cliente HTTP customizado com interceptors para autenticação automática, tratamento de erros padronizado e retry automático para requisições falhadas. Cache inteligente reduz chamadas desnecessárias à API.

**Otimização de Performance:** Lazy loading de componentes, memoização estratégica e code splitting automático garantem carregamento rápido e experiência fluida. Bundle size otimizado através de tree shaking e compressão avançada.

### Experiência do Usuário

**Navegação Intuitiva:** Menu lateral colapsível com ícones descritivos e organização lógica das funcionalidades. Breadcrumbs contextuais ajudam na orientação dentro do sistema.

**Feedback Visual:** Sistema abrangente de notificações, loading states e confirmações de ações. Animações sutis melhoram a percepção de responsividade sem comprometer a performance.

**Personalização:** Usuários podem personalizar dashboards, configurar alertas personalizados e definir preferências de visualização. Temas claro e escuro disponíveis para diferentes preferências de uso.

### Integração com Backend

**Autenticação Segura:** Implementação de JWT com refresh tokens automático, garantindo sessões seguras e experiência contínua. Logout automático em caso de inatividade prolongada.

**Sincronização em Tempo Real:** WebSockets para atualizações em tempo real de métricas críticas e notificações importantes. Fallback para polling em ambientes com restrições de conectividade.

**Tratamento de Erros:** Sistema robusto de tratamento de erros com mensagens contextuais e sugestões de ação. Retry automático para operações críticas e fallbacks graceful para funcionalidades secundárias.


## Integrações Governamentais

### ANVISA - Agência Nacional de Vigilância Sanitária

A integração com a ANVISA representa um dos pilares fundamentais para a conformidade regulatória do sistema Farmynex. Esta integração permite acesso em tempo real a informações oficiais sobre medicamentos, produtos para saúde e estabelecimentos farmacêuticos.

**Consulta de Produtos:** O sistema oferece funcionalidades abrangentes para consulta de produtos registrados na ANVISA, incluindo verificação de registro ativo, situação regulatória, composição, indicações terapêuticas e restrições de uso. A base de dados é sincronizada regularmente para garantir informações atualizadas.

**Verificação de Estabelecimentos:** Validação automática de licenças e autorizações de funcionamento de farmácias e drogarias. O sistema verifica se o estabelecimento possui autorização vigente para comercialização de medicamentos e produtos controlados.

**Alertas e Notificações:** Monitoramento contínuo de alertas sanitários, recalls de produtos e mudanças regulatórias que possam impactar o negócio. Notificações automáticas são enviadas quando produtos em estoque são afetados por alertas da ANVISA.

**Relatórios de Farmacovigilância:** Funcionalidades para geração e envio de relatórios de eventos adversos e queixas técnicas, conforme exigido pela legislação sanitária brasileira.

### SNGPC/SNCM - Sistema Nacional de Gerenciamento de Produtos Controlados

O módulo SNGPC/SNCM garante conformidade total com as exigências legais para comercialização de medicamentos controlados, proporcionando rastreabilidade completa e relatórios automáticos.

**Escrituração Digital:** Sistema automatizado para escrituração de medicamentos controlados, incluindo entradas, saídas, transferências e perdas. Todos os movimentos são registrados com timestamp preciso e identificação do responsável.

**Controle de Receituário:** Validação automática de receitas de medicamentos controlados, verificação de autenticidade, prazo de validade e conformidade com prescrições médicas. Integração com sistemas de prescrição eletrônica quando disponíveis.

**Relatórios Obrigatórios:** Geração automática de relatórios mensais e trimestrais exigidos pela ANVISA, incluindo mapas de movimento, inventários e declarações de estoque. Envio automático dentro dos prazos regulamentares.

**Auditoria e Rastreabilidade:** Sistema completo de auditoria que mantém histórico detalhado de todas as operações com medicamentos controlados, permitindo rastreabilidade completa desde a entrada até a dispensação final.

### Receita Federal - Validação e Conformidade Fiscal

A integração com a Receita Federal proporciona validação automática de dados fiscais e conformidade com obrigações tributárias, essencial para operação legal de estabelecimentos farmacêuticos.

**Validação de CNPJ:** Verificação automática da situação cadastral de fornecedores, clientes corporativos e parceiros comerciais. O sistema consulta dados atualizados sobre situação ativa, regularidade fiscal e atividades econômicas autorizadas.

**Verificação de CPF:** Validação de dados de clientes pessoa física, incluindo verificação de regularidade cadastral e situação junto à Receita Federal. Importante para vendas de medicamentos controlados e programas de fidelidade.

**Consulta de Débitos:** Verificação automática de débitos em aberto de fornecedores e parceiros, auxiliando na gestão de risco de crédito e tomada de decisões comerciais.

**Certidões Negativas:** Geração automática de certidões negativas de débitos quando necessário para participação em licitações ou contratos com órgãos públicos.

### CNES - Cadastro Nacional de Estabelecimentos de Saúde

O módulo CNES permite validação e consulta de informações sobre estabelecimentos de saúde, fundamental para vendas B2B e parcerias estratégicas.

**Validação de Estabelecimentos:** Verificação automática de hospitais, clínicas e unidades de saúde cadastradas no CNES, incluindo situação ativa, serviços oferecidos e responsáveis técnicos.

**Consulta de Profissionais:** Validação de vínculos profissionais de médicos, farmacêuticos e outros profissionais de saúde com estabelecimentos credenciados.

**Relatórios Regionais:** Geração de relatórios sobre densidade de estabelecimentos de saúde por região, auxiliando em análises de mercado e planejamento estratégico.

### SERASA - Análise de Crédito e Risco

A integração com o SERASA proporciona análise completa de risco de crédito para clientes pessoa física e jurídica, essencial para gestão financeira e comercial.

**Score de Crédito:** Consulta automática de score de crédito para clientes, permitindo definição de limites de crédito personalizados e políticas de pagamento diferenciadas.

**Análise de Risco:** Avaliação automática de risco para novos clientes, incluindo histórico de pagamentos, relacionamento bancário e comportamento financeiro.

**Monitoramento Contínuo:** Acompanhamento automático de mudanças no perfil de crédito de clientes importantes, com alertas para deterioração de score ou inclusão de restrições.

**Relatórios de Carteira:** Análise consolidada da carteira de clientes com distribuição de risco, identificação de clientes problemáticos e recomendações para gestão de crédito.

### SEFAZ - Notas Fiscais Eletrônicas

O módulo SEFAZ garante conformidade total com obrigações fiscais relacionadas à emissão de notas fiscais eletrônicas e declarações tributárias.

**Validação de NFe:** Verificação automática da autenticidade e validade de notas fiscais eletrônicas de fornecedores, garantindo conformidade fiscal e prevenindo fraudes.

**Consulta de Situação:** Verificação em tempo real da situação de notas fiscais emitidas, incluindo autorização, cancelamento ou rejeição pela SEFAZ.

**Relatórios Fiscais:** Geração automática de relatórios fiscais exigidos pela legislação, incluindo SPED Fiscal, SINTEGRA e outras obrigações acessórias.

**Monitoramento de Regularidade:** Acompanhamento contínuo da situação fiscal do estabelecimento, com alertas para pendências ou irregularidades que possam impactar a operação.

### OpenHealth/SBIS - Interoperabilidade em Saúde

A integração com padrões OpenHealth e SBIS garante interoperabilidade com sistemas de saúde e conformidade com protocolos de troca de informações médicas.

**Prescrições Eletrônicas:** Recebimento e validação de prescrições médicas eletrônicas, incluindo verificação de autenticidade, validade e conformidade com protocolos clínicos.

**Histórico do Paciente:** Acesso controlado ao histórico farmacoterapêutico de pacientes, permitindo análise de interações medicamentosas e acompanhamento de tratamentos.

**Alertas Clínicos:** Sistema de alertas para interações medicamentosas, contraindicações, alergias conhecidas e duplicidade terapêutica.

**Relatórios de Aderência:** Geração de relatórios sobre aderência ao tratamento, auxiliando profissionais de saúde no acompanhamento de pacientes crônicos.


## Módulo Mobile

### Arquitetura Mobile-First

O módulo mobile do Farmynex foi desenvolvido com arquitetura mobile-first, reconhecendo a importância crescente de dispositivos móveis no ambiente farmacêutico. A solução oferece funcionalidades completas otimizadas para smartphones e tablets, permitindo operação eficiente mesmo em ambientes com conectividade limitada.

**Autenticação por Dispositivo:** Sistema robusto de autenticação que considera as características únicas de cada dispositivo móvel. Cada dispositivo recebe tokens específicos com políticas de expiração diferenciadas, permitindo controle granular de acesso e segurança aprimorada.

**Gestão de Sessões:** Implementação de sessões persistentes com refresh automático de tokens, garantindo experiência contínua para usuários. O sistema suporta múltiplos dispositivos por usuário, com capacidade de revogação remota em caso de perda ou roubo.

**Sincronização Inteligente:** Mecanismo sofisticado de sincronização que otimiza o tráfego de dados e garante consistência entre dispositivos. A sincronização é incremental, transferindo apenas dados modificados desde a última sincronização.

### Funcionalidades Offline

**Cache Local:** Sistema abrangente de cache que permite operação offline para funcionalidades críticas. Dados de produtos, clientes frequentes e configurações são mantidos localmente, permitindo vendas mesmo sem conectividade.

**Sincronização Diferida:** Transações realizadas offline são armazenadas localmente e sincronizadas automaticamente quando a conectividade é restaurada. Mecanismos de resolução de conflitos garantem integridade dos dados.

**Indicadores de Status:** Interface clara que informa o status de conectividade e sincronização, permitindo que usuários compreendam quando estão operando offline e quando dados foram sincronizados.

### Otimizações de Performance

**Carregamento Progressivo:** Implementação de lazy loading para componentes e dados, reduzindo tempo de inicialização e consumo de memória. Dados são carregados conforme necessário, melhorando responsividade.

**Compressão de Dados:** Algoritmos de compressão otimizados reduzem significativamente o tráfego de dados, importante para usuários com planos limitados ou conectividade instável.

**Cache Inteligente:** Sistema de cache que aprende padrões de uso e pré-carrega dados relevantes, melhorando percepção de performance e reduzindo latência.

### Push Notifications

**Notificações Contextuais:** Sistema inteligente de notificações que considera contexto do usuário, horário de trabalho e preferências pessoais. Notificações são categorizadas por prioridade e tipo.

**Alertas Críticos:** Notificações imediatas para situações críticas como estoque baixo, vencimento de produtos, alertas sanitários e problemas de sistema.

**Campanhas Personalizadas:** Capacidade de envio de campanhas promocionais segmentadas baseadas em perfil do usuário, histórico de compras e localização geográfica.

### Segurança Mobile

**Criptografia End-to-End:** Todas as comunicações entre dispositivos móveis e servidores são criptografadas usando protocolos modernos. Dados sensíveis são criptografados também no armazenamento local.

**Biometria e PIN:** Suporte a autenticação biométrica (impressão digital, reconhecimento facial) e PIN personalizado para acesso rápido e seguro ao aplicativo.

**Detecção de Fraude:** Algoritmos de machine learning monitoram padrões de uso e detectam atividades suspeitas, como tentativas de acesso não autorizadas ou comportamentos anômalos.

### APIs Móveis Especializadas

**Endpoints Otimizados:** APIs específicas para dispositivos móveis com payloads reduzidos e estruturas otimizadas para consumo em aplicações móveis.

**Versionamento de API:** Sistema robusto de versionamento que permite atualizações graduais sem quebrar compatibilidade com versões anteriores do aplicativo.

**Rate Limiting Inteligente:** Políticas de rate limiting que consideram tipo de dispositivo, qualidade de conexão e padrões de uso, evitando bloqueios desnecessários.

### Análise e Métricas Mobile

**Analytics de Uso:** Coleta detalhada de métricas de uso, incluindo funcionalidades mais utilizadas, tempo de sessão, padrões de navegação e pontos de abandono.

**Performance Monitoring:** Monitoramento contínuo de performance do aplicativo, incluindo tempo de carregamento, crashes, consumo de bateria e uso de memória.

**Feedback de Usuários:** Sistema integrado para coleta de feedback e avaliações, permitindo melhoria contínua baseada na experiência real dos usuários.

### Integração com Hardware

**Scanner de Código de Barras:** Integração nativa com câmera do dispositivo para leitura de códigos de barras e QR codes, facilitando cadastro de produtos e vendas.

**Impressoras Móveis:** Suporte a impressoras térmicas móveis via Bluetooth para emissão de cupons fiscais e etiquetas em campo.

**Dispositivos de Pagamento:** Integração com maquininhas de cartão móveis e sistemas de pagamento por aproximação (NFC).


## Configuração e Instalação

### Pré-requisitos do Sistema

**Ambiente de Desenvolvimento:**
- Node.js versão 18.x ou superior
- npm versão 8.x ou superior
- Git para controle de versão
- Editor de código com suporte a TypeScript (recomendado: VS Code)

**Banco de Dados:**
- SQLite para desenvolvimento local (incluído)
- PostgreSQL 14.x ou superior para produção
- Redis 6.x para cache e sessões (opcional mas recomendado)

**Serviços Externos:**
- Conta Stripe com chaves de API configuradas
- Certificados digitais para integrações governamentais
- Servidor SMTP para envio de emails

### Instalação do Backend

**1. Clone do Repositório:**
```bash
git clone https://github.com/farmynex/farmynex-integrated.git
cd farmynex-integrated/backend
```

**2. Instalação de Dependências:**
```bash
npm install
```

**3. Configuração de Variáveis de Ambiente:**
Crie um arquivo `.env` na raiz do projeto backend com as seguintes configurações:

```env
# Configurações Gerais
NODE_ENV=development
PORT=3000
JWT_SECRET=sua_chave_jwt_super_secreta_aqui

# Banco de Dados
DATABASE_TYPE=sqlite
DATABASE_NAME=farmynex.db
# Para PostgreSQL em produção:
# DATABASE_TYPE=postgres
# DATABASE_HOST=localhost
# DATABASE_PORT=5432
# DATABASE_USERNAME=farmynex
# DATABASE_PASSWORD=senha_segura
# DATABASE_NAME=farmynex_prod

# Stripe
STRIPE_SECRET_KEY=sk_test_sua_chave_stripe_aqui
STRIPE_WEBHOOK_SECRET=whsec_sua_chave_webhook_aqui
STRIPE_PUBLIC_KEY=pk_test_sua_chave_publica_aqui

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=seu_email@gmail.com
SMTP_PASS=sua_senha_app

# Integrações Governamentais
ANVISA_API_KEY=sua_chave_anvisa
SNGPC_CERTIFICATE_PATH=/path/to/certificate.p12
SNGPC_CERTIFICATE_PASSWORD=senha_certificado
RECEITA_FEDERAL_API_KEY=sua_chave_receita_federal
```

**4. Execução das Migrações:**
```bash
npm run migration:run
```

**5. Inicialização do Servidor:**
```bash
# Desenvolvimento
npm run start:dev

# Produção
npm run build
npm run start:prod
```

### Instalação do Frontend

**1. Navegação para o Diretório:**
```bash
cd ../farmynex-dashboard
```

**2. Instalação de Dependências:**
```bash
npm install
```

**3. Configuração de Variáveis de Ambiente:**
Crie um arquivo `.env` no diretório do frontend:

```env
VITE_API_BASE_URL=http://localhost:3000
VITE_STRIPE_PUBLIC_KEY=pk_test_sua_chave_publica_stripe
VITE_APP_NAME=Farmynex Dashboard
VITE_APP_VERSION=1.0.0
```

**4. Execução do Servidor de Desenvolvimento:**
```bash
npm run dev
```

**5. Build para Produção:**
```bash
npm run build
```

### Configuração do Stripe

**1. Criação de Produtos no Dashboard Stripe:**
Acesse o dashboard do Stripe e crie os seguintes produtos com seus respectivos preços:

- **Plano Básico Mensal:** R$ 29,99/mês
- **Plano Profissional Mensal:** R$ 59,99/mês  
- **Plano Empresarial Mensal:** R$ 99,99/mês
- **Plano Básico Anual:** R$ 299,99/ano
- **Plano Profissional Anual:** R$ 599,99/ano
- **Plano Empresarial Anual:** R$ 999,99/ano

**2. Configuração de Webhooks:**
Configure os seguintes endpoints de webhook no dashboard Stripe:

- **URL:** `https://seu-dominio.com/stripe/webhook`
- **Eventos:** 
  - `checkout.session.completed`
  - `invoice.payment_succeeded`
  - `invoice.payment_failed`
  - `customer.subscription.updated`
  - `customer.subscription.deleted`

**3. Configuração de Métodos de Pagamento:**
Habilite os seguintes métodos de pagamento:
- Cartões de crédito/débito (Visa, Mastercard, Elo)
- PIX (quando disponível)
- Boleto bancário

### Configuração de Integrações Governamentais

**1. Certificados Digitais:**
Obtenha certificados digitais A1 ou A3 para integrações que requerem autenticação por certificado:
- SNGPC/SNCM
- SEFAZ (NFe)
- Receita Federal (consultas avançadas)

**2. Credenciamento em APIs:**
Realize o credenciamento nas seguintes APIs governamentais:
- ANVISA: Solicite chave de API para consultas de produtos
- CNES: Registre-se para acesso aos webservices
- SERASA: Configure conta empresarial para consultas de CPF/CNPJ

**3. Configuração de Certificados:**
```bash
# Copie os certificados para o diretório seguro
mkdir -p /etc/farmynex/certificates
cp certificado_sngpc.p12 /etc/farmynex/certificates/
cp certificado_sefaz.p12 /etc/farmynex/certificates/
chmod 600 /etc/farmynex/certificates/*
```

### Configuração de Produção

**1. Servidor Web:**
Configure um servidor web (Nginx recomendado) como proxy reverso:

```nginx
server {
    listen 80;
    server_name seu-dominio.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

**2. SSL/TLS:**
Configure certificados SSL usando Let's Encrypt:

```bash
sudo certbot --nginx -d seu-dominio.com
```

**3. Process Manager:**
Use PM2 para gerenciamento de processos em produção:

```bash
npm install -g pm2
pm2 start ecosystem.config.js
pm2 startup
pm2 save
```

**4. Monitoramento:**
Configure monitoramento com ferramentas como:
- PM2 Monitor para processos Node.js
- Nginx logs para análise de tráfego
- PostgreSQL logs para monitoramento de banco
- Stripe Dashboard para métricas financeiras

### Backup e Recuperação

**1. Backup Automático do Banco:**
```bash
# Script de backup diário
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump farmynex_prod > /backups/farmynex_$DATE.sql
find /backups -name "farmynex_*.sql" -mtime +7 -delete
```

**2. Backup de Certificados:**
```bash
# Backup semanal de certificados
tar -czf /backups/certificates_$(date +%Y%m%d).tar.gz /etc/farmynex/certificates/
```

**3. Procedimento de Recuperação:**
```bash
# Restauração do banco
psql farmynex_prod < /backups/farmynex_YYYYMMDD_HHMMSS.sql

# Restauração de certificados
tar -xzf /backups/certificates_YYYYMMDD.tar.gz -C /
```


## Endpoints da API

### Autenticação e Usuários

**POST /auth/login**
Realiza autenticação de usuário no sistema.

```json
{
  "email": "usuario@farmacia.com",
  "password": "senha123"
}
```

Resposta:
```json
{
  "success": true,
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": "uuid",
      "email": "usuario@farmacia.com",
      "firstName": "João",
      "lastName": "Silva",
      "role": "PHARMACIST"
    }
  }
}
```

**POST /auth/refresh**
Renova token de acesso usando refresh token.

**POST /auth/logout**
Realiza logout e invalida tokens.

**GET /users/profile**
Obtém perfil do usuário autenticado.

**PUT /users/profile**
Atualiza dados do perfil do usuário.

### Stripe e Assinaturas

**GET /stripe/plans**
Lista todos os planos de assinatura disponíveis.

Resposta:
```json
{
  "success": true,
  "data": [
    {
      "id": "basico",
      "name": "Plano Básico",
      "description": "Ideal para farmácias pequenas",
      "price": 2999,
      "currency": "brl",
      "interval": "month",
      "features": [
        "Gestão de estoque básica",
        "Vendas simples",
        "Relatórios básicos"
      ]
    }
  ]
}
```

**GET /stripe/plans/:planId**
Obtém detalhes de um plano específico.

**POST /stripe/create-checkout-session**
Cria sessão de checkout para assinatura.

```json
{
  "planId": "profissional",
  "customerEmail": "cliente@farmacia.com",
  "successUrl": "https://app.farmynex.com/success",
  "cancelUrl": "https://app.farmynex.com/cancel"
}
```

**GET /stripe/subscription/:subscriptionId**
Obtém detalhes de uma assinatura.

**POST /stripe/subscription/:subscriptionId/cancel**
Cancela uma assinatura.

**POST /stripe/subscription/:subscriptionId/update**
Atualiza plano de uma assinatura.

**POST /stripe/webhook**
Endpoint para webhooks do Stripe.

### Integrações Governamentais

#### ANVISA

**GET /integrations/anvisa/product/:codigo**
Consulta produto na base da ANVISA.

Resposta:
```json
{
  "success": true,
  "data": {
    "codigo": "123456789",
    "nome": "Dipirona Sódica 500mg",
    "principioAtivo": "Dipirona Sódica",
    "laboratorio": "EMS S/A",
    "situacao": "ATIVO",
    "dataRegistro": "2020-01-15",
    "indicacoes": ["Analgésico", "Antitérmico"]
  }
}
```

**GET /integrations/anvisa/establishment/:cnpj**
Consulta estabelecimento na ANVISA.

**GET /integrations/anvisa/alerts**
Lista alertas sanitários ativos.

#### Receita Federal

**GET /integrations/receita-federal/cnpj/:cnpj**
Consulta dados de empresa por CNPJ.

```json
{
  "success": true,
  "data": {
    "cnpj": "12345678000190",
    "razaoSocial": "FARMACIA CENTRAL LTDA",
    "situacaoCadastral": "ATIVA",
    "cnae": {
      "principal": {
        "codigo": "4771-7/01",
        "descricao": "Comércio varejista de produtos farmacêuticos"
      }
    }
  }
}
```

**GET /integrations/receita-federal/cpf/:cpf**
Consulta situação de CPF.

**POST /integrations/receita-federal/validate-cnpj**
Valida CNPJ e verifica aptidão farmacêutica.

#### SERASA

**GET /integrations/serasa/score-pf/:cpf**
Consulta score de pessoa física.

**GET /integrations/serasa/score-pj/:cnpj**
Consulta score de pessoa jurídica.

**POST /integrations/serasa/analyze-risk**
Analisa risco de crédito.

```json
{
  "documento": "12345678901",
  "tipo": "CPF",
  "valorCredito": 5000
}
```

#### SEFAZ

**GET /integrations/sefaz/nfe/:chaveAcesso**
Consulta NFe por chave de acesso.

**GET /integrations/sefaz/nfe/status/:chaveAcesso**
Consulta situação de NFe.

**GET /integrations/sefaz/nfes/period**
Consulta NFes por período.

Parâmetros:
- `cnpj`: CNPJ do emitente
- `dataInicio`: Data inicial (YYYY-MM-DD)
- `dataFim`: Data final (YYYY-MM-DD)

### Mobile APIs

**POST /mobile/auth/login**
Autenticação específica para dispositivos móveis.

```json
{
  "email": "usuario@farmacia.com",
  "password": "senha123",
  "deviceId": "device_unique_id",
  "deviceName": "iPhone 13",
  "deviceType": "ios",
  "osVersion": "15.0",
  "appVersion": "1.0.0",
  "pushToken": "push_notification_token"
}
```

**POST /mobile/auth/refresh**
Renova token móvel.

**GET /mobile/auth/devices**
Lista dispositivos do usuário.

**DELETE /mobile/auth/devices/:deviceId**
Remove dispositivo.

**POST /mobile/sync**
Sincroniza dados com dispositivo móvel.

```json
{
  "lastSyncTimestamp": "2024-12-08T10:00:00Z",
  "entities": ["products", "sales", "customers"],
  "deviceId": "device_unique_id"
}
```

### Códigos de Status HTTP

**200 OK:** Requisição processada com sucesso
**201 Created:** Recurso criado com sucesso
**400 Bad Request:** Dados inválidos na requisição
**401 Unauthorized:** Token de autenticação inválido ou ausente
**403 Forbidden:** Usuário não tem permissão para acessar recurso
**404 Not Found:** Recurso não encontrado
**429 Too Many Requests:** Limite de requisições excedido
**500 Internal Server Error:** Erro interno do servidor

### Rate Limiting

**Limites Padrão:**
- APIs públicas: 100 requisições por minuto
- APIs autenticadas: 1000 requisições por minuto
- APIs de integração: 500 requisições por minuto
- Webhooks: Sem limite

**Headers de Rate Limiting:**
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1640995200
```

### Paginação

Endpoints que retornam listas suportam paginação:

**Parâmetros:**
- `page`: Número da página (padrão: 1)
- `limit`: Itens por página (padrão: 20, máximo: 100)
- `sort`: Campo para ordenação
- `order`: Direção da ordenação (asc/desc)

**Resposta:**
```json
{
  "success": true,
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "pages": 8
  }
}
```

### Filtros e Busca

**Parâmetros de Filtro:**
- `search`: Busca textual
- `status`: Filtro por status
- `dateFrom`: Data inicial
- `dateTo`: Data final
- `category`: Categoria

**Exemplo:**
```
GET /products?search=dipirona&category=medicamentos&status=active&page=1&limit=20
```


## Exemplos de Uso

### Fluxo Completo de Assinatura

**1. Listagem de Planos:**
```javascript
// Frontend - Buscar planos disponíveis
const response = await fetch('/api/stripe/plans');
const { data: plans } = await response.json();

// Exibir planos na interface
plans.forEach(plan => {
  console.log(`${plan.name}: R$ ${plan.price/100} por ${plan.interval}`);
});
```

**2. Criação de Checkout:**
```javascript
// Criar sessão de checkout
const checkoutData = {
  planId: 'profissional',
  customerEmail: 'cliente@farmacia.com',
  successUrl: 'https://app.farmynex.com/success',
  cancelUrl: 'https://app.farmynex.com/cancel'
};

const response = await fetch('/api/stripe/create-checkout-session', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${accessToken}`
  },
  body: JSON.stringify(checkoutData)
});

const { data } = await response.json();
// Redirecionar para data.url
window.location.href = data.url;
```

**3. Processamento de Webhook:**
```javascript
// Backend - Processar evento de checkout completado
@Post('stripe/webhook')
async handleWebhook(@Body() payload, @Headers('stripe-signature') signature) {
  const event = stripe.webhooks.constructEvent(payload, signature, webhookSecret);
  
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    
    // Ativar assinatura do usuário
    await this.subscriptionService.activateSubscription({
      userId: session.metadata.userId,
      stripeSubscriptionId: session.subscription,
      planId: session.metadata.planId
    });
  }
}
```

### Integração com ANVISA

**Consulta de Produto:**
```javascript
// Verificar produto na ANVISA
async function verificarProdutoANVISA(codigoProduto) {
  try {
    const response = await fetch(`/api/integrations/anvisa/product/${codigoProduto}`);
    const { data: produto } = await response.json();
    
    if (produto.situacao === 'ATIVO') {
      console.log(`Produto ${produto.nome} está regular na ANVISA`);
      return {
        valido: true,
        produto: produto
      };
    } else {
      console.warn(`Produto ${produto.nome} com situação: ${produto.situacao}`);
      return {
        valido: false,
        motivo: produto.situacao
      };
    }
  } catch (error) {
    console.error('Erro ao consultar ANVISA:', error);
    return {
      valido: false,
      motivo: 'Erro na consulta'
    };
  }
}
```

### Autenticação Mobile

**Login com Dispositivo:**
```javascript
// App Mobile - Login com informações do dispositivo
async function loginMobile(email, password) {
  const deviceInfo = {
    email,
    password,
    deviceId: await getDeviceId(),
    deviceName: await getDeviceName(),
    deviceType: Platform.OS, // 'ios' ou 'android'
    osVersion: await getOSVersion(),
    appVersion: getAppVersion(),
    pushToken: await getPushToken()
  };
  
  const response = await fetch('/api/mobile/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(deviceInfo)
  });
  
  const { data } = await response.json();
  
  // Armazenar tokens localmente
  await AsyncStorage.setItem('accessToken', data.accessToken);
  await AsyncStorage.setItem('refreshToken', data.refreshToken);
  
  return data;
}
```

**Sincronização de Dados:**
```javascript
// Sincronizar dados com servidor
async function syncData() {
  const lastSync = await AsyncStorage.getItem('lastSyncTimestamp');
  const deviceId = await getDeviceId();
  
  const syncRequest = {
    lastSyncTimestamp: lastSync,
    entities: ['products', 'sales', 'customers'],
    deviceId
  };
  
  const response = await fetch('/api/mobile/sync', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${await getAccessToken()}`
    },
    body: JSON.stringify(syncRequest)
  });
  
  const { data } = await response.json();
  
  // Atualizar dados locais
  await updateLocalData(data);
  await AsyncStorage.setItem('lastSyncTimestamp', data.timestamp);
}
```

## Segurança e Conformidade

### Proteção de Dados

**Criptografia:** Todos os dados sensíveis são criptografados em trânsito usando TLS 1.3 e em repouso usando AES-256. Chaves de criptografia são rotacionadas regularmente e armazenadas em HSM (Hardware Security Module) em produção.

**Tokenização:** Dados de pagamento são tokenizados pelo Stripe, garantindo que informações de cartão nunca sejam armazenadas nos servidores da aplicação. Tokens têm escopo limitado e podem ser revogados instantaneamente.

**Auditoria:** Sistema completo de auditoria registra todas as ações críticas, incluindo acessos, modificações de dados, transações financeiras e integrações com órgãos governamentais. Logs são imutáveis e mantidos por período mínimo de 5 anos.

### Conformidade Regulatória

**LGPD (Lei Geral de Proteção de Dados):** Implementação completa de controles de privacidade, incluindo consentimento explícito, direito ao esquecimento, portabilidade de dados e notificação de incidentes. DPO (Data Protection Officer) designado para supervisionar conformidade.

**PCI DSS:** Certificação PCI DSS Level 1 através da integração com Stripe, garantindo máxima segurança para processamento de pagamentos. Auditorias anuais validam manutenção dos controles de segurança.

**Regulamentações Farmacêuticas:** Conformidade com RDC 44/2009 da ANVISA para farmácias, incluindo rastreabilidade de medicamentos controlados, escrituração digital e relatórios obrigatórios.

### Controles de Acesso

**Autenticação Multifator:** Suporte a 2FA via SMS, email e aplicativos autenticadores. Obrigatório para usuários com privilégios administrativos e recomendado para todos os usuários.

**Controle de Sessão:** Sessões têm timeout configurável, detecção de atividade suspeita e capacidade de revogação remota. Múltiplas sessões por usuário são permitidas com monitoramento de localização.

**Princípio do Menor Privilégio:** Usuários recebem apenas as permissões mínimas necessárias para suas funções. Revisões periódicas de acesso garantem que privilégios permaneçam apropriados.

## Monitoramento e Logs

### Métricas de Sistema

**Performance:** Monitoramento contínuo de latência de API, throughput, uso de CPU e memória. Alertas automáticos para degradação de performance ou indisponibilidade de serviços.

**Disponibilidade:** SLA de 99.9% de uptime com monitoramento 24/7. Redundância geográfica e failover automático garantem continuidade de serviço.

**Segurança:** Detecção de tentativas de intrusão, ataques DDoS e comportamentos anômalos. Integração com serviços de threat intelligence para proteção proativa.

### Dashboards Operacionais

**Métricas de Negócio:** Acompanhamento em tempo real de receita, novos clientes, churn rate e uso de funcionalidades. Alertas para métricas fora dos parâmetros esperados.

**Integrações:** Status de todas as integrações governamentais, latência de consultas e taxa de sucesso. Alertas para indisponibilidade de serviços externos.

**Mobile:** Métricas específicas de aplicações móveis, incluindo crashes, tempo de sincronização e uso offline. Análise de performance por dispositivo e versão do app.

## Troubleshooting

### Problemas Comuns

**Erro de Autenticação Stripe:**
- Verificar se as chaves de API estão corretas no arquivo .env
- Confirmar se o webhook está configurado com a URL correta
- Validar se os produtos foram criados no dashboard Stripe

**Falha em Integrações Governamentais:**
- Verificar validade dos certificados digitais
- Confirmar conectividade com APIs externas
- Revisar logs para identificar erros específicos

**Problemas de Sincronização Mobile:**
- Verificar conectividade de rede do dispositivo
- Confirmar se tokens de autenticação estão válidos
- Revisar logs de sincronização para identificar conflitos

### Logs e Debugging

**Níveis de Log:**
- ERROR: Erros críticos que impedem funcionamento
- WARN: Situações que requerem atenção mas não impedem operação
- INFO: Informações gerais sobre operação do sistema
- DEBUG: Informações detalhadas para debugging

**Localização de Logs:**
- Backend: `/var/log/farmynex/backend.log`
- Frontend: Console do navegador e Sentry
- Mobile: Logs locais e crash reporting

## Roadmap e Próximos Passos

### Funcionalidades Planejadas

**Curto Prazo (3 meses):**
- Integração com PIX para pagamentos instantâneos
- Módulo de telemedicina para consultas remotas
- Analytics avançados com machine learning
- App mobile nativo para iOS e Android

**Médio Prazo (6 meses):**
- Integração com sistemas de gestão hospitalar
- Marketplace de medicamentos entre farmácias
- Programa de fidelidade integrado
- Chatbot com IA para atendimento ao cliente

**Longo Prazo (12 meses):**
- Expansão para outros países da América Latina
- Integração com IoT para monitoramento de estoque
- Blockchain para rastreabilidade de medicamentos
- Plataforma de educação continuada para farmacêuticos

### Melhorias Técnicas

**Performance:** Implementação de CDN global, otimização de queries de banco de dados e cache distribuído para melhorar latência.

**Escalabilidade:** Migração para arquitetura de microserviços, implementação de auto-scaling e distribuição geográfica de serviços.

**Segurança:** Implementação de Zero Trust Architecture, criptografia homomórfica para análise de dados sensíveis e detecção avançada de ameaças.

---

**Conclusão**

A integração completa do Farmynex representa um marco significativo na digitalização do setor farmacêutico brasileiro. Com funcionalidades abrangentes, conformidade regulatória e arquitetura moderna, a solução está preparada para atender às necessidades atuais e futuras do mercado farmacêutico.

A documentação apresentada fornece todas as informações necessárias para implementação, configuração e operação do sistema. Para suporte adicional ou esclarecimentos, entre em contato com a equipe técnica através dos canais oficiais.

**Contato:**
- Email: suporte@farmynex.com
- Telefone: +55 11 1234-5678
- Portal de Suporte: https://suporte.farmynex.com

**Versão da Documentação:** 1.0.0  
**Última Atualização:** 9 de dezembro de 2024

