import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import Backend from 'i18next-http-backend';

// Traduções inline para desenvolvimento
const resources = {
  pt: {
    translation: {
      // Navegação
      "dashboard": "Dashboard",
      "plans": "Planos",
      "subscription": "Minha Assinatura",
      "billing": "Faturamento",
      "reports": "Relatórios",
      "settings": "Configurações",
      "logout": "Sair",
      
      // Dashboard
      "welcome": "Bem-vindo ao Farmynex",
      "dashboard_subtitle": "Gerencie seus planos de assinatura e acompanhe métricas",
      "total_revenue": "Receita Total",
      "active_subscriptions": "Assinaturas Ativas",
      "monthly_growth": "Crescimento Mensal",
      "churn_rate": "Taxa de Churn",
      
      // Planos
      "available_plans": "Planos Disponíveis",
      "choose_plan": "Escolher Plano",
      "most_popular": "Mais Popular",
      "monthly": "Mensal",
      "annual": "Anual",
      "per_month": "por mês",
      "per_year": "por ano",
      "savings": "economia",
      "select_plan": "Selecionar Plano",
      
      // Checkout
      "checkout": "Finalizar Compra",
      "plan_selected": "Plano Selecionado",
      "payment_method": "Método de Pagamento",
      "billing_info": "Informações de Cobrança",
      "complete_purchase": "Finalizar Compra",
      
      // Relatórios
      "detailed_reports": "Relatórios Detalhados",
      "revenue_analytics": "Análise de Receita",
      "subscription_metrics": "Métricas de Assinatura",
      "customer_insights": "Insights de Clientes",
      "export_data": "Exportar Dados",
      
      // Formulários
      "email": "Email",
      "password": "Senha",
      "full_name": "Nome Completo",
      "company": "Empresa",
      "phone": "Telefone",
      "save": "Salvar",
      "cancel": "Cancelar",
      "loading": "Carregando...",
      
      // Mensagens
      "success": "Sucesso!",
      "error": "Erro",
      "subscription_updated": "Assinatura atualizada com sucesso",
      "payment_processed": "Pagamento processado com sucesso",
      "data_saved": "Dados salvos com sucesso"
    }
  },
  en: {
    translation: {
      // Navigation
      "dashboard": "Dashboard",
      "plans": "Plans",
      "subscription": "My Subscription",
      "billing": "Billing",
      "reports": "Reports",
      "settings": "Settings",
      "logout": "Logout",
      
      // Dashboard
      "welcome": "Welcome to Farmynex",
      "dashboard_subtitle": "Manage your subscription plans and track metrics",
      "total_revenue": "Total Revenue",
      "active_subscriptions": "Active Subscriptions",
      "monthly_growth": "Monthly Growth",
      "churn_rate": "Churn Rate",
      
      // Plans
      "available_plans": "Available Plans",
      "choose_plan": "Choose Plan",
      "most_popular": "Most Popular",
      "monthly": "Monthly",
      "annual": "Annual",
      "per_month": "per month",
      "per_year": "per year",
      "savings": "savings",
      "select_plan": "Select Plan",
      
      // Checkout
      "checkout": "Checkout",
      "plan_selected": "Selected Plan",
      "payment_method": "Payment Method",
      "billing_info": "Billing Information",
      "complete_purchase": "Complete Purchase",
      
      // Reports
      "detailed_reports": "Detailed Reports",
      "revenue_analytics": "Revenue Analytics",
      "subscription_metrics": "Subscription Metrics",
      "customer_insights": "Customer Insights",
      "export_data": "Export Data",
      
      // Forms
      "email": "Email",
      "password": "Password",
      "full_name": "Full Name",
      "company": "Company",
      "phone": "Phone",
      "save": "Save",
      "cancel": "Cancel",
      "loading": "Loading...",
      
      // Messages
      "success": "Success!",
      "error": "Error",
      "subscription_updated": "Subscription updated successfully",
      "payment_processed": "Payment processed successfully",
      "data_saved": "Data saved successfully"
    }
  },
  es: {
    translation: {
      // Navegación
      "dashboard": "Panel",
      "plans": "Planes",
      "subscription": "Mi Suscripción",
      "billing": "Facturación",
      "reports": "Informes",
      "settings": "Configuración",
      "logout": "Cerrar Sesión",
      
      // Dashboard
      "welcome": "Bienvenido a Farmynex",
      "dashboard_subtitle": "Gestiona tus planes de suscripción y rastrea métricas",
      "total_revenue": "Ingresos Totales",
      "active_subscriptions": "Suscripciones Activas",
      "monthly_growth": "Crecimiento Mensual",
      "churn_rate": "Tasa de Abandono",
      
      // Planes
      "available_plans": "Planes Disponibles",
      "choose_plan": "Elegir Plan",
      "most_popular": "Más Popular",
      "monthly": "Mensual",
      "annual": "Anual",
      "per_month": "por mes",
      "per_year": "por año",
      "savings": "ahorro",
      "select_plan": "Seleccionar Plan",
      
      // Checkout
      "checkout": "Finalizar Compra",
      "plan_selected": "Plan Seleccionado",
      "payment_method": "Método de Pago",
      "billing_info": "Información de Facturación",
      "complete_purchase": "Completar Compra",
      
      // Informes
      "detailed_reports": "Informes Detallados",
      "revenue_analytics": "Análisis de Ingresos",
      "subscription_metrics": "Métricas de Suscripción",
      "customer_insights": "Insights de Clientes",
      "export_data": "Exportar Datos",
      
      // Formularios
      "email": "Correo",
      "password": "Contraseña",
      "full_name": "Nombre Completo",
      "company": "Empresa",
      "phone": "Teléfono",
      "save": "Guardar",
      "cancel": "Cancelar",
      "loading": "Cargando...",
      
      // Mensajes
      "success": "¡Éxito!",
      "error": "Error",
      "subscription_updated": "Suscripción actualizada exitosamente",
      "payment_processed": "Pago procesado exitosamente",
      "data_saved": "Datos guardados exitosamente"
    }
  }
};

i18n
  .use(Backend)
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'pt',
    debug: false,
    
    interpolation: {
      escapeValue: false,
    },
    
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage'],
    },
  });

export default i18n;

