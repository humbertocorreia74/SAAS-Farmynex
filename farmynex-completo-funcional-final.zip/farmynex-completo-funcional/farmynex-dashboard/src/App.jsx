import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { 
  CreditCard, 
  Check, 
  Star, 
  Zap, 
  Shield, 
  Users, 
  BarChart3, 
  Settings, 
  Bell, 
  User, 
  LogOut,
  Menu,
  X
} from 'lucide-react';
import { authService, stripeService } from '@/services/api.js';
import Reports from '@/components/Reports.jsx';
import Checkout from '@/components/Checkout.jsx';
import LanguageSwitcher from '@/components/LanguageSwitcher.jsx';
import './i18n/index.js'; // Importar configuração do i18n
import './App.css';

// Criar cliente do React Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutos
    },
  },
});

// Dados dos planos Farmynex atualizados
const farmynexPlans = [
  {
    id: 'basico',
    name: 'Plano Básico',
    description: 'Ideal para farmácias pequenas',
    price: 2999,
    currency: 'R$',
    interval: 'mês',
    popular: false,
    features: [
      'Gestão básica de estoque',
      'Controle de vendas',
      'Relatórios básicos',
      'Suporte por email',
      'Até 1.000 produtos'
    ]
  },
  {
    id: 'profissional',
    name: 'Plano Profissional',
    description: 'Para farmácias em crescimento',
    price: 5999,
    currency: 'R$',
    interval: 'mês',
    popular: true,
    features: [
      'Gestão completa de estoque',
      'Sistema de vendas avançado',
      'Relatórios detalhados',
      'Integração com fornecedores',
      'Suporte prioritário',
      'Até 5.000 produtos'
    ]
  },
  {
    id: 'empresarial',
    name: 'Plano Empresarial',
    description: 'Para redes de farmácias',
    price: 9999,
    currency: 'R$',
    interval: 'mês',
    popular: false,
    features: [
      'Gestão multi-loja',
      'Analytics avançados',
      'API completa',
      'Integrações personalizadas',
      'Suporte 24/7',
      'Produtos ilimitados'
    ]
  }
];

// Componente principal do Dashboard
function Dashboard() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [plans, setPlans] = useState(farmynexPlans);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Carregar dados do usuário
    const currentUser = authService.getCurrentUser();
    setUser(currentUser);
    
    // Carregar planos da API
    loadPlans();
  }, []);

  const loadPlans = async () => {
    setLoading(true);
    try {
      const response = await stripeService.getPlans();
      if (response.success) {
        setPlans(response.data);
      }
    } catch (error) {
      console.error('Erro ao carregar planos:', error);
      // Manter planos mock em caso de erro
    } finally {
      setLoading(false);
    }
  };

  const handleSelectPlan = (planId) => {
    window.location.href = `/checkout?plan=${planId}`;
  };

  const handleLogout = async () => {
    await authService.logout();
    window.location.href = '/login';
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price / 100);
  };

  const Sidebar = () => (
    <div className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform ${
      sidebarOpen ? 'translate-x-0' : '-translate-x-full'
    } transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0`}>
      <div className="flex items-center justify-between h-16 px-6 border-b">
        <h1 className="text-xl font-bold text-blue-600">Farmynex</h1>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSidebarOpen(false)}
          className="lg:hidden"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      <nav className="mt-6">
        <div className="px-3 space-y-1">
          <Button
            variant={activeTab === 'dashboard' ? 'secondary' : 'ghost'}
            className="w-full justify-start"
            onClick={() => {
              setActiveTab('dashboard');
              setSidebarOpen(false);
            }}
          >
            <BarChart3 className="mr-2 h-4 w-4" />
            {t('dashboard')}
          </Button>
          
          <Button
            variant={activeTab === 'plans' ? 'secondary' : 'ghost'}
            className="w-full justify-start"
            onClick={() => {
              setActiveTab('plans');
              setSidebarOpen(false);
            }}
          >
            <CreditCard className="mr-2 h-4 w-4" />
            {t('plans')}
          </Button>
          
          <Button
            variant={activeTab === 'subscription' ? 'secondary' : 'ghost'}
            className="w-full justify-start"
            onClick={() => {
              setActiveTab('subscription');
              setSidebarOpen(false);
            }}
          >
            <User className="mr-2 h-4 w-4" />
            {t('subscription')}
          </Button>
          
          <Button
            variant={activeTab === 'billing' ? 'secondary' : 'ghost'}
            className="w-full justify-start"
            onClick={() => {
              setActiveTab('billing');
              setSidebarOpen(false);
            }}
          >
            <CreditCard className="mr-2 h-4 w-4" />
            {t('billing')}
          </Button>
          
          <Button
            variant={activeTab === 'reports' ? 'secondary' : 'ghost'}
            className="w-full justify-start"
            onClick={() => {
              setActiveTab('reports');
              setSidebarOpen(false);
            }}
          >
            <BarChart3 className="mr-2 h-4 w-4" />
            {t('reports')}
          </Button>
          
          <Button
            variant={activeTab === 'settings' ? 'secondary' : 'ghost'}
            className="w-full justify-start"
            onClick={() => {
              setActiveTab('settings');
              setSidebarOpen(false);
            }}
          >
            <Settings className="mr-2 h-4 w-4" />
            {t('settings')}
          </Button>
        </div>
      </nav>
      
      <div className="absolute bottom-0 w-full p-3 border-t">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-white" />
            </div>
            <div className="text-sm">
              <p className="font-medium">{user?.firstName || 'Usuário'}</p>
              <p className="text-gray-500 text-xs">{user?.email || 'email@exemplo.com'}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={handleLogout}>
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );

  const Header = () => (
    <header className="bg-white shadow-sm border-b lg:ml-64">
      <div className="flex items-center justify-between h-16 px-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSidebarOpen(true)}
          className="lg:hidden"
        >
          <Menu className="h-4 w-4" />
        </Button>
        
        <div className="flex items-center space-x-4">
          <LanguageSwitcher />
          <Button variant="ghost" size="sm">
            <Bell className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );

  const DashboardContent = () => (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{t('welcome')}</h1>
        <p className="text-muted-foreground">{t('dashboard_subtitle')}</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('total_revenue')}</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 67.890</div>
            <p className="text-xs text-muted-foreground">+12.5% em relação ao mês anterior</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('active_subscriptions')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1.247</div>
            <p className="text-xs text-muted-foreground">+8.3% em relação ao mês anterior</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('monthly_growth')}</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">+15.2%</div>
            <p className="text-xs text-muted-foreground">Meta: +10% mensal</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('churn_rate')}</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2.1%</div>
            <p className="text-xs text-muted-foreground">-0.5% em relação ao mês anterior</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const PlansContent = () => (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{t('available_plans')}</h1>
        <p className="text-muted-foreground">{t('choose_plan')}</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card key={plan.id} className={`relative ${plan.popular ? 'border-blue-500 shadow-lg' : ''}`}>
            {plan.popular && (
              <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-blue-500">
                <Star className="w-3 h-3 mr-1" />
                {t('most_popular')}
              </Badge>
            )}
            
            <CardHeader>
              <CardTitle className="text-xl">{plan.name}</CardTitle>
              <CardDescription>{plan.description}</CardDescription>
              <div className="text-3xl font-bold">
                {formatPrice(plan.price)}
                <span className="text-sm font-normal text-muted-foreground">
                  /{t('per_month')}
                </span>
              </div>
            </CardHeader>
            
            <CardContent>
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            
            <CardFooter>
              <Button 
                className="w-full" 
                variant={plan.popular ? "default" : "outline"}
                onClick={() => handleSelectPlan(plan.id)}
              >
                {t('select_plan')}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );

  const SubscriptionContent = () => (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{t('subscription')}</h1>
        <p className="text-muted-foreground">Gerencie sua assinatura atual</p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Plano Atual</CardTitle>
          <CardDescription>Detalhes da sua assinatura ativa</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="font-medium">Plano:</span>
              <Badge variant="secondary">Plano Profissional</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-medium">Status:</span>
              <Badge className="bg-green-500">Ativo</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-medium">Próxima cobrança:</span>
              <span>15 de Janeiro, 2025</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-medium">Valor:</span>
              <span className="font-bold">R$ 59,99/mês</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="space-x-2">
          <Button variant="outline">Alterar Plano</Button>
          <Button variant="destructive">Cancelar Assinatura</Button>
        </CardFooter>
      </Card>
    </div>
  );

  const BillingContent = () => (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{t('billing')}</h1>
        <p className="text-muted-foreground">Histórico de pagamentos e faturas</p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Pagamentos</CardTitle>
          <CardDescription>Últimas transações da sua conta</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { date: '15 Dez 2024', amount: 'R$ 59,99', status: 'Pago', invoice: '#INV-001' },
              { date: '15 Nov 2024', amount: 'R$ 59,99', status: 'Pago', invoice: '#INV-002' },
              { date: '15 Out 2024', amount: 'R$ 59,99', status: 'Pago', invoice: '#INV-003' },
            ].map((payment, index) => (
              <div key={index} className="flex justify-between items-center p-4 border rounded-lg">
                <div>
                  <p className="font-medium">{payment.invoice}</p>
                  <p className="text-sm text-muted-foreground">{payment.date}</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">{payment.amount}</p>
                  <Badge variant="secondary">{payment.status}</Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const SettingsContent = () => (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{t('settings')}</h1>
        <p className="text-muted-foreground">Configurações da conta e preferências</p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Informações da Conta</CardTitle>
          <CardDescription>Atualize suas informações pessoais</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Nome</label>
                <input 
                  type="text" 
                  className="w-full mt-1 p-2 border rounded-md" 
                  defaultValue={user?.firstName || ''}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Sobrenome</label>
                <input 
                  type="text" 
                  className="w-full mt-1 p-2 border rounded-md" 
                  defaultValue={user?.lastName || ''}
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Email</label>
              <input 
                type="email" 
                className="w-full mt-1 p-2 border rounded-md" 
                defaultValue={user?.email || ''}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button>{t('save')}</Button>
        </CardFooter>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />
      <Header />
      
      <main className="lg:ml-64 p-6">
        {activeTab === 'dashboard' && <DashboardContent />}
        {activeTab === 'plans' && <PlansContent />}
        {activeTab === 'subscription' && <SubscriptionContent />}
        {activeTab === 'billing' && <BillingContent />}
        {activeTab === 'reports' && <Reports />}
        {activeTab === 'settings' && <SettingsContent />}
      </main>
      
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}

// Componente principal da aplicação
function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/plans" element={<Dashboard />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/reports" element={<Dashboard />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </QueryClientProvider>
  );
}

export default App;

