import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Separator } from '@/components/ui/separator.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';
import { 
  CreditCard, 
  Shield, 
  Check, 
  ArrowLeft, 
  Loader2,
  Star,
  Lock
} from 'lucide-react';
import { stripeService, authService } from '@/services/api.js';

export default function Checkout() {
  const { t } = useTranslation();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    fullName: '',
    company: '',
    phone: '',
  });

  const planId = searchParams.get('plan');

  useEffect(() => {
    if (planId) {
      loadPlanDetails();
    }
    
    // Pré-preencher dados do usuário se estiver logado
    const user = authService.getCurrentUser();
    if (user) {
      setFormData(prev => ({
        ...prev,
        email: user.email || '',
        fullName: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
      }));
    }
  }, [planId]);

  const loadPlanDetails = async () => {
    try {
      const response = await stripeService.getPlan(planId);
      if (response.success) {
        setSelectedPlan(response.data);
      } else {
        setError('Plano não encontrado');
      }
    } catch (error) {
      console.error('Erro ao carregar plano:', error);
      setError('Erro ao carregar detalhes do plano');
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCheckout = async () => {
    if (!selectedPlan) return;

    setLoading(true);
    setError('');

    try {
      // Validar dados obrigatórios
      if (!formData.email || !formData.fullName) {
        setError('Por favor, preencha todos os campos obrigatórios');
        setLoading(false);
        return;
      }

      // Criar sessão de checkout
      const response = await stripeService.createCheckoutSession(
        selectedPlan.id,
        formData.email,
        `${window.location.origin}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
        `${window.location.origin}/checkout/cancel`
      );

      if (response.success && response.data.url) {
        // Redirecionar para o Stripe Checkout
        window.location.href = response.data.url;
      } else {
        setError('Erro ao criar sessão de pagamento');
      }
    } catch (error) {
      console.error('Erro no checkout:', error);
      setError('Erro ao processar pagamento. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price, currency = 'BRL') => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: currency,
    }).format(price / 100);
  };

  if (!selectedPlan && !error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (error && !selectedPlan) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button 
          variant="outline" 
          onClick={() => navigate('/plans')}
          className="mt-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar aos Planos
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* Header */}
      <div className="mb-8">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/plans')}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar aos Planos
        </Button>
        
        <h1 className="text-3xl font-bold">{t('checkout')}</h1>
        <p className="text-muted-foreground">
          Finalize sua assinatura do Farmynex
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Formulário de Checkout */}
        <div className="lg:col-span-2 space-y-6">
          {/* Informações Pessoais */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                {t('billing_info')}
              </CardTitle>
              <CardDescription>
                Preencha suas informações para finalizar a compra
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Nome Completo *</Label>
                  <Input
                    id="fullName"
                    value={formData.fullName}
                    onChange={(e) => handleInputChange('fullName', e.target.value)}
                    placeholder="Seu nome completo"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="seu@email.com"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="company">Empresa/Farmácia</Label>
                  <Input
                    id="company"
                    value={formData.company}
                    onChange={(e) => handleInputChange('company', e.target.value)}
                    placeholder="Nome da sua farmácia"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefone</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    placeholder="(11) 99999-9999"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Métodos de Pagamento */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                {t('payment_method')}
              </CardTitle>
              <CardDescription>
                Pagamento processado de forma segura pelo Stripe
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-center p-6 border-2 border-dashed border-gray-300 rounded-lg">
                  <div className="text-center">
                    <CreditCard className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                    <p className="text-sm text-gray-600">
                      Cartão de crédito, débito e PIX
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Processamento seguro via Stripe
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-4 text-xs text-gray-500">
                  <div className="flex items-center gap-1">
                    <Shield className="h-3 w-3" />
                    SSL Seguro
                  </div>
                  <div className="flex items-center gap-1">
                    <Lock className="h-3 w-3" />
                    PCI Compliant
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Erro */}
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Botão de Checkout */}
          <Button 
            onClick={handleCheckout}
            disabled={loading || !formData.email || !formData.fullName}
            className="w-full h-12 text-lg"
            size="lg"
          >
            {loading ? (
              <>
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                Processando...
              </>
            ) : (
              <>
                <CreditCard className="h-5 w-5 mr-2" />
                {t('complete_purchase')}
              </>
            )}
          </Button>
        </div>

        {/* Resumo do Pedido */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('plan_selected')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedPlan && (
                <>
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold text-lg">{selectedPlan.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {selectedPlan.description}
                      </p>
                      {selectedPlan.popular && (
                        <Badge variant="secondary" className="mt-1">
                          <Star className="h-3 w-3 mr-1" />
                          {t('most_popular')}
                        </Badge>
                      )}
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>{formatPrice(selectedPlan.price)}</span>
                    </div>
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Impostos:</span>
                      <span>Inclusos</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-semibold text-lg">
                      <span>Total:</span>
                      <span>{formatPrice(selectedPlan.price)}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Cobrança {selectedPlan.interval === 'month' ? 'mensal' : 'anual'}
                    </p>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <h4 className="font-medium">Funcionalidades incluídas:</h4>
                    <ul className="space-y-1">
                      {selectedPlan.features?.map((feature, index) => (
                        <li key={index} className="flex items-center gap-2 text-sm">
                          <Check className="h-3 w-3 text-green-600" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Garantia */}
          <Card>
            <CardContent className="pt-6">
              <div className="text-center space-y-2">
                <Shield className="h-8 w-8 mx-auto text-green-600" />
                <h4 className="font-medium">Garantia de 30 dias</h4>
                <p className="text-sm text-muted-foreground">
                  Cancele a qualquer momento nos primeiros 30 dias e receba reembolso total
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

