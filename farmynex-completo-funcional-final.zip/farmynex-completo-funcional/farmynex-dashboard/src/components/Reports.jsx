import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { DatePickerWithRange } from '@/components/ui/date-picker.jsx';
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  DollarSign, 
  Calendar, 
  Download,
  BarChart3,
  PieChart as PieChartIcon,
  Activity
} from 'lucide-react';
import { reportsService } from '@/services/api.js';

// Dados mock para desenvolvimento
const mockRevenueData = [
  { month: 'Jan', revenue: 45000, subscriptions: 150, churn: 5 },
  { month: 'Fev', revenue: 52000, subscriptions: 173, churn: 3 },
  { month: 'Mar', revenue: 48000, subscriptions: 160, churn: 7 },
  { month: 'Abr', revenue: 61000, subscriptions: 203, churn: 4 },
  { month: 'Mai', revenue: 55000, subscriptions: 183, churn: 6 },
  { month: 'Jun', revenue: 67000, subscriptions: 223, churn: 2 },
];

const mockPlanDistribution = [
  { name: 'Básico', value: 45, color: '#8884d8' },
  { name: 'Profissional', value: 35, color: '#82ca9d' },
  { name: 'Empresarial', value: 20, color: '#ffc658' },
];

const mockCustomerMetrics = [
  { metric: 'Novos Clientes', value: 156, change: 12.5, trend: 'up' },
  { metric: 'Clientes Ativos', value: 1247, change: 8.3, trend: 'up' },
  { metric: 'Taxa de Retenção', value: 94.2, change: -2.1, trend: 'down' },
  { metric: 'LTV Médio', value: 2450, change: 15.7, trend: 'up' },
];

const mockChurnAnalysis = [
  { reason: 'Preço Alto', percentage: 35 },
  { reason: 'Falta de Funcionalidades', percentage: 25 },
  { reason: 'Suporte Inadequado', percentage: 20 },
  { reason: 'Concorrência', percentage: 15 },
  { reason: 'Outros', percentage: 5 },
];

export default function Reports() {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState('30d');
  const [dateRange, setDateRange] = useState(null);
  const [revenueData, setRevenueData] = useState(mockRevenueData);
  const [planDistribution, setPlanDistribution] = useState(mockPlanDistribution);
  const [customerMetrics, setCustomerMetrics] = useState(mockCustomerMetrics);

  // Carregar dados dos relatórios
  useEffect(() => {
    loadReportsData();
  }, [selectedPeriod, dateRange]);

  const loadReportsData = async () => {
    setLoading(true);
    try {
      // Tentar carregar dados reais da API
      const [revenueResponse, metricsResponse] = await Promise.all([
        reportsService.getRevenueAnalytics(dateRange?.from, dateRange?.to),
        reportsService.getSubscriptionMetrics(selectedPeriod),
      ]);

      if (revenueResponse.success) {
        setRevenueData(revenueResponse.data);
      }

      if (metricsResponse.success) {
        setCustomerMetrics(metricsResponse.data.customerMetrics || mockCustomerMetrics);
        setPlanDistribution(metricsResponse.data.planDistribution || mockPlanDistribution);
      }
    } catch (error) {
      console.error('Erro ao carregar dados dos relatórios:', error);
      // Manter dados mock em caso de erro
    } finally {
      setLoading(false);
    }
  };

  const handleExportData = async (reportType) => {
    try {
      await reportsService.exportData(reportType, 'csv');
    } catch (error) {
      console.error('Erro ao exportar dados:', error);
    }
  };

  const MetricCard = ({ metric, value, change, trend, icon: Icon }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{metric}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">
          {typeof value === 'number' && value > 1000 
            ? value.toLocaleString('pt-BR') 
            : value}
          {metric.includes('Taxa') || metric.includes('LTV') ? '%' : ''}
        </div>
        <p className={`text-xs flex items-center ${
          trend === 'up' ? 'text-green-600' : 'text-red-600'
        }`}>
          {trend === 'up' ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
          {Math.abs(change)}% em relação ao período anterior
        </p>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">{t('detailed_reports')}</h1>
          <p className="text-muted-foreground">
            Análise completa de performance e métricas de negócio
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Selecionar período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Últimos 7 dias</SelectItem>
              <SelectItem value="30d">Últimos 30 dias</SelectItem>
              <SelectItem value="90d">Últimos 90 dias</SelectItem>
              <SelectItem value="1y">Último ano</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="outline" 
            onClick={() => handleExportData('complete')}
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            {t('export_data')}
          </Button>
        </div>
      </div>

      {/* Métricas Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {customerMetrics.map((metric, index) => (
          <MetricCard
            key={index}
            metric={metric.metric}
            value={metric.value}
            change={metric.change}
            trend={metric.trend}
            icon={index === 0 ? Users : index === 1 ? Activity : index === 2 ? TrendingUp : DollarSign}
          />
        ))}
      </div>

      {/* Tabs de Relatórios */}
      <Tabs defaultValue="revenue" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="revenue">{t('revenue_analytics')}</TabsTrigger>
          <TabsTrigger value="subscriptions">{t('subscription_metrics')}</TabsTrigger>
          <TabsTrigger value="customers">{t('customer_insights')}</TabsTrigger>
          <TabsTrigger value="churn">Análise de Churn</TabsTrigger>
        </TabsList>

        {/* Análise de Receita */}
        <TabsContent value="revenue" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Receita Mensal
                </CardTitle>
                <CardDescription>
                  Evolução da receita ao longo do tempo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => [`R$ ${value.toLocaleString()}`, 'Receita']}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="revenue" 
                      stroke="#8884d8" 
                      fill="#8884d8" 
                      fillOpacity={0.3}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Assinaturas vs Churn
                </CardTitle>
                <CardDescription>
                  Comparação entre novas assinaturas e cancelamentos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="subscriptions" 
                      stroke="#82ca9d" 
                      name="Assinaturas"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="churn" 
                      stroke="#ff7c7c" 
                      name="Churn"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Métricas de Assinatura */}
        <TabsContent value="subscriptions" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChartIcon className="h-5 w-5" />
                  Distribuição de Planos
                </CardTitle>
                <CardDescription>
                  Percentual de assinantes por plano
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={planDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {planDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Métricas de Performance</CardTitle>
                <CardDescription>
                  Indicadores chave de performance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">MRR (Monthly Recurring Revenue)</span>
                  <span className="text-lg font-bold text-green-600">R$ 67.000</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">ARR (Annual Recurring Revenue)</span>
                  <span className="text-lg font-bold text-blue-600">R$ 804.000</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">ARPU (Average Revenue Per User)</span>
                  <span className="text-lg font-bold">R$ 300</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Taxa de Conversão</span>
                  <span className="text-lg font-bold text-purple-600">12.5%</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Insights de Clientes */}
        <TabsContent value="customers" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Crescimento de Clientes</CardTitle>
                <CardDescription>
                  Evolução da base de clientes ao longo do tempo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="subscriptions" 
                      stroke="#82ca9d" 
                      fill="#82ca9d" 
                      fillOpacity={0.3}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Segmentação de Clientes</CardTitle>
                <CardDescription>
                  Distribuição por tipo de cliente
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Farmácias Independentes</span>
                    <span className="text-sm font-medium">65%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '65%' }}></div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Redes Pequenas</span>
                    <span className="text-sm font-medium">25%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: '25%' }}></div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Grandes Redes</span>
                    <span className="text-sm font-medium">10%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-purple-600 h-2 rounded-full" style={{ width: '10%' }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Análise de Churn */}
        <TabsContent value="churn" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Motivos de Cancelamento</CardTitle>
                <CardDescription>
                  Principais razões para cancelamento de assinaturas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={mockChurnAnalysis} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="reason" type="category" width={120} />
                    <Tooltip formatter={(value) => [`${value}%`, 'Percentual']} />
                    <Bar dataKey="percentage" fill="#ff7c7c" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Ações de Retenção</CardTitle>
                <CardDescription>
                  Estratégias para reduzir churn
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900">Programa de Desconto</h4>
                  <p className="text-sm text-blue-700">
                    Oferecer 20% de desconto para clientes em risco
                  </p>
                  <div className="mt-2 text-xs text-blue-600">
                    Efetividade: 65% de retenção
                  </div>
                </div>
                
                <div className="p-4 bg-green-50 rounded-lg">
                  <h4 className="font-medium text-green-900">Suporte Proativo</h4>
                  <p className="text-sm text-green-700">
                    Contato direto com clientes insatisfeitos
                  </p>
                  <div className="mt-2 text-xs text-green-600">
                    Efetividade: 45% de retenção
                  </div>
                </div>
                
                <div className="p-4 bg-purple-50 rounded-lg">
                  <h4 className="font-medium text-purple-900">Upgrade de Funcionalidades</h4>
                  <p className="text-sm text-purple-700">
                    Acesso temporário a recursos premium
                  </p>
                  <div className="mt-2 text-xs text-purple-600">
                    Efetividade: 55% de retenção
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

