import axios from 'axios';

// Configuração base da API
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';

// Instância do axios com configurações padrão
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor para adicionar token de autenticação
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Interceptor para tratar respostas e erros
api.interceptors.response.use(
  (response) => {
    return response.data;
  },
  async (error) => {
    const originalRequest = error.config;

    // Se o token expirou, tenta renovar
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        const refreshToken = localStorage.getItem('refreshToken');
        if (refreshToken) {
          const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
            refreshToken,
          });
          
          const { accessToken } = response.data.data;
          localStorage.setItem('accessToken', accessToken);
          
          // Retry da requisição original
          originalRequest.headers.Authorization = `Bearer ${accessToken}`;
          return api(originalRequest);
        }
      } catch (refreshError) {
        // Se falhou ao renovar, redireciona para login
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// Serviços de autenticação
export const authService = {
  login: async (email, password) => {
    const response = await api.post('/auth/login', { email, password });
    
    if (response.success && response.data) {
      localStorage.setItem('accessToken', response.data.accessToken);
      localStorage.setItem('refreshToken', response.data.refreshToken);
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    
    return response;
  },

  logout: async () => {
    try {
      await api.post('/auth/logout');
    } catch (error) {
      console.error('Erro ao fazer logout:', error);
    } finally {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      localStorage.removeItem('user');
    }
  },

  getCurrentUser: () => {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  },

  isAuthenticated: () => {
    return !!localStorage.getItem('accessToken');
  },
};

// Serviços do Stripe
export const stripeService = {
  getPlans: async () => {
    return await api.get('/stripe/plans');
  },

  getPlan: async (planId) => {
    return await api.get(`/stripe/plans/${planId}`);
  },

  createCheckoutSession: async (planId, customerEmail, successUrl, cancelUrl) => {
    return await api.post('/stripe/create-checkout-session', {
      planId,
      customerEmail,
      successUrl,
      cancelUrl,
    });
  },

  getSubscription: async (subscriptionId) => {
    return await api.get(`/stripe/subscription/${subscriptionId}`);
  },

  cancelSubscription: async (subscriptionId) => {
    return await api.post(`/stripe/subscription/${subscriptionId}/cancel`);
  },

  updateSubscription: async (subscriptionId, newPlanId) => {
    return await api.post(`/stripe/subscription/${subscriptionId}/update`, {
      newPlanId,
    });
  },
};

// Serviços de assinatura
export const subscriptionService = {
  getUserSubscription: async () => {
    return await api.get('/subscription/current');
  },

  getSubscriptionHistory: async () => {
    return await api.get('/subscription/history');
  },

  getBillingHistory: async () => {
    return await api.get('/subscription/billing-history');
  },
};

// Serviços de relatórios
export const reportsService = {
  getDashboardMetrics: async () => {
    return await api.get('/reports/dashboard-metrics');
  },

  getRevenueAnalytics: async (startDate, endDate) => {
    return await api.get('/reports/revenue-analytics', {
      params: { startDate, endDate },
    });
  },

  getSubscriptionMetrics: async (period = '30d') => {
    return await api.get('/reports/subscription-metrics', {
      params: { period },
    });
  },

  getCustomerInsights: async () => {
    return await api.get('/reports/customer-insights');
  },

  exportData: async (reportType, format = 'csv') => {
    const response = await api.get(`/reports/export/${reportType}`, {
      params: { format },
      responseType: 'blob',
    });
    
    // Criar download do arquivo
    const url = window.URL.createObjectURL(new Blob([response]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${reportType}_${new Date().toISOString().split('T')[0]}.${format}`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  },
};

// Serviços de usuário
export const userService = {
  getProfile: async () => {
    return await api.get('/users/profile');
  },

  updateProfile: async (profileData) => {
    return await api.put('/users/profile', profileData);
  },

  changePassword: async (currentPassword, newPassword) => {
    return await api.post('/users/change-password', {
      currentPassword,
      newPassword,
    });
  },
};

// Serviços de integrações
export const integrationsService = {
  // ANVISA
  searchAnvisaProduct: async (codigo) => {
    return await api.get(`/integrations/anvisa/product/${codigo}`);
  },

  getAnvisaAlerts: async () => {
    return await api.get('/integrations/anvisa/alerts');
  },

  // Receita Federal
  validateCNPJ: async (cnpj) => {
    return await api.get(`/integrations/receita-federal/cnpj/${cnpj}`);
  },

  validateCPF: async (cpf) => {
    return await api.get(`/integrations/receita-federal/cpf/${cpf}`);
  },

  // SERASA
  getSerasaScore: async (documento, tipo) => {
    return await api.get(`/integrations/serasa/score-${tipo}/${documento}`);
  },

  // SEFAZ
  consultarNFe: async (chaveAcesso) => {
    return await api.get(`/integrations/sefaz/nfe/${chaveAcesso}`);
  },
};

export default api;

