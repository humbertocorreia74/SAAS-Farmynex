import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { notificationService } from './api';

// Configurar comportamento das notificações
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export interface NotificationData {
  id: string;
  title: string;
  body: string;
  data?: any;
  timestamp: string;
  read: boolean;
}

class NotificationManager {
  private expoPushToken: string | null = null;
  private notificationListener: any = null;
  private responseListener: any = null;

  async initialize() {
    try {
      // Registrar para push notifications
      await this.registerForPushNotifications();
      
      // Configurar listeners
      this.setupNotificationListeners();
      
      // Sincronizar com o servidor
      if (this.expoPushToken) {
        await this.registerTokenWithServer();
      }
    } catch (error) {
      console.error('Erro ao inicializar notificações:', error);
    }
  }

  async registerForPushNotifications() {
    if (!Device.isDevice) {
      console.warn('Push notifications só funcionam em dispositivos físicos');
      return;
    }

    // Verificar permissões existentes
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    // Solicitar permissões se necessário
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      console.warn('Permissão para notificações negada');
      return;
    }

    // Obter token do Expo
    try {
      const token = await Notifications.getExpoPushTokenAsync({
        projectId: 'your-expo-project-id', // Substitua pelo seu project ID
      });
      
      this.expoPushToken = token.data;
      await AsyncStorage.setItem('expoPushToken', token.data);
      
      console.log('Token de push notification:', token.data);
    } catch (error) {
      console.error('Erro ao obter token de push:', error);
    }

    // Configurações específicas do Android
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'Farmynex',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#2563eb',
        sound: 'default',
      });
    }
  }

  setupNotificationListeners() {
    // Listener para notificações recebidas
    this.notificationListener = Notifications.addNotificationReceivedListener(
      (notification) => {
        console.log('Notificação recebida:', notification);
        this.handleNotificationReceived(notification);
      }
    );

    // Listener para quando o usuário toca na notificação
    this.responseListener = Notifications.addNotificationResponseReceivedListener(
      (response) => {
        console.log('Notificação tocada:', response);
        this.handleNotificationResponse(response);
      }
    );
  }

  async registerTokenWithServer() {
    if (!this.expoPushToken) return;

    try {
      await notificationService.registerForPushNotifications(this.expoPushToken);
      console.log('Token registrado no servidor');
    } catch (error) {
      console.error('Erro ao registrar token no servidor:', error);
    }
  }

  async handleNotificationReceived(notification: Notifications.Notification) {
    // Salvar notificação localmente
    try {
      const storedNotifications = await AsyncStorage.getItem('notifications');
      const notifications: NotificationData[] = storedNotifications 
        ? JSON.parse(storedNotifications) 
        : [];

      const newNotification: NotificationData = {
        id: notification.request.identifier,
        title: notification.request.content.title || '',
        body: notification.request.content.body || '',
        data: notification.request.content.data,
        timestamp: new Date().toISOString(),
        read: false,
      };

      notifications.unshift(newNotification);
      
      // Manter apenas as últimas 100 notificações
      if (notifications.length > 100) {
        notifications.splice(100);
      }

      await AsyncStorage.setItem('notifications', JSON.stringify(notifications));
    } catch (error) {
      console.error('Erro ao salvar notificação:', error);
    }
  }

  handleNotificationResponse(response: Notifications.NotificationResponse) {
    const data = response.notification.request.content.data;
    
    // Navegar baseado no tipo de notificação
    if (data?.type) {
      switch (data.type) {
        case 'product_alert':
          // Navegar para detalhes do produto
          break;
        case 'stock_low':
          // Navegar para estoque
          break;
        case 'sale_completed':
          // Navegar para vendas
          break;
        default:
          // Navegar para lista de notificações
          break;
      }
    }
  }

  async scheduleLocalNotification(
    title: string,
    body: string,
    data?: any,
    trigger?: Notifications.NotificationTriggerInput
  ) {
    try {
      const identifier = await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
          data,
          sound: 'default',
        },
        trigger: trigger || null,
      });
      
      return identifier;
    } catch (error) {
      console.error('Erro ao agendar notificação local:', error);
      return null;
    }
  }

  async getStoredNotifications(): Promise<NotificationData[]> {
    try {
      const storedNotifications = await AsyncStorage.getItem('notifications');
      return storedNotifications ? JSON.parse(storedNotifications) : [];
    } catch (error) {
      console.error('Erro ao buscar notificações:', error);
      return [];
    }
  }

  async markNotificationAsRead(notificationId: string) {
    try {
      const notifications = await this.getStoredNotifications();
      const updatedNotifications = notifications.map(notification =>
        notification.id === notificationId
          ? { ...notification, read: true }
          : notification
      );
      
      await AsyncStorage.setItem('notifications', JSON.stringify(updatedNotifications));
      
      // Marcar como lida no servidor também
      try {
        await notificationService.markAsRead(notificationId);
      } catch (error) {
        console.error('Erro ao marcar como lida no servidor:', error);
      }
    } catch (error) {
      console.error('Erro ao marcar notificação como lida:', error);
    }
  }

  async clearAllNotifications() {
    try {
      await AsyncStorage.removeItem('notifications');
      await Notifications.dismissAllNotificationsAsync();
    } catch (error) {
      console.error('Erro ao limpar notificações:', error);
    }
  }

  async getBadgeCount(): Promise<number> {
    try {
      const notifications = await this.getStoredNotifications();
      return notifications.filter(n => !n.read).length;
    } catch (error) {
      console.error('Erro ao obter contagem de badge:', error);
      return 0;
    }
  }

  async updateBadge() {
    try {
      const count = await this.getBadgeCount();
      await Notifications.setBadgeCountAsync(count);
    } catch (error) {
      console.error('Erro ao atualizar badge:', error);
    }
  }

  cleanup() {
    if (this.notificationListener) {
      Notifications.removeNotificationSubscription(this.notificationListener);
    }
    if (this.responseListener) {
      Notifications.removeNotificationSubscription(this.responseListener);
    }
  }

  // Métodos para diferentes tipos de notificações
  async notifyLowStock(productName: string, currentStock: number) {
    return await this.scheduleLocalNotification(
      'Estoque Baixo',
      `${productName} tem apenas ${currentStock} unidades em estoque`,
      { type: 'stock_low', productName, currentStock }
    );
  }

  async notifyProductExpiring(productName: string, expiryDate: string) {
    return await this.scheduleLocalNotification(
      'Produto Vencendo',
      `${productName} vence em ${expiryDate}`,
      { type: 'product_expiring', productName, expiryDate }
    );
  }

  async notifySaleCompleted(saleId: string, total: number) {
    return await this.scheduleLocalNotification(
      'Venda Concluída',
      `Venda #${saleId} finalizada - Total: R$ ${total.toFixed(2)}`,
      { type: 'sale_completed', saleId, total }
    );
  }

  async notifySystemUpdate(message: string) {
    return await this.scheduleLocalNotification(
      'Atualização do Sistema',
      message,
      { type: 'system_update' }
    );
  }
}

// Instância singleton
export const notificationManager = new NotificationManager();

// Funções de conveniência
export const initializeNotifications = () => notificationManager.initialize();
export const scheduleNotification = (title: string, body: string, data?: any) =>
  notificationManager.scheduleLocalNotification(title, body, data);
export const getNotifications = () => notificationManager.getStoredNotifications();
export const markAsRead = (id: string) => notificationManager.markNotificationAsRead(id);
export const clearNotifications = () => notificationManager.clearAllNotifications();
export const updateBadgeCount = () => notificationManager.updateBadge();

export default notificationManager;

