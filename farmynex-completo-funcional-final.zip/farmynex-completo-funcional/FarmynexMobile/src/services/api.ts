import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Configuração base da API
const API_BASE_URL = __DEV__ 
  ? 'http://localhost:3000' 
  : 'https://api.farmynex.com';

// Instância do axios com configurações padrão
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor para adicionar token de autenticação
api.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem('accessToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Interceptor para tratar respostas e erros
api.interceptors.response.use(
  (response) => {
    return response.data;
  },
  async (error) => {
    const originalRequest = error.config;

    // Se o token expirou, tenta renovar
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        const refreshToken = await AsyncStorage.getItem('refreshToken');
        if (refreshToken) {
          const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
            refreshToken,
          });
          
          const { accessToken } = response.data.data;
          await AsyncStorage.setItem('accessToken', accessToken);
          
          // Retry da requisição original
          originalRequest.headers.Authorization = `Bearer ${accessToken}`;
          return api(originalRequest);
        }
      } catch (refreshError) {
        // Se falhou ao renovar, limpa tokens
        await AsyncStorage.multiRemove(['accessToken', 'refreshToken', 'user']);
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// Serviços de autenticação
export const authService = {
  login: async (email: string, password: string) => {
    const response = await api.post('/auth/mobile/login', { email, password });
    
    if (response.success && response.data) {
      await AsyncStorage.setItem('accessToken', response.data.accessToken);
      await AsyncStorage.setItem('refreshToken', response.data.refreshToken);
      await AsyncStorage.setItem('user', JSON.stringify(response.data.user));
    }
    
    return response;
  },

  logout: async () => {
    try {
      await api.post('/auth/mobile/logout');
    } catch (error) {
      console.error('Erro ao fazer logout:', error);
    } finally {
      await AsyncStorage.multiRemove(['accessToken', 'refreshToken', 'user']);
    }
  },

  getCurrentUser: async () => {
    const user = await AsyncStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  },

  isAuthenticated: async () => {
    const token = await AsyncStorage.getItem('accessToken');
    return !!token;
  },

  registerDevice: async (deviceToken: string, deviceInfo: any) => {
    return await api.post('/mobile/device/register', {
      deviceToken,
      deviceInfo,
    });
  },
};

// Serviços de sincronização
export const syncService = {
  syncData: async (lastSyncTimestamp?: string) => {
    return await api.post('/mobile/sync', {
      lastSyncTimestamp,
    });
  },

  uploadOfflineData: async (offlineData: any[]) => {
    return await api.post('/mobile/sync/upload', {
      data: offlineData,
    });
  },

  getUpdates: async (lastSyncTimestamp: string) => {
    return await api.get('/mobile/sync/updates', {
      params: { since: lastSyncTimestamp },
    });
  },
};

// Serviços de produtos
export const productService = {
  searchProduct: async (barcode: string) => {
    return await api.get(`/mobile/products/search/${barcode}`);
  },

  getProductDetails: async (productId: string) => {
    return await api.get(`/mobile/products/${productId}`);
  },

  updateStock: async (productId: string, quantity: number) => {
    return await api.post(`/mobile/products/${productId}/stock`, {
      quantity,
    });
  },

  addProduct: async (productData: any) => {
    return await api.post('/mobile/products', productData);
  },
};

// Serviços de vendas
export const salesService = {
  createSale: async (saleData: any) => {
    return await api.post('/mobile/sales', saleData);
  },

  getSales: async (page = 1, limit = 20) => {
    return await api.get('/mobile/sales', {
      params: { page, limit },
    });
  },

  getSaleDetails: async (saleId: string) => {
    return await api.get(`/mobile/sales/${saleId}`);
  },
};

// Serviços de integrações
export const integrationsService = {
  validateProduct: async (barcode: string) => {
    return await api.get(`/mobile/integrations/anvisa/validate/${barcode}`);
  },

  checkControlledMedicine: async (barcode: string) => {
    return await api.get(`/mobile/integrations/sngpc/check/${barcode}`);
  },

  validateCustomer: async (document: string) => {
    return await api.get(`/mobile/integrations/serasa/validate/${document}`);
  },
};

// Serviços de notificações
export const notificationService = {
  registerForPushNotifications: async (expoPushToken: string) => {
    return await api.post('/mobile/notifications/register', {
      expoPushToken,
    });
  },

  getNotifications: async (page = 1, limit = 20) => {
    return await api.get('/mobile/notifications', {
      params: { page, limit },
    });
  },

  markAsRead: async (notificationId: string) => {
    return await api.post(`/mobile/notifications/${notificationId}/read`);
  },
};

export default api;

