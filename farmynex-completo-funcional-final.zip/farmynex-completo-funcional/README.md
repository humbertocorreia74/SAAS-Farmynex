# 🏥 Farmynex - Sistema Completo de Gestão Farmacêutica

## 📋 Visão Geral

O **Farmynex** é um sistema SaaS completo e funcional para gestão de farmácias, desenvolvido com as mais modernas tecnologias e integrações específicas do setor farmacêutico brasileiro.

## 🚀 Tecnologias Utilizadas

### Backend (NestJS)
- **Framework**: NestJS 10.x
- **Banco de Dados**: SQLite (desenvolvimento) / PostgreSQL (produção)
- **ORM**: TypeORM
- **Autenticação**: JWT + Passport
- **Documentação**: Swagger/OpenAPI
- **Pagamentos**: Stripe
- **Validação**: Class Validator

### Frontend (React + Vite)
- **Framework**: React 19.x
- **Build Tool**: Vite 6.x
- **UI Components**: Radix UI + Tailwind CSS
- **Gerenciamento de Estado**: TanStack Query
- **Roteamento**: React Router DOM
- **Formulários**: React Hook Form + Zod

### Mobile (React Native)
- **Framework**: React Native + Expo
- **Navegação**: React Navigation
- **Estado**: Context API

## 🏗️ Arquitetura do Sistema

```
farmynex-completo-funcional/
├── backend/                    # API NestJS
│   ├── src/
│   │   ├── auth/              # Autenticação e autorização
│   │   ├── users/             # Gestão de usuários
│   │   ├── products/          # Gestão de produtos
│   │   ├── campaigns/         # Campanhas de marketing
│   │   ├── analytics/         # Analytics e relatórios
│   │   ├── stripe/            # Integração Stripe
│   │   ├── subscription/      # Sistema de assinaturas
│   │   ├── integrations/      # Integrações externas
│   │   │   ├── anvisa/        # Integração ANVISA
│   │   │   ├── receita-federal/ # Integração Receita Federal
│   │   │   ├── sngpc/         # Sistema Nacional de Gerenciamento de Produtos Controlados
│   │   │   ├── sefaz/         # Integração SEFAZ
│   │   │   └── ...
│   │   ├── branding/          # Sistema de branding personalizado
│   │   ├── equipment/         # Gestão de equipamentos farmacêuticos
│   │   └── mobile/            # APIs específicas para mobile
│   ├── package.json
│   └── .env
├── farmynex-dashboard/        # Frontend React
│   ├── src/
│   │   ├── components/        # Componentes reutilizáveis
│   │   ├── pages/            # Páginas da aplicação
│   │   ├── services/         # Serviços de API
│   │   └── utils/            # Utilitários
│   ├── package.json
│   └── vite.config.js
├── FarmynexMobile/           # App React Native
│   ├── src/
│   │   ├── components/       # Componentes mobile
│   │   ├── screens/          # Telas do app
│   │   └── services/         # Serviços mobile
│   ├── package.json
│   └── app.json
└── docs/                     # Documentação
```

## ⚡ Instalação e Execução

### Pré-requisitos
- Node.js 18+ 
- npm ou yarn
- SQLite (desenvolvimento)
- PostgreSQL (produção)

### 1. Backend (API)
```bash
cd backend
npm install
cp .env.example .env
# Configurar variáveis de ambiente no .env
npm run start:dev
```

### 2. Frontend (Dashboard)
```bash
cd farmynex-dashboard
npm install
npm run dev
```

### 3. Mobile (React Native)
```bash
cd FarmynexMobile
npm install
npx expo start
```

## 🔧 Configuração

### Variáveis de Ambiente (.env)
```env
# Banco de Dados
DATABASE_URL=sqlite:farmynex.db

# JWT
JWT_SECRET=seu-jwt-secret-super-seguro

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Integrações
ANVISA_API_KEY=sua-chave-anvisa
RECEITA_FEDERAL_CERT_PATH=/path/to/cert.p12
SNGPC_USERNAME=seu-usuario-sngpc
SNGPC_PASSWORD=sua-senha-sngpc
```

## 🎯 Funcionalidades Principais

### ✅ Sistema de Autenticação
- Login/Registro com JWT
- Controle de permissões por função
- Autenticação multi-fator (2FA)

### ✅ Gestão de Produtos
- Cadastro completo de medicamentos
- Controle de estoque
- Alertas de vencimento
- Rastreabilidade de lotes

### ✅ Sistema de Branding Personalizado
- Logomarca personalizada nos dashboards
- Dados fiscais da farmácia
- Cores e temas customizáveis
- Posicionamento flexível de elementos

### ✅ Integrações Farmacêuticas
- **ANVISA**: Consulta de medicamentos e notificações
- **Receita Federal**: Validação de CNPJ e dados fiscais
- **SNGPC**: Controle de medicamentos controlados
- **SEFAZ**: Emissão de notas fiscais
- **Farmácia Popular**: Integração com programa governamental

### ✅ Equipamentos Farmacêuticos
- **Impressoras**: Térmicas e fiscais
- **Balanças**: Integração para pesagem
- **Câmara Fria**: Monitoramento de temperatura
- **Leitores de Código**: Automação de entrada
- **Terminais POS**: Integração com pagamentos

### ✅ Sistema de Assinaturas (Stripe)
- Planos flexíveis (Starter, Professional, Enterprise)
- Cobrança recorrente automática
- Gestão de upgrades/downgrades
- Webhooks para sincronização

### ✅ Analytics e Relatórios
- Dashboard executivo
- Relatórios de vendas
- Análise de estoque
- Métricas de performance

### ✅ App Mobile Completo
- Gestão de estoque mobile
- Vendas offline
- Sincronização automática
- Notificações push

## 🔌 APIs e Integrações

### Endpoints Principais

#### Autenticação
```
POST /api/auth/login
POST /api/auth/register
POST /api/auth/refresh
```

#### Produtos
```
GET    /api/products
POST   /api/products
PUT    /api/products/:id
DELETE /api/products/:id
```

#### Branding
```
GET  /api/branding
POST /api/branding
PUT  /api/branding
GET  /api/branding/dashboard
```

#### Equipamentos
```
GET  /api/equipment
POST /api/equipment
PUT  /api/equipment/:id/status
POST /api/equipment/:id/test
```

#### Integrações
```
GET  /api/integrations/anvisa/product/:code
POST /api/integrations/sngpc/report
GET  /api/integrations/receita-federal/cnpj/:cnpj
```

### Documentação da API
Acesse: `http://localhost:3000/api/docs`

## 🛡️ Segurança

- Autenticação JWT com refresh tokens
- Validação de entrada com Class Validator
- Rate limiting para APIs
- Sanitização de dados
- CORS configurado
- Logs de auditoria

## 📱 Recursos Mobile

- Interface nativa com React Native
- Funcionalidade offline
- Sincronização em background
- Câmera para leitura de códigos
- Notificações push
- Biometria para autenticação

## 🔄 Integrações Específicas

### ANVISA
- Consulta de medicamentos por código
- Verificação de registros
- Notificações de recalls
- Validação de lotes

### SNGPC (Medicamentos Controlados)
- Relatórios obrigatórios
- Controle de receitas
- Rastreabilidade completa
- Alertas de conformidade

### Receita Federal
- Validação de CNPJ
- Consulta de situação fiscal
- Integração com NFe
- Dados cadastrais

### SEFAZ
- Emissão de NFe/NFCe
- Consulta de status
- Cancelamento de notas
- Contingência offline

## 📊 Planos de Assinatura

### Starter (R$ 99/mês)
- Até 1.000 produtos
- 1 usuário
- Relatórios básicos
- Suporte por email

### Professional (R$ 299/mês)
- Até 10.000 produtos
- 5 usuários
- Relatórios avançados
- Integrações básicas
- Suporte prioritário

### Enterprise (R$ 599/mês)
- Produtos ilimitados
- Usuários ilimitados
- Todas as integrações
- API completa
- Suporte 24/7

## 🚀 Deploy

### Desenvolvimento
```bash
# Backend
npm run start:dev

# Frontend
npm run dev

# Mobile
npx expo start
```

### Produção
```bash
# Build
npm run build

# Docker
docker-compose up -d

# PM2
pm2 start ecosystem.config.js
```

## 📞 Suporte

- **Email**: suporte@farmynex.com.br
- **Documentação**: [docs.farmynex.com.br](https://docs.farmynex.com.br)
- **Status**: [status.farmynex.com.br](https://status.farmynex.com.br)

## 📄 Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

---

**Desenvolvido com ❤️ pela equipe Farmynex**

*Sistema completo e funcional para gestão farmacêutica no Brasil*

