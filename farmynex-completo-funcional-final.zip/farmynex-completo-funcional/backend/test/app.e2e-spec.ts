import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';

describe('Farmynex API (e2e)', () => {
  let app: INestApplication;
  let authToken: string;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  describe('Authentication', () => {
    it('/api/auth/register (POST)', () => {
      return request(app.getHttpServer())
        .post('/api/auth/register')
        .send({
          firstName: 'Test',
          lastName: 'User',
          email: 'test@farmynex.com',
          password: 'Test123!',
          role: 'employee',
        })
        .expect(201)
        .expect((res) => {
          expect(res.body).toHaveProperty('access_token');
          expect(res.body).toHaveProperty('user');
          expect(res.body.user.email).toBe('test@farmynex.com');
        });
    });

    it('/api/auth/login (POST)', async () => {
      // Primeiro registrar um usuário
      await request(app.getHttpServer())
        .post('/api/auth/register')
        .send({
          firstName: 'Login',
          lastName: 'Test',
          email: 'login@farmynex.com',
          password: 'Test123!',
          role: 'employee',
        });

      // Depois fazer login
      return request(app.getHttpServer())
        .post('/api/auth/login')
        .send({
          email: 'login@farmynex.com',
          password: 'Test123!',
        })
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('access_token');
          expect(res.body).toHaveProperty('user');
          authToken = res.body.access_token;
        });
    });

    it('/api/auth/profile (GET) - should require authentication', () => {
      return request(app.getHttpServer())
        .get('/api/auth/profile')
        .expect(401);
    });

    it('/api/auth/profile (GET) - should return user profile when authenticated', async () => {
      // Registrar e fazer login
      const registerResponse = await request(app.getHttpServer())
        .post('/api/auth/register')
        .send({
          firstName: 'Profile',
          lastName: 'Test',
          email: 'profile@farmynex.com',
          password: 'Test123!',
          role: 'employee',
        });

      const token = registerResponse.body.access_token;

      return request(app.getHttpServer())
        .get('/api/auth/profile')
        .set('Authorization', `Bearer ${token}`)
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('id');
          expect(res.body).toHaveProperty('email');
          expect(res.body.email).toBe('profile@farmynex.com');
        });
    });
  });

  describe('Products', () => {
    let authToken: string;

    beforeEach(async () => {
      // Registrar usuário para testes
      const response = await request(app.getHttpServer())
        .post('/api/auth/register')
        .send({
          firstName: 'Product',
          lastName: 'Tester',
          email: 'products@farmynex.com',
          password: 'Test123!',
          role: 'pharmacist',
        });
      
      authToken = response.body.access_token;
    });

    it('/api/products (POST) - should create a product', () => {
      return request(app.getHttpServer())
        .post('/api/products')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Paracetamol 500mg',
          description: 'Analgésico e antitérmico',
          barcode: '7891234567890',
          category: 'medication',
          price: 15.90,
          stock: 100,
          minStock: 10,
        })
        .expect(201)
        .expect((res) => {
          expect(res.body).toHaveProperty('id');
          expect(res.body.name).toBe('Paracetamol 500mg');
          expect(res.body.barcode).toBe('7891234567890');
        });
    });

    it('/api/products (GET) - should list products', async () => {
      // Criar um produto primeiro
      await request(app.getHttpServer())
        .post('/api/products')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Dipirona 500mg',
          description: 'Analgésico',
          barcode: '7891234567891',
          category: 'medication',
          price: 12.50,
          stock: 50,
        });

      return request(app.getHttpServer())
        .get('/api/products')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200)
        .expect((res) => {
          expect(Array.isArray(res.body.data)).toBe(true);
          expect(res.body).toHaveProperty('total');
          expect(res.body).toHaveProperty('page');
        });
    });

    it('/api/products/barcode/:barcode (GET) - should find product by barcode', async () => {
      // Criar um produto primeiro
      await request(app.getHttpServer())
        .post('/api/products')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Ibuprofeno 600mg',
          description: 'Anti-inflamatório',
          barcode: '7891234567892',
          category: 'medication',
          price: 18.90,
          stock: 75,
        });

      return request(app.getHttpServer())
        .get('/api/products/barcode/7891234567892')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200)
        .expect((res) => {
          expect(res.body.name).toBe('Ibuprofeno 600mg');
          expect(res.body.barcode).toBe('7891234567892');
        });
    });
  });

  describe('Leads', () => {
    let authToken: string;

    beforeEach(async () => {
      const response = await request(app.getHttpServer())
        .post('/api/auth/register')
        .send({
          firstName: 'Lead',
          lastName: 'Tester',
          email: 'leads@farmynex.com',
          password: 'Test123!',
          role: 'pharmacist',
        });
      
      authToken = response.body.access_token;
    });

    it('/api/leads (POST) - should create a lead', () => {
      return request(app.getHttpServer())
        .post('/api/leads')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          firstName: 'João',
          lastName: 'Silva',
          email: 'joao.silva@email.com',
          phone: '(11) 99999-9999',
          company: 'Farmácia Silva',
          source: 'website',
        })
        .expect(201)
        .expect((res) => {
          expect(res.body).toHaveProperty('id');
          expect(res.body.firstName).toBe('João');
          expect(res.body.email).toBe('joao.silva@email.com');
          expect(res.body).toHaveProperty('score');
        });
    });

    it('/api/leads (GET) - should list leads', async () => {
      // Criar um lead primeiro
      await request(app.getHttpServer())
        .post('/api/leads')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          firstName: 'Maria',
          lastName: 'Santos',
          email: 'maria.santos@email.com',
          phone: '(11) 88888-8888',
          source: 'social_media',
        });

      return request(app.getHttpServer())
        .get('/api/leads')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200)
        .expect((res) => {
          expect(Array.isArray(res.body.data)).toBe(true);
          expect(res.body).toHaveProperty('total');
        });
    });
  });

  describe('Analytics', () => {
    let authToken: string;

    beforeEach(async () => {
      const response = await request(app.getHttpServer())
        .post('/api/auth/register')
        .send({
          firstName: 'Analytics',
          lastName: 'Tester',
          email: 'analytics@farmynex.com',
          password: 'Test123!',
          role: 'admin',
        });
      
      authToken = response.body.access_token;
    });

    it('/api/analytics/dashboard (GET) - should return dashboard data', () => {
      return request(app.getHttpServer())
        .get('/api/analytics/dashboard')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('totalUsers');
          expect(res.body).toHaveProperty('totalProducts');
          expect(res.body).toHaveProperty('totalLeads');
          expect(res.body).toHaveProperty('activeCampaigns');
        });
    });

    it('/api/analytics/kpis (GET) - should return KPIs', () => {
      return request(app.getHttpServer())
        .get('/api/analytics/kpis')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200)
        .expect((res) => {
          expect(Array.isArray(res.body)).toBe(true);
        });
    });
  });
});

