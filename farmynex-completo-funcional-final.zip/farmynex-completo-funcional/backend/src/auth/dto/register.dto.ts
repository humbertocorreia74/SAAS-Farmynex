import { ApiProperty } from '@nestjs/swagger';
import {
  IsEmail,
  IsNotEmpty,
  IsString,
  MinLength,
  IsEnum,
  IsOptional,
  IsPhoneNumber,
} from 'class-validator';
import { UserRole } from '../../users/entities/user.entity';

export class RegisterDto {
  @ApiProperty({
    description: 'Email do usuário',
    example: 'farmaceutico@farmynex.com',
  })
  @IsEmail({}, { message: 'Email deve ter um formato válido' })
  @IsNotEmpty({ message: 'Email é obrigatório' })
  email: string;

  @ApiProperty({
    description: 'Senha do usuário',
    example: 'senha123',
    minLength: 6,
  })
  @IsString({ message: 'Senha deve ser uma string' })
  @IsNotEmpty({ message: 'Senha é obrigatória' })
  @MinLength(6, { message: 'Senha deve ter pelo menos 6 caracteres' })
  password: string;

  @ApiProperty({
    description: 'Primeiro nome',
    example: 'João',
  })
  @IsString({ message: 'Primeiro nome deve ser uma string' })
  @IsNotEmpty({ message: 'Primeiro nome é obrigatório' })
  firstName: string;

  @ApiProperty({
    description: 'Último nome',
    example: 'Silva',
  })
  @IsString({ message: 'Último nome deve ser uma string' })
  @IsNotEmpty({ message: 'Último nome é obrigatório' })
  lastName: string;

  @ApiProperty({
    description: 'Telefone do usuário',
    example: '+5511999999999',
    required: false,
  })
  @IsOptional()
  @IsPhoneNumber('BR', { message: 'Telefone deve ter um formato válido' })
  phone?: string;

  @ApiProperty({
    description: 'Papel do usuário',
    enum: UserRole,
    example: UserRole.PHARMACIST,
    required: false,
  })
  @IsOptional()
  @IsEnum(UserRole, { message: 'Papel deve ser um valor válido' })
  role?: UserRole;

  @ApiProperty({
    description: 'CRF do farmacêutico',
    example: 'CRF-SP 12345',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'CRF deve ser uma string' })
  crf?: string;
}

