import { IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateSubscriptionDto {
  @ApiProperty({
    description: 'ID do novo plano',
    example: 'professional_monthly',
  })
  @IsString()
  newPlanId: string;
}

