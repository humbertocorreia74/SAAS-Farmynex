import { IsString, IsEmail, IsUrl, IsOptional, IsObject } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateCheckoutSessionDto {
  @ApiProperty({
    description: 'ID do plano selecionado',
    example: 'starter_monthly',
  })
  @IsString()
  planId: string;

  @ApiProperty({
    description: 'Email do cliente',
    example: 'cliente@farmacia.com',
  })
  @IsEmail()
  customerEmail: string;

  @ApiProperty({
    description: 'URL de redirecionamento em caso de sucesso',
    example: 'https://app.farmynex.com/success',
  })
  @IsUrl()
  successUrl: string;

  @ApiProperty({
    description: 'URL de redirecionamento em caso de cancelamento',
    example: 'https://app.farmynex.com/cancel',
  })
  @IsUrl()
  cancelUrl: string;

  @ApiProperty({
    description: 'Metadados adicionais para a sessão',
    example: { userId: '123', pharmacyId: '456' },
    required: false,
  })
  @IsOptional()
  @IsObject()
  metadata?: Record<string, string>;
}

