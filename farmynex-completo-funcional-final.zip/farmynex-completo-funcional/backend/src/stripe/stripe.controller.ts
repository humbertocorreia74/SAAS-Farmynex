import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Headers,
  RawBodyRequest,
  Req,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { StripeService } from './stripe.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CreateCheckoutSessionDto } from './dto/create-checkout-session.dto';
import { UpdateSubscriptionDto } from './dto/update-subscription.dto';

@ApiTags('stripe')
@Controller('stripe')
export class StripeController {
  constructor(private readonly stripeService: StripeService) {}

  @Get('plans')
  @ApiOperation({ summary: 'Listar todos os planos disponíveis' })
  @ApiResponse({ status: 200, description: 'Lista de planos retornada com sucesso' })
  getPlans() {
    return {
      success: true,
      data: this.stripeService.getPlans(),
    };
  }

  @Get('plans/:planId')
  @ApiOperation({ summary: 'Obter detalhes de um plano específico' })
  @ApiResponse({ status: 200, description: 'Detalhes do plano retornados com sucesso' })
  @ApiResponse({ status: 404, description: 'Plano não encontrado' })
  getPlan(@Param('planId') planId: string) {
    const plan = this.stripeService.getPlanById(planId);
    
    if (!plan) {
      return {
        success: false,
        message: 'Plano não encontrado',
      };
    }

    return {
      success: true,
      data: plan,
    };
  }

  @Post('create-checkout-session')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Criar sessão de checkout personalizada' })
  @ApiResponse({ status: 201, description: 'Sessão de checkout criada com sucesso' })
  @ApiResponse({ status: 400, description: 'Dados inválidos' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  async createCheckoutSession(@Body() createCheckoutSessionDto: CreateCheckoutSessionDto) {
    try {
      const session = await this.stripeService.createCheckoutSession(
        createCheckoutSessionDto.planId,
        createCheckoutSessionDto.customerEmail,
        createCheckoutSessionDto.successUrl,
        createCheckoutSessionDto.cancelUrl,
      );

      return {
        success: true,
        data: {
          sessionId: session.id,
          url: session.url,
        },
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Get('subscription/:subscriptionId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Obter detalhes de uma assinatura' })
  @ApiResponse({ status: 200, description: 'Detalhes da assinatura retornados com sucesso' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  @ApiResponse({ status: 404, description: 'Assinatura não encontrada' })
  async getSubscription(@Param('subscriptionId') subscriptionId: string) {
    try {
      const subscription = await this.stripeService.getSubscription(subscriptionId);
      
      return {
        success: true,
        data: subscription,
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Post('subscription/:subscriptionId/cancel')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Cancelar uma assinatura' })
  @ApiResponse({ status: 200, description: 'Assinatura cancelada com sucesso' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  @ApiResponse({ status: 404, description: 'Assinatura não encontrada' })
  async cancelSubscription(@Param('subscriptionId') subscriptionId: string) {
    try {
      const subscription = await this.stripeService.cancelSubscription(subscriptionId);
      
      return {
        success: true,
        data: subscription,
        message: 'Assinatura cancelada com sucesso',
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Post('subscription/:subscriptionId/update')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Atualizar uma assinatura (mudança de plano)' })
  @ApiResponse({ status: 200, description: 'Assinatura atualizada com sucesso' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  @ApiResponse({ status: 404, description: 'Assinatura não encontrada' })
  async updateSubscription(
    @Param('subscriptionId') subscriptionId: string,
    @Body() updateSubscriptionDto: UpdateSubscriptionDto,
  ) {
    try {
      const subscription = await this.stripeService.updateSubscription(
        subscriptionId,
        updateSubscriptionDto.newPlanId,
      );
      
      return {
        success: true,
        data: subscription,
        message: 'Assinatura atualizada com sucesso',
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Post('webhook')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Webhook do Stripe para eventos de assinatura' })
  @ApiResponse({ status: 200, description: 'Webhook processado com sucesso' })
  async handleWebhook(
    @Req() req: RawBodyRequest<Request>,
    @Headers('stripe-signature') signature: string,
  ) {
    try {
      const payload = req.rawBody.toString();
      const result = await this.stripeService.handleWebhook(payload, signature);
      
      return result;
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }
}

