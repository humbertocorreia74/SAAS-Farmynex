import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';

export interface StripeProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  interval: 'month' | 'year';
  features: string[];
  popular?: boolean;
  stripePriceId: string;
}

export interface CreateCheckoutSessionDto {
  planId: string;
  customerEmail: string;
  successUrl: string;
  cancelUrl: string;
}

export interface UpdateSubscriptionDto {
  subscriptionId: string;
  newPlanId: string;
}

@Injectable()
export class StripeService {
  private readonly logger = new Logger(StripeService.name);
  private readonly stripe: Stripe;

  // Planos disponíveis baseados no arquivo fornecido
  private readonly plans: StripeProduct[] = [
    {
      id: 'basico',
      name: 'Plano Básico',
      description: 'Ideal para farmácias pequenas',
      price: 2999, // R$ 29,99
      currency: 'brl',
      interval: 'month',
      stripePriceId: 'price_basico_monthly',
      features: [
        'Gestão de estoque básica',
        'Vendas simples',
        'Relatórios básicos',
        'Suporte por email'
      ]
    },
    {
      id: 'profissional',
      name: 'Plano Profissional',
      description: 'Para farmácias em crescimento',
      price: 5999, // R$ 59,99
      currency: 'brl',
      interval: 'month',
      stripePriceId: 'price_profissional_monthly',
      popular: true,
      features: [
        'Gestão completa de estoque',
        'Sistema de vendas avançado',
        'Relatórios detalhados',
        'Integração com fornecedores',
        'Suporte prioritário'
      ]
    },
    {
      id: 'empresarial',
      name: 'Plano Empresarial',
      description: 'Para redes de farmácias',
      price: 9999, // R$ 99,99
      currency: 'brl',
      interval: 'month',
      stripePriceId: 'price_empresarial_monthly',
      features: [
        'Gestão multi-loja',
        'Analytics avançados',
        'API completa',
        'Integrações personalizadas',
        'Suporte 24/7',
        'Treinamento incluído'
      ]
    },
    {
      id: 'anual_basico',
      name: 'Plano Básico Anual',
      description: 'Plano básico com desconto anual',
      price: 29999, // R$ 299,99 (2 meses grátis)
      currency: 'brl',
      interval: 'year',
      stripePriceId: 'price_basico_yearly',
      features: [
        'Gestão de estoque básica',
        'Vendas simples',
        'Relatórios básicos',
        'Suporte por email',
        '2 meses grátis'
      ]
    },
    {
      id: 'anual_profissional',
      name: 'Plano Profissional Anual',
      description: 'Plano profissional com desconto anual',
      price: 59999, // R$ 599,99 (2 meses grátis)
      currency: 'brl',
      interval: 'year',
      stripePriceId: 'price_profissional_yearly',
      features: [
        'Gestão completa de estoque',
        'Sistema de vendas avançado',
        'Relatórios detalhados',
        'Integração com fornecedores',
        'Suporte prioritário',
        '2 meses grátis'
      ]
    },
    {
      id: 'anual_empresarial',
      name: 'Plano Empresarial Anual',
      description: 'Plano empresarial com desconto anual',
      price: 99999, // R$ 999,99 (2 meses grátis)
      currency: 'brl',
      interval: 'year',
      stripePriceId: 'price_empresarial_yearly',
      features: [
        'Gestão multi-loja',
        'Analytics avançados',
        'API completa',
        'Integrações personalizadas',
        'Suporte 24/7',
        'Treinamento incluído',
        '2 meses grátis'
      ]
    }
  ];

  constructor(private configService: ConfigService) {
    const stripeSecretKey = this.configService.get<string>('STRIPE_SECRET_KEY') || 'sk_test_...';
    this.stripe = new Stripe(stripeSecretKey, {
      apiVersion: '2025-06-30.basil',
    });
  }

  /**
   * Obtém todos os planos disponíveis
   */
  getPlans(): StripeProduct[] {
    return this.plans;
  }

  /**
   * Obtém um plano específico por ID
   */
  getPlanById(planId: string): StripeProduct | undefined {
    return this.plans.find(plan => plan.id === planId);
  }

  /**
   * Cria uma sessão de checkout do Stripe
   */
  async createCheckoutSession(
    planId: string,
    customerEmail: string,
    successUrl: string,
    cancelUrl: string
  ): Promise<Stripe.Checkout.Session> {
    const plan = this.getPlanById(planId);
    if (!plan) {
      throw new Error(`Plano ${planId} não encontrado`);
    }

    try {
      const session = await this.stripe.checkout.sessions.create({
        payment_method_types: ['card', 'boleto'],
        line_items: [
          {
            price: plan.stripePriceId,
            quantity: 1,
          },
        ],
        mode: 'subscription',
        customer_email: customerEmail,
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: {
          planId: planId,
        },
        subscription_data: {
          metadata: {
            planId: planId,
          },
        },
      });

      this.logger.log(`Sessão de checkout criada: ${session.id} para plano: ${planId}`);
      return session;
    } catch (error) {
      this.logger.error('Erro ao criar sessão de checkout:', error);
      throw error;
    }
  }

  /**
   * Obtém informações de uma assinatura
   */
  async getSubscription(subscriptionId: string): Promise<Stripe.Subscription> {
    try {
      return await this.stripe.subscriptions.retrieve(subscriptionId);
    } catch (error) {
      this.logger.error('Erro ao obter assinatura:', error);
      throw error;
    }
  }

  /**
   * Cancela uma assinatura
   */
  async cancelSubscription(subscriptionId: string): Promise<Stripe.Subscription> {
    try {
      return await this.stripe.subscriptions.cancel(subscriptionId);
    } catch (error) {
      this.logger.error('Erro ao cancelar assinatura:', error);
      throw error;
    }
  }

  /**
   * Atualiza uma assinatura para um novo plano
   */
  async updateSubscription(
    subscriptionId: string,
    newPlanId: string
  ): Promise<Stripe.Subscription> {
    const plan = this.getPlanById(newPlanId);
    if (!plan) {
      throw new Error(`Plano ${newPlanId} não encontrado`);
    }

    try {
      const subscription = await this.stripe.subscriptions.retrieve(subscriptionId);
      
      return await this.stripe.subscriptions.update(subscriptionId, {
        items: [
          {
            id: subscription.items.data[0].id,
            price: plan.stripePriceId,
          },
        ],
        proration_behavior: 'create_prorations',
      });
    } catch (error) {
      this.logger.error('Erro ao atualizar assinatura:', error);
      throw error;
    }
  }

  /**
   * Processa webhook do Stripe
   */
  async handleWebhook(payload: string, signature: string): Promise<any> {
    const webhookSecret = this.configService.get<string>('STRIPE_WEBHOOK_SECRET');
    
    try {
      const event = this.stripe.webhooks.constructEvent(payload, signature, webhookSecret);
      
      this.logger.log(`Webhook recebido: ${event.type}`);
      
      switch (event.type) {
        case 'checkout.session.completed':
          await this.handleCheckoutCompleted(event.data.object as Stripe.Checkout.Session);
          break;
        case 'invoice.payment_succeeded':
          await this.handlePaymentSucceeded(event.data.object as Stripe.Invoice);
          break;
        case 'invoice.payment_failed':
          await this.handlePaymentFailed(event.data.object as Stripe.Invoice);
          break;
        case 'customer.subscription.updated':
          await this.handleSubscriptionUpdated(event.data.object as Stripe.Subscription);
          break;
        case 'customer.subscription.deleted':
          await this.handleSubscriptionDeleted(event.data.object as Stripe.Subscription);
          break;
        default:
          this.logger.log(`Evento não tratado: ${event.type}`);
      }
      
      return { received: true };
    } catch (error) {
      this.logger.error('Erro ao processar webhook:', error);
      throw error;
    }
  }

  private async handleCheckoutCompleted(session: Stripe.Checkout.Session): Promise<void> {
    this.logger.log(`Checkout completado: ${session.id}`);
    // Implementar lógica para ativar assinatura do usuário
  }

  private async handlePaymentSucceeded(invoice: Stripe.Invoice): Promise<void> {
    this.logger.log(`Pagamento bem-sucedido: ${invoice.id}`);
    // Implementar lógica para confirmar pagamento
  }

  private async handlePaymentFailed(invoice: Stripe.Invoice): Promise<void> {
    this.logger.log(`Falha no pagamento: ${invoice.id}`);
    // Implementar lógica para lidar com falha no pagamento
  }

  private async handleSubscriptionUpdated(subscription: Stripe.Subscription): Promise<void> {
    this.logger.log(`Assinatura atualizada: ${subscription.id}`);
    // Implementar lógica para atualizar dados da assinatura
  }

  private async handleSubscriptionDeleted(subscription: Stripe.Subscription): Promise<void> {
    this.logger.log(`Assinatura cancelada: ${subscription.id}`);
    // Implementar lógica para desativar acesso do usuário
  }

  /**
   * Obtém histórico de faturas de um cliente
   */
  async getCustomerInvoices(customerId: string): Promise<Stripe.Invoice[]> {
    try {
      const invoices = await this.stripe.invoices.list({
        customer: customerId,
        limit: 100,
      });
      
      return invoices.data;
    } catch (error) {
      this.logger.error('Erro ao obter faturas:', error);
      throw error;
    }
  }

  /**
   * Cria um portal de cobrança para o cliente
   */
  async createBillingPortalSession(
    customerId: string,
    returnUrl: string
  ): Promise<Stripe.BillingPortal.Session> {
    try {
      return await this.stripe.billingPortal.sessions.create({
        customer: customerId,
        return_url: returnUrl,
      });
    } catch (error) {
      this.logger.error('Erro ao criar portal de cobrança:', error);
      throw error;
    }
  }
}

