import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Campaign, CampaignStatus, CampaignType } from './entities/campaign.entity';
import { CreateCampaignDto } from './dto/create-campaign.dto';
import { UpdateCampaignDto } from './dto/update-campaign.dto';
import { LeadsService } from '../leads/leads.service';
import { Lead, LeadTemperature, LeadStatus } from '../leads/entities/lead.entity';

@Injectable()
export class CampaignsService {
  constructor(
    @InjectRepository(Campaign)
    private campaignsRepository: Repository<Campaign>,
    private leadsService: LeadsService,
  ) {}

  async create(createCampaignDto: CreateCampaignDto, createdBy: string): Promise<Campaign> {
    const campaign = this.campaignsRepository.create({
      ...createCampaignDto,
      createdBy,
    });

    // Calcular público-alvo
    if (createCampaignDto.targetAudience) {
      const targetCount = await this.calculateTargetAudience(createCampaignDto.targetAudience);
      campaign.targetCount = targetCount;
    }

    // Se tem agendamento, definir status como agendado
    if (createCampaignDto.scheduledAt) {
      campaign.status = CampaignStatus.SCHEDULED;
    }

    return this.campaignsRepository.save(campaign);
  }

  async findAll(filters?: {
    status?: CampaignStatus;
    type?: CampaignType;
    createdBy?: string;
    page?: number;
    limit?: number;
  }): Promise<{ campaigns: Campaign[]; total: number; page: number; totalPages: number }> {
    const page = filters?.page || 1;
    const limit = filters?.limit || 20;
    const skip = (page - 1) * limit;

    const queryBuilder = this.campaignsRepository.createQueryBuilder('campaign');

    // Filtros
    if (filters?.status) {
      queryBuilder.andWhere('campaign.status = :status', { status: filters.status });
    }

    if (filters?.type) {
      queryBuilder.andWhere('campaign.type = :type', { type: filters.type });
    }

    if (filters?.createdBy) {
      queryBuilder.andWhere('campaign.createdBy = :createdBy', { createdBy: filters.createdBy });
    }

    // Ordenação
    queryBuilder.orderBy('campaign.createdAt', 'DESC');

    // Paginação
    queryBuilder.skip(skip).take(limit);

    const [campaigns, total] = await queryBuilder.getManyAndCount();
    const totalPages = Math.ceil(total / limit);

    return {
      campaigns,
      total,
      page,
      totalPages,
    };
  }

  async findOne(id: string): Promise<Campaign> {
    const campaign = await this.campaignsRepository.findOne({ where: { id } });
    
    if (!campaign) {
      throw new NotFoundException('Campanha não encontrada');
    }
    
    return campaign;
  }

  async update(id: string, updateCampaignDto: UpdateCampaignDto): Promise<Campaign> {
    const campaign = await this.findOne(id);

    Object.assign(campaign, updateCampaignDto);

    // Recalcular público-alvo se mudou
    if (updateCampaignDto.targetAudience) {
      const targetCount = await this.calculateTargetAudience(updateCampaignDto.targetAudience);
      campaign.targetCount = targetCount;
    }

    return this.campaignsRepository.save(campaign);
  }

  async remove(id: string): Promise<void> {
    const campaign = await this.findOne(id);
    await this.campaignsRepository.remove(campaign);
  }

  async startCampaign(id: string): Promise<Campaign> {
    const campaign = await this.findOne(id);
    
    if (campaign.status !== CampaignStatus.DRAFT && campaign.status !== CampaignStatus.SCHEDULED) {
      throw new Error('Campanha não pode ser iniciada neste status');
    }

    campaign.status = CampaignStatus.RUNNING;
    campaign.startedAt = new Date();

    // Simular envio da campanha
    await this.simulateCampaignExecution(campaign);

    return this.campaignsRepository.save(campaign);
  }

  async pauseCampaign(id: string): Promise<Campaign> {
    const campaign = await this.findOne(id);
    
    if (campaign.status !== CampaignStatus.RUNNING) {
      throw new Error('Apenas campanhas em execução podem ser pausadas');
    }

    campaign.status = CampaignStatus.PAUSED;
    return this.campaignsRepository.save(campaign);
  }

  async completeCampaign(id: string): Promise<Campaign> {
    const campaign = await this.findOne(id);
    
    campaign.status = CampaignStatus.COMPLETED;
    campaign.completedAt = new Date();
    
    return this.campaignsRepository.save(campaign);
  }

  async getCampaignStats() {
    const total = await this.campaignsRepository.count();
    const running = await this.campaignsRepository.count({ where: { status: CampaignStatus.RUNNING } });
    const completed = await this.campaignsRepository.count({ where: { status: CampaignStatus.COMPLETED } });
    const scheduled = await this.campaignsRepository.count({ where: { status: CampaignStatus.SCHEDULED } });

    // Calcular métricas médias
    const avgMetrics = await this.campaignsRepository
      .createQueryBuilder('campaign')
      .select([
        'AVG(campaign.openedCount * 100.0 / NULLIF(campaign.deliveredCount, 0)) as avgOpenRate',
        'AVG(campaign.clickedCount * 100.0 / NULLIF(campaign.deliveredCount, 0)) as avgClickRate',
        'AVG(campaign.convertedCount * 100.0 / NULLIF(campaign.deliveredCount, 0)) as avgConversionRate',
        'SUM(campaign.revenue) as totalRevenue',
      ])
      .where('campaign.status = :status', { status: CampaignStatus.COMPLETED })
      .getRawOne();

    return {
      total,
      running,
      completed,
      scheduled,
      averageOpenRate: Math.round(avgMetrics?.avgOpenRate || 0),
      averageClickRate: Math.round(avgMetrics?.avgClickRate || 0),
      averageConversionRate: Math.round(avgMetrics?.avgConversionRate || 0),
      totalRevenue: parseFloat(avgMetrics?.totalRevenue || '0'),
    };
  }

  async getTopPerformingCampaigns(limit: number = 10): Promise<Campaign[]> {
    return this.campaignsRepository
      .createQueryBuilder('campaign')
      .where('campaign.status = :status', { status: CampaignStatus.COMPLETED })
      .orderBy('campaign.revenue', 'DESC')
      .take(limit)
      .getMany();
  }

  async generateCampaignWithAI(prompt: string, userId: string): Promise<Campaign> {
    // Simulação de geração de campanha com IA
    const aiGeneratedCampaign = await this.generateCampaignContent(prompt);
    
    const campaign = this.campaignsRepository.create({
      ...aiGeneratedCampaign,
      createdBy: userId,
      status: CampaignStatus.DRAFT,
    });

    return this.campaignsRepository.save(campaign);
  }

  // Método privado para calcular público-alvo
  private async calculateTargetAudience(targetAudience: any): Promise<number> {
    const filters: any = {};

    if (targetAudience.leadTemperature?.length > 0) {
      filters.temperature = targetAudience.leadTemperature[0]; // Simplificado
    }

    if (targetAudience.leadStatus?.length > 0) {
      filters.status = targetAudience.leadStatus[0]; // Simplificado
    }

    if (targetAudience.tags?.length > 0) {
      filters.tags = targetAudience.tags;
    }

    try {
      const result = await this.leadsService.findAll(filters);
      return result.total;
    } catch (error) {
      return 0;
    }
  }

  // Simulação de execução de campanha
  private async simulateCampaignExecution(campaign: Campaign): Promise<void> {
    // Simular métricas realistas baseadas no tipo de campanha
    const baseMetrics = this.getBaseMetricsForCampaignType(campaign.type);
    
    campaign.sentCount = campaign.targetCount;
    campaign.deliveredCount = Math.round(campaign.sentCount * baseMetrics.deliveryRate);
    campaign.openedCount = Math.round(campaign.deliveredCount * baseMetrics.openRate);
    campaign.clickedCount = Math.round(campaign.openedCount * baseMetrics.clickRate);
    campaign.convertedCount = Math.round(campaign.deliveredCount * baseMetrics.conversionRate);
    campaign.bouncedCount = campaign.sentCount - campaign.deliveredCount;
    campaign.unsubscribedCount = Math.round(campaign.deliveredCount * 0.01); // 1% unsubscribe
    
    // Simular receita baseada nas conversões
    const avgOrderValue = 150; // R$ 150 valor médio do pedido
    campaign.revenue = campaign.convertedCount * avgOrderValue;
  }

  // Métricas base por tipo de campanha
  private getBaseMetricsForCampaignType(type: CampaignType) {
    switch (type) {
      case CampaignType.EMAIL:
        return {
          deliveryRate: 0.95,
          openRate: 0.22,
          clickRate: 0.15,
          conversionRate: 0.03,
        };
      case CampaignType.SMS:
        return {
          deliveryRate: 0.98,
          openRate: 0.90,
          clickRate: 0.08,
          conversionRate: 0.05,
        };
      case CampaignType.WHATSAPP:
        return {
          deliveryRate: 0.97,
          openRate: 0.85,
          clickRate: 0.12,
          conversionRate: 0.07,
        };
      default:
        return {
          deliveryRate: 0.90,
          openRate: 0.20,
          clickRate: 0.10,
          conversionRate: 0.02,
        };
    }
  }

  // Geração de conteúdo com IA (simulado)
  private async generateCampaignContent(prompt: string): Promise<Partial<Campaign>> {
    // Simulação de IA que gera conteúdo baseado no prompt
    const templates = {
      'black friday': {
        name: 'Campanha Black Friday 2025',
        subject: '🔥 Black Friday: Até 70% OFF em medicamentos!',
        content: `
          <h1>Black Friday Farmynex!</h1>
          <p>Aproveite nossa super promoção de Black Friday com descontos de até 70% em medicamentos selecionados.</p>
          <ul>
            <li>Medicamentos genéricos com 50% OFF</li>
            <li>Suplementos vitamínicos com 40% OFF</li>
            <li>Produtos de higiene com 30% OFF</li>
          </ul>
          <p>Oferta válida até 30/11/2025 ou enquanto durarem os estoques.</p>
        `,
        ctaText: 'Aproveitar Oferta',
        ctaUrl: 'https://farmynex.com/black-friday',
        type: CampaignType.EMAIL,
        objective: 'sales' as any,
      },
      'natal': {
        name: 'Campanha Natal 2025',
        subject: '🎄 Presentes de Natal para cuidar de quem você ama',
        content: `
          <h1>Natal Farmynex 2025</h1>
          <p>Neste Natal, cuide de quem você ama com produtos especiais da Farmynex.</p>
          <p>Kits especiais de presente:</p>
          <ul>
            <li>Kit Família Saudável</li>
            <li>Kit Beleza e Bem-estar</li>
            <li>Kit Cuidados Especiais</li>
          </ul>
        `,
        ctaText: 'Ver Kits de Natal',
        ctaUrl: 'https://farmynex.com/natal',
        type: CampaignType.EMAIL,
        objective: 'sales' as any,
      },
    };

    // Buscar template baseado no prompt
    const promptLower = prompt.toLowerCase();
    
    if (promptLower.includes('black friday')) {
      return templates['black friday'];
    } else if (promptLower.includes('natal')) {
      return templates['natal'];
    }

    // Template genérico
    return {
      name: 'Campanha Gerada por IA',
      subject: 'Oferta especial para você!',
      content: `
        <h1>Oferta Especial Farmynex</h1>
        <p>Temos uma oferta especial preparada especialmente para você.</p>
        <p>Confira nossos produtos em promoção e aproveite!</p>
      `,
      ctaText: 'Ver Ofertas',
      ctaUrl: 'https://farmynex.com/ofertas',
      type: CampaignType.EMAIL,
      objective: 'sales' as any,
    };
  }
}

