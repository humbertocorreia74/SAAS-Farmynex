import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';

export enum CampaignType {
  EMAIL = 'email',
  SMS = 'sms',
  WHATSAPP = 'whatsapp',
  SOCIAL_MEDIA = 'social_media',
  PUSH_NOTIFICATION = 'push_notification',
}

export enum CampaignStatus {
  DRAFT = 'draft',
  SCHEDULED = 'scheduled',
  RUNNING = 'running',
  PAUSED = 'paused',
  COMPLETED = 'completed',
  CANCELLED = 'cancelled',
}

export enum CampaignObjective {
  LEAD_GENERATION = 'lead_generation',
  SALES = 'sales',
  ENGAGEMENT = 'engagement',
  RETENTION = 'retention',
  AWARENESS = 'awareness',
}

@Entity('campaigns')
@Index(['status'])
@Index(['type'])
@Index(['createdAt'])
export class Campaign {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({
    type: 'varchar',
    default: CampaignType.EMAIL,
  })
  type: CampaignType;

  @Column({
    type: 'varchar',
    default: CampaignStatus.DRAFT,
  })
  status: CampaignStatus;

  @Column({
    type: 'varchar',
    default: CampaignObjective.SALES,
  })
  objective: CampaignObjective;

  @Column()
  subject: string; // Assunto do email ou título da campanha

  @Column({ type: 'text' })
  content: string; // Conteúdo da mensagem

  @Column({ type: 'text', nullable: true })
  ctaText: string; // Texto do Call-to-Action

  @Column({ type: 'text', nullable: true })
  ctaUrl: string; // URL do Call-to-Action

  // Configurações de segmentação
  @Column({ type: 'json', nullable: true })
  targetAudience: {
    leadTemperature?: string[];
    leadStatus?: string[];
    interests?: string[];
    tags?: string[];
    customFilters?: Record<string, any>;
  };

  // Configurações de agendamento
  @Column({ type: 'datetime', nullable: true })
  scheduledAt: Date;

  @Column({ type: 'datetime', nullable: true })
  startedAt: Date;

  @Column({ type: 'datetime', nullable: true })
  completedAt: Date;

  // Métricas da campanha
  @Column({ type: 'int', default: 0 })
  targetCount: number; // Número de leads alvo

  @Column({ type: 'int', default: 0 })
  sentCount: number; // Número de mensagens enviadas

  @Column({ type: 'int', default: 0 })
  deliveredCount: number; // Número de mensagens entregues

  @Column({ type: 'int', default: 0 })
  openedCount: number; // Número de aberturas

  @Column({ type: 'int', default: 0 })
  clickedCount: number; // Número de cliques

  @Column({ type: 'int', default: 0 })
  repliedCount: number; // Número de respostas

  @Column({ type: 'int', default: 0 })
  unsubscribedCount: number; // Número de descadastros

  @Column({ type: 'int', default: 0 })
  bouncedCount: number; // Número de bounces

  @Column({ type: 'int', default: 0 })
  convertedCount: number; // Número de conversões

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  revenue: number; // Receita gerada pela campanha

  // Configurações avançadas
  @Column({ type: 'json', nullable: true })
  abTestConfig: {
    enabled: boolean;
    variants?: Array<{
      name: string;
      subject?: string;
      content?: string;
      ctaText?: string;
      percentage: number;
    }>;
  };

  @Column({ type: 'json', nullable: true })
  automationRules: {
    followUpEnabled?: boolean;
    followUpDelay?: number; // em horas
    followUpContent?: string;
    retargetingEnabled?: boolean;
    retargetingCriteria?: Record<string, any>;
  };

  @Column({ nullable: true })
  createdBy: string; // ID do usuário que criou

  @Column({ type: 'json', nullable: true })
  tags: string[];

  @Column({ type: 'json', nullable: true })
  metadata: Record<string, any>;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Getters calculados
  get deliveryRate(): number {
    if (this.sentCount === 0) return 0;
    return Math.round((this.deliveredCount / this.sentCount) * 100);
  }

  get openRate(): number {
    if (this.deliveredCount === 0) return 0;
    return Math.round((this.openedCount / this.deliveredCount) * 100);
  }

  get clickRate(): number {
    if (this.deliveredCount === 0) return 0;
    return Math.round((this.clickedCount / this.deliveredCount) * 100);
  }

  get clickToOpenRate(): number {
    if (this.openedCount === 0) return 0;
    return Math.round((this.clickedCount / this.openedCount) * 100);
  }

  get conversionRate(): number {
    if (this.deliveredCount === 0) return 0;
    return Math.round((this.convertedCount / this.deliveredCount) * 100);
  }

  get bounceRate(): number {
    if (this.sentCount === 0) return 0;
    return Math.round((this.bouncedCount / this.sentCount) * 100);
  }

  get unsubscribeRate(): number {
    if (this.deliveredCount === 0) return 0;
    return Math.round((this.unsubscribedCount / this.deliveredCount) * 100);
  }

  get roi(): number {
    // Assumindo custo médio de R$ 0,10 por email enviado
    const estimatedCost = this.sentCount * 0.10;
    if (estimatedCost === 0) return 0;
    return Math.round(((this.revenue - estimatedCost) / estimatedCost) * 100);
  }

  get isActive(): boolean {
    return [CampaignStatus.RUNNING, CampaignStatus.SCHEDULED].includes(this.status);
  }

  get isCompleted(): boolean {
    return [CampaignStatus.COMPLETED, CampaignStatus.CANCELLED].includes(this.status);
  }
}

