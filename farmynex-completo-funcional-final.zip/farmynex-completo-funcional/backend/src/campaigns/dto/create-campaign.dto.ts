import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsNotEmpty,
  IsEnum,
  IsOptional,
  IsObject,
  IsDateString,
  IsArray,
  IsUrl,
  IsNumber,
  Min,
} from 'class-validator';
import { CampaignType, CampaignObjective } from '../entities/campaign.entity';

export class CreateCampaignDto {
  @ApiProperty({
    description: 'Nome da campanha',
    example: 'Campanha Black Friday 2025',
  })
  @IsString({ message: 'Nome deve ser uma string' })
  @IsNotEmpty({ message: 'Nome é obrigatório' })
  name: string;

  @ApiProperty({
    description: 'Descrição da campanha',
    example: 'Campanha promocional para Black Friday com descontos especiais',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Descrição deve ser uma string' })
  description?: string;

  @ApiProperty({
    description: 'Tipo da campanha',
    enum: CampaignType,
    example: CampaignType.EMAIL,
  })
  @IsEnum(CampaignType, { message: 'Tipo deve ser um valor válido' })
  type: CampaignType;

  @ApiProperty({
    description: 'Objetivo da campanha',
    enum: CampaignObjective,
    example: CampaignObjective.SALES,
  })
  @IsEnum(CampaignObjective, { message: 'Objetivo deve ser um valor válido' })
  objective: CampaignObjective;

  @ApiProperty({
    description: 'Assunto do email ou título da campanha',
    example: '🔥 Black Friday: Até 70% OFF em medicamentos!',
  })
  @IsString({ message: 'Assunto deve ser uma string' })
  @IsNotEmpty({ message: 'Assunto é obrigatório' })
  subject: string;

  @ApiProperty({
    description: 'Conteúdo da mensagem',
    example: 'Aproveite nossa super promoção de Black Friday...',
  })
  @IsString({ message: 'Conteúdo deve ser uma string' })
  @IsNotEmpty({ message: 'Conteúdo é obrigatório' })
  content: string;

  @ApiProperty({
    description: 'Texto do Call-to-Action',
    example: 'Comprar Agora',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Texto do CTA deve ser uma string' })
  ctaText?: string;

  @ApiProperty({
    description: 'URL do Call-to-Action',
    example: 'https://farmynex.com/promocao-black-friday',
    required: false,
  })
  @IsOptional()
  @IsUrl({}, { message: 'URL do CTA deve ser uma URL válida' })
  ctaUrl?: string;

  @ApiProperty({
    description: 'Configurações de público-alvo',
    example: {
      leadTemperature: ['hot', 'warm'],
      leadStatus: ['new', 'contacted'],
      interests: ['medicamentos', 'suplementos'],
      tags: ['vip', 'farmacia-grande'],
    },
    required: false,
  })
  @IsOptional()
  @IsObject({ message: 'Público-alvo deve ser um objeto' })
  targetAudience?: {
    leadTemperature?: string[];
    leadStatus?: string[];
    interests?: string[];
    tags?: string[];
    customFilters?: Record<string, any>;
  };

  @ApiProperty({
    description: 'Data e hora para envio agendado',
    example: '2025-11-29T09:00:00Z',
    required: false,
  })
  @IsOptional()
  @IsDateString({}, { message: 'Data de agendamento deve ser uma data válida' })
  scheduledAt?: string;

  @ApiProperty({
    description: 'Configurações de teste A/B',
    example: {
      enabled: true,
      variants: [
        {
          name: 'Variante A',
          subject: 'Black Friday: Descontos imperdíveis!',
          percentage: 50,
        },
        {
          name: 'Variante B',
          subject: '🔥 Última chance: Black Friday!',
          percentage: 50,
        },
      ],
    },
    required: false,
  })
  @IsOptional()
  @IsObject({ message: 'Configuração de teste A/B deve ser um objeto' })
  abTestConfig?: {
    enabled: boolean;
    variants?: Array<{
      name: string;
      subject?: string;
      content?: string;
      ctaText?: string;
      percentage: number;
    }>;
  };

  @ApiProperty({
    description: 'Regras de automação',
    example: {
      followUpEnabled: true,
      followUpDelay: 24,
      followUpContent: 'Não perdeu nossa oferta especial...',
      retargetingEnabled: true,
    },
    required: false,
  })
  @IsOptional()
  @IsObject({ message: 'Regras de automação devem ser um objeto' })
  automationRules?: {
    followUpEnabled?: boolean;
    followUpDelay?: number;
    followUpContent?: string;
    retargetingEnabled?: boolean;
    retargetingCriteria?: Record<string, any>;
  };

  @ApiProperty({
    description: 'Tags da campanha',
    example: ['black-friday', 'promocional', 'email'],
    required: false,
  })
  @IsOptional()
  @IsArray({ message: 'Tags devem ser um array' })
  @IsString({ each: true, message: 'Cada tag deve ser uma string' })
  tags?: string[];

  @ApiProperty({
    description: 'Metadados adicionais',
    example: { budget: 1000, expectedROI: 300 },
    required: false,
  })
  @IsOptional()
  @IsObject({ message: 'Metadados devem ser um objeto' })
  metadata?: Record<string, any>;
}

