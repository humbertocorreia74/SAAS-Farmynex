import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Query,
  Request,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
  ApiBody,
} from '@nestjs/swagger';
import { CampaignsService } from './campaigns.service';
import { CreateCampaignDto } from './dto/create-campaign.dto';
import { UpdateCampaignDto } from './dto/update-campaign.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CampaignStatus, CampaignType } from './entities/campaign.entity';

@ApiTags('campaigns')
@Controller('campaigns')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class CampaignsController {
  constructor(private readonly campaignsService: CampaignsService) {}

  @Post()
  @ApiOperation({ summary: 'Criar nova campanha' })
  @ApiResponse({
    status: 201,
    description: 'Campanha criada com sucesso',
  })
  async create(
    @Body() createCampaignDto: CreateCampaignDto,
    @Request() req,
  ) {
    const campaign = await this.campaignsService.create(createCampaignDto, req.user.id);
    
    return {
      success: true,
      message: 'Campanha criada com sucesso',
      data: campaign,
    };
  }

  @Post('generate-ai')
  @ApiOperation({ summary: 'Gerar campanha com IA' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        prompt: {
          type: 'string',
          example: 'Criar campanha de Black Friday para medicamentos com desconto',
        },
      },
    },
  })
  @ApiResponse({
    status: 201,
    description: 'Campanha gerada com IA com sucesso',
  })
  async generateWithAI(
    @Body() body: { prompt: string },
    @Request() req,
  ) {
    const campaign = await this.campaignsService.generateCampaignWithAI(body.prompt, req.user.id);
    
    return {
      success: true,
      message: 'Campanha gerada com IA com sucesso',
      data: campaign,
    };
  }

  @Get()
  @ApiOperation({ summary: 'Listar campanhas com filtros' })
  @ApiQuery({ name: 'status', enum: CampaignStatus, required: false })
  @ApiQuery({ name: 'type', enum: CampaignType, required: false })
  @ApiQuery({ name: 'createdBy', required: false })
  @ApiQuery({ name: 'page', type: Number, required: false })
  @ApiQuery({ name: 'limit', type: Number, required: false })
  @ApiResponse({
    status: 200,
    description: 'Lista de campanhas retornada com sucesso',
  })
  async findAll(
    @Query('status') status?: CampaignStatus,
    @Query('type') type?: CampaignType,
    @Query('createdBy') createdBy?: string,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
  ) {
    const result = await this.campaignsService.findAll({
      status,
      type,
      createdBy,
      page,
      limit,
    });

    return {
      success: true,
      data: result.campaigns,
      pagination: {
        page: result.page,
        limit: limit || 20,
        total: result.total,
        totalPages: result.totalPages,
      },
    };
  }

  @Get('stats')
  @ApiOperation({ summary: 'Estatísticas de campanhas' })
  @ApiResponse({
    status: 200,
    description: 'Estatísticas retornadas com sucesso',
  })
  async getStats() {
    const stats = await this.campaignsService.getCampaignStats();
    
    return {
      success: true,
      data: stats,
    };
  }

  @Get('top-performing')
  @ApiOperation({ summary: 'Campanhas com melhor performance' })
  @ApiQuery({ name: 'limit', type: Number, required: false })
  @ApiResponse({
    status: 200,
    description: 'Campanhas com melhor performance retornadas com sucesso',
  })
  async getTopPerforming(@Query('limit') limit?: number) {
    const campaigns = await this.campaignsService.getTopPerformingCampaigns(limit);
    
    return {
      success: true,
      data: campaigns,
      total: campaigns.length,
    };
  }

  @Get(':id')
  @ApiOperation({ summary: 'Buscar campanha por ID' })
  @ApiParam({ name: 'id', description: 'ID da campanha' })
  @ApiResponse({
    status: 200,
    description: 'Campanha encontrada',
  })
  @ApiResponse({
    status: 404,
    description: 'Campanha não encontrada',
  })
  async findOne(@Param('id') id: string) {
    const campaign = await this.campaignsService.findOne(id);
    
    return {
      success: true,
      data: campaign,
    };
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar campanha' })
  @ApiParam({ name: 'id', description: 'ID da campanha' })
  @ApiResponse({
    status: 200,
    description: 'Campanha atualizada com sucesso',
  })
  async update(
    @Param('id') id: string,
    @Body() updateCampaignDto: UpdateCampaignDto,
  ) {
    const campaign = await this.campaignsService.update(id, updateCampaignDto);
    
    return {
      success: true,
      message: 'Campanha atualizada com sucesso',
      data: campaign,
    };
  }

  @Patch(':id/start')
  @ApiOperation({ summary: 'Iniciar campanha' })
  @ApiParam({ name: 'id', description: 'ID da campanha' })
  @ApiResponse({
    status: 200,
    description: 'Campanha iniciada com sucesso',
  })
  async startCampaign(@Param('id') id: string) {
    const campaign = await this.campaignsService.startCampaign(id);
    
    return {
      success: true,
      message: 'Campanha iniciada com sucesso',
      data: campaign,
    };
  }

  @Patch(':id/pause')
  @ApiOperation({ summary: 'Pausar campanha' })
  @ApiParam({ name: 'id', description: 'ID da campanha' })
  @ApiResponse({
    status: 200,
    description: 'Campanha pausada com sucesso',
  })
  async pauseCampaign(@Param('id') id: string) {
    const campaign = await this.campaignsService.pauseCampaign(id);
    
    return {
      success: true,
      message: 'Campanha pausada com sucesso',
      data: campaign,
    };
  }

  @Patch(':id/complete')
  @ApiOperation({ summary: 'Finalizar campanha' })
  @ApiParam({ name: 'id', description: 'ID da campanha' })
  @ApiResponse({
    status: 200,
    description: 'Campanha finalizada com sucesso',
  })
  async completeCampaign(@Param('id') id: string) {
    const campaign = await this.campaignsService.completeCampaign(id);
    
    return {
      success: true,
      message: 'Campanha finalizada com sucesso',
      data: campaign,
    };
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Remover campanha' })
  @ApiParam({ name: 'id', description: 'ID da campanha' })
  @ApiResponse({
    status: 200,
    description: 'Campanha removida com sucesso',
  })
  async remove(@Param('id') id: string) {
    await this.campaignsService.remove(id);
    
    return {
      success: true,
      message: 'Campanha removida com sucesso',
    };
  }
}

