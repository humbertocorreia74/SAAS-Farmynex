import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';

// Módulos existentes
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { ProductsModule } from './products/products.module';
import { CampaignsModule } from './campaigns/campaigns.module';
import { AnalyticsModule } from './analytics/analytics.module';
import { DatabaseModule } from './database/database.module';

// Novos módulos integrados
import { StripeModule } from './stripe/stripe.module';
import { SubscriptionModule } from './subscription/subscription.module';
import { IntegrationsModule } from './integrations/integrations.module';
import { MobileModule } from './mobile/mobile.module';

// Módulos farmacêuticos específicos
import { BrandingModule } from './branding/branding.module';
import { EquipmentModule } from './equipment/equipment.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    TypeOrmModule.forRoot({
      type: 'sqlite',
      database: 'farmynex.db',
      entities: [__dirname + '/**/*.entity{.ts,.js}'],
      synchronize: true,
      logging: false,
    }),
    PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.register({
      secret: process.env.JWT_SECRET || 'farmynex-secret-key',
      signOptions: { expiresIn: '24h' },
    }),
    
    // Módulos existentes
    DatabaseModule,
    AuthModule,
    UsersModule,
    ProductsModule,
    CampaignsModule,
    AnalyticsModule,
    
    // Novos módulos
    StripeModule,
    SubscriptionModule,
    IntegrationsModule,
    MobileModule,
    
    // Módulos farmacêuticos específicos
    BrandingModule,
    EquipmentModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}

