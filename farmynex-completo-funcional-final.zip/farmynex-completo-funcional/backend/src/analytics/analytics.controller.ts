import {
  Controller,
  Get,
  UseGuards,
  Query,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { AnalyticsService } from './analytics.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('analytics')
@Controller('analytics')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class AnalyticsController {
  constructor(private readonly analyticsService: AnalyticsService) {}

  @Get('dashboard')
  @ApiOperation({ summary: 'Visão geral do dashboard' })
  @ApiResponse({
    status: 200,
    description: 'Dados do dashboard retornados com sucesso',
    schema: {
      example: {
        success: true,
        data: {
          overview: {
            totalUsers: 150,
            totalProducts: 1200,
            totalLeads: 450,
            totalCampaigns: 25,
          },
          alerts: {
            activeUsers: 142,
            lowStockProducts: 15,
            hotLeads: 23,
            activeCampaigns: 3,
          },
        },
      },
    },
  })
  async getDashboardOverview() {
    const data = await this.analyticsService.getDashboardOverview();
    
    return {
      success: true,
      data,
    };
  }

  @Get('sales')
  @ApiOperation({ summary: 'Analytics de vendas' })
  @ApiQuery({ 
    name: 'period', 
    enum: ['week', 'month', 'quarter', 'year'], 
    required: false,
    description: 'Período para análise',
  })
  @ApiResponse({
    status: 200,
    description: 'Analytics de vendas retornados com sucesso',
  })
  async getSalesAnalytics(
    @Query('period') period: 'week' | 'month' | 'quarter' | 'year' = 'month',
  ) {
    const data = await this.analyticsService.getSalesAnalytics(period);
    
    return {
      success: true,
      data,
    };
  }

  @Get('leads')
  @ApiOperation({ summary: 'Analytics de leads' })
  @ApiQuery({ 
    name: 'period', 
    enum: ['week', 'month', 'quarter', 'year'], 
    required: false,
    description: 'Período para análise',
  })
  @ApiResponse({
    status: 200,
    description: 'Analytics de leads retornados com sucesso',
  })
  async getLeadsAnalytics(
    @Query('period') period: 'week' | 'month' | 'quarter' | 'year' = 'month',
  ) {
    const data = await this.analyticsService.getLeadsAnalytics(period);
    
    return {
      success: true,
      data,
    };
  }

  @Get('campaigns')
  @ApiOperation({ summary: 'Analytics de campanhas' })
  @ApiQuery({ 
    name: 'period', 
    enum: ['week', 'month', 'quarter', 'year'], 
    required: false,
    description: 'Período para análise',
  })
  @ApiResponse({
    status: 200,
    description: 'Analytics de campanhas retornados com sucesso',
  })
  async getCampaignsAnalytics(
    @Query('period') period: 'week' | 'month' | 'quarter' | 'year' = 'month',
  ) {
    const data = await this.analyticsService.getCampaignsAnalytics(period);
    
    return {
      success: true,
      data,
    };
  }

  @Get('inventory')
  @ApiOperation({ summary: 'Analytics de estoque' })
  @ApiResponse({
    status: 200,
    description: 'Analytics de estoque retornados com sucesso',
  })
  async getInventoryAnalytics() {
    const data = await this.analyticsService.getInventoryAnalytics();
    
    return {
      success: true,
      data,
    };
  }

  @Get('users')
  @ApiOperation({ summary: 'Analytics de usuários' })
  @ApiQuery({ 
    name: 'period', 
    enum: ['week', 'month', 'quarter', 'year'], 
    required: false,
    description: 'Período para análise',
  })
  @ApiResponse({
    status: 200,
    description: 'Analytics de usuários retornados com sucesso',
  })
  async getUsersAnalytics(
    @Query('period') period: 'week' | 'month' | 'quarter' | 'year' = 'month',
  ) {
    const data = await this.analyticsService.getUsersAnalytics(period);
    
    return {
      success: true,
      data,
    };
  }

  @Get('reports/sales-summary')
  @ApiOperation({ summary: 'Relatório resumo de vendas' })
  @ApiQuery({ 
    name: 'period', 
    enum: ['week', 'month', 'quarter', 'year'], 
    required: false,
  })
  @ApiResponse({
    status: 200,
    description: 'Relatório de vendas gerado com sucesso',
  })
  async getSalesSummaryReport(
    @Query('period') period: 'week' | 'month' | 'quarter' | 'year' = 'month',
  ) {
    const salesData = await this.analyticsService.getSalesAnalytics(period);
    const inventoryData = await this.analyticsService.getInventoryAnalytics();
    
    return {
      success: true,
      data: {
        period,
        generatedAt: new Date().toISOString(),
        sales: salesData,
        inventory: inventoryData,
        summary: {
          totalRevenue: salesData.totalRevenue,
          totalOrders: salesData.totalOrders,
          averageOrderValue: salesData.averageOrderValue,
          topSellingProduct: salesData.topProducts[0]?.name || 'N/A',
          lowStockAlerts: inventoryData.overview.lowStockProducts,
        },
      },
    };
  }

  @Get('reports/leads-performance')
  @ApiOperation({ summary: 'Relatório de performance de leads' })
  @ApiQuery({ 
    name: 'period', 
    enum: ['week', 'month', 'quarter', 'year'], 
    required: false,
  })
  @ApiResponse({
    status: 200,
    description: 'Relatório de leads gerado com sucesso',
  })
  async getLeadsPerformanceReport(
    @Query('period') period: 'week' | 'month' | 'quarter' | 'year' = 'month',
  ) {
    const leadsData = await this.analyticsService.getLeadsAnalytics(period);
    const campaignsData = await this.analyticsService.getCampaignsAnalytics(period);
    
    return {
      success: true,
      data: {
        period,
        generatedAt: new Date().toISOString(),
        leads: leadsData,
        campaigns: campaignsData,
        summary: {
          totalLeads: leadsData.leadsByTemperature.reduce((sum, item) => sum + item.count, 0),
          conversionRate: leadsData.conversionFunnel.conversionRate,
          hotLeads: leadsData.leadsByTemperature.find(item => item.temperature === 'hot')?.count || 0,
          campaignROI: campaignsData.overallMetrics.totalRevenue > 0 
            ? Math.round(((campaignsData.overallMetrics.totalRevenue - (campaignsData.overallMetrics.totalSent * 0.10)) / (campaignsData.overallMetrics.totalSent * 0.10)) * 100)
            : 0,
        },
      },
    };
  }

  @Get('kpis')
  @ApiOperation({ summary: 'KPIs principais do sistema' })
  @ApiResponse({
    status: 200,
    description: 'KPIs retornados com sucesso',
  })
  async getMainKPIs() {
    const [dashboard, sales, leads, campaigns] = await Promise.all([
      this.analyticsService.getDashboardOverview(),
      this.analyticsService.getSalesAnalytics('month'),
      this.analyticsService.getLeadsAnalytics('month'),
      this.analyticsService.getCampaignsAnalytics('month'),
    ]);

    return {
      success: true,
      data: {
        revenue: {
          current: sales.totalRevenue,
          growth: Math.floor(Math.random() * 20) + 5, // Simular crescimento
          target: sales.totalRevenue * 1.2,
        },
        leads: {
          total: dashboard.overview.totalLeads,
          hot: dashboard.alerts.hotLeads,
          conversionRate: leads.conversionFunnel.conversionRate,
        },
        campaigns: {
          active: dashboard.alerts.activeCampaigns,
          averageOpenRate: campaigns.overallMetrics.averageOpenRate,
          averageClickRate: campaigns.overallMetrics.averageClickRate,
          roi: campaigns.overallMetrics.totalRevenue > 0 
            ? Math.round(((campaigns.overallMetrics.totalRevenue - (campaigns.overallMetrics.totalSent * 0.10)) / (campaigns.overallMetrics.totalSent * 0.10)) * 100)
            : 0,
        },
        inventory: {
          totalProducts: dashboard.overview.totalProducts,
          lowStock: dashboard.alerts.lowStockProducts,
          stockTurnover: Math.floor(Math.random() * 10) + 5, // Simular giro de estoque
        },
        users: {
          total: dashboard.overview.totalUsers,
          active: dashboard.alerts.activeUsers,
          growth: Math.floor(Math.random() * 15) + 3, // Simular crescimento
        },
      },
    };
  }
}

