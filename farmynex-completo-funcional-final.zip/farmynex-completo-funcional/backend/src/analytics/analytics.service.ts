import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User, UserStatus } from '../users/entities/user.entity';
import { Product, ProductStatus } from '../products/entities/product.entity';
import { Lead, LeadTemperature, LeadStatus } from '../leads/entities/lead.entity';
import { Campaign, CampaignStatus } from '../campaigns/entities/campaign.entity';

@Injectable()
export class AnalyticsService {
  constructor(
    @InjectRepository(User)
    private usersRepository: Repository<User>,
    @InjectRepository(Product)
    private productsRepository: Repository<Product>,
    @InjectRepository(Lead)
    private leadsRepository: Repository<Lead>,
    @InjectRepository(Campaign)
    private campaignsRepository: Repository<Campaign>,
  ) {}

  async getDashboardOverview() {
    const [
      totalUsers,
      totalProducts,
      totalLeads,
      totalCampaigns,
      activeUsers,
      lowStockProducts,
      hotLeads,
      activeCampaigns,
    ] = await Promise.all([
      this.usersRepository.count(),
      this.productsRepository.count(),
      this.leadsRepository.count(),
      this.campaignsRepository.count(),
      this.usersRepository.count({ where: { status: UserStatus.ACTIVE } }),
      this.productsRepository
        .createQueryBuilder('product')
        .where('product.stock <= product.minStock')
        .getCount(),
      this.leadsRepository.count({ where: { temperature: LeadTemperature.HOT } }),
      this.campaignsRepository.count({ where: { status: CampaignStatus.RUNNING } }),
    ]);

    return {
      overview: {
        totalUsers,
        totalProducts,
        totalLeads,
        totalCampaigns,
      },
      alerts: {
        activeUsers,
        lowStockProducts,
        hotLeads,
        activeCampaigns,
      },
    };
  }

  async getSalesAnalytics(period: 'week' | 'month' | 'quarter' | 'year' = 'month') {
    const days = this.getPeriodDays(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Simular dados de vendas (em um sistema real, viria de uma tabela de vendas)
    const salesData = await this.generateSalesData(startDate, new Date());
    
    const topProducts = await this.productsRepository
      .createQueryBuilder('product')
      .orderBy('product.salesCount', 'DESC')
      .take(10)
      .getMany();

    const revenueByCategory = await this.getRevenueByCategory(startDate);

    return {
      period,
      salesData,
      topProducts: topProducts.map(product => ({
        id: product.id,
        name: product.name,
        salesCount: product.salesCount,
        revenue: product.salesCount * product.price,
        category: product.category,
      })),
      revenueByCategory,
      totalRevenue: salesData.reduce((sum, day) => sum + day.revenue, 0),
      totalOrders: salesData.reduce((sum, day) => sum + day.orders, 0),
      averageOrderValue: salesData.length > 0 
        ? salesData.reduce((sum, day) => sum + day.revenue, 0) / salesData.reduce((sum, day) => sum + day.orders, 0)
        : 0,
    };
  }

  async getLeadsAnalytics(period: 'week' | 'month' | 'quarter' | 'year' = 'month') {
    const days = this.getPeriodDays(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const leadsOverTime = await this.getLeadsOverTime(startDate);
    const conversionFunnel = await this.getConversionFunnel();
    const leadsBySource = await this.getLeadsBySource(startDate);
    const leadsByTemperature = await this.getLeadsByTemperature();

    return {
      period,
      leadsOverTime,
      conversionFunnel,
      leadsBySource,
      leadsByTemperature,
    };
  }

  async getCampaignsAnalytics(period: 'week' | 'month' | 'quarter' | 'year' = 'month') {
    const days = this.getPeriodDays(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const campaignPerformance = await this.campaignsRepository
      .createQueryBuilder('campaign')
      .where('campaign.createdAt >= :startDate', { startDate })
      .orderBy('campaign.revenue', 'DESC')
      .getMany();

    const avgMetrics = await this.campaignsRepository
      .createQueryBuilder('campaign')
      .select([
        'AVG(campaign.openedCount * 100.0 / NULLIF(campaign.deliveredCount, 0)) as avgOpenRate',
        'AVG(campaign.clickedCount * 100.0 / NULLIF(campaign.deliveredCount, 0)) as avgClickRate',
        'AVG(campaign.convertedCount * 100.0 / NULLIF(campaign.deliveredCount, 0)) as avgConversionRate',
        'SUM(campaign.revenue) as totalRevenue',
        'SUM(campaign.sentCount) as totalSent',
        'SUM(campaign.deliveredCount) as totalDelivered',
        'SUM(campaign.openedCount) as totalOpened',
        'SUM(campaign.clickedCount) as totalClicked',
        'SUM(campaign.convertedCount) as totalConverted',
      ])
      .where('campaign.createdAt >= :startDate', { startDate })
      .getRawOne();

    return {
      period,
      campaignPerformance: campaignPerformance.map(campaign => ({
        id: campaign.id,
        name: campaign.name,
        type: campaign.type,
        status: campaign.status,
        sentCount: campaign.sentCount,
        openRate: campaign.openRate,
        clickRate: campaign.clickRate,
        conversionRate: campaign.conversionRate,
        revenue: campaign.revenue,
        roi: campaign.roi,
      })),
      overallMetrics: {
        averageOpenRate: Math.round(avgMetrics?.avgOpenRate || 0),
        averageClickRate: Math.round(avgMetrics?.avgClickRate || 0),
        averageConversionRate: Math.round(avgMetrics?.avgConversionRate || 0),
        totalRevenue: parseFloat(avgMetrics?.totalRevenue || '0'),
        totalSent: parseInt(avgMetrics?.totalSent || '0'),
        totalDelivered: parseInt(avgMetrics?.totalDelivered || '0'),
        totalOpened: parseInt(avgMetrics?.totalOpened || '0'),
        totalClicked: parseInt(avgMetrics?.totalClicked || '0'),
        totalConverted: parseInt(avgMetrics?.totalConverted || '0'),
      },
    };
  }

  async getInventoryAnalytics() {
    const totalProducts = await this.productsRepository.count();
    const activeProducts = await this.productsRepository.count({ where: { status: ProductStatus.ACTIVE } });
    const lowStockProducts = await this.productsRepository
      .createQueryBuilder('product')
      .where('product.stock <= product.minStock')
      .getCount();

    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
    
    const expiringProducts = await this.productsRepository
      .createQueryBuilder('product')
      .where('product.expirationDate <= :date', { date: thirtyDaysFromNow })
      .andWhere('product.expirationDate > :now', { now: new Date() })
      .getCount();

    const expiredProducts = await this.productsRepository
      .createQueryBuilder('product')
      .where('product.expirationDate <= :now', { now: new Date() })
      .getCount();

    const stockByCategory = await this.productsRepository
      .createQueryBuilder('product')
      .select('product.category', 'category')
      .addSelect('SUM(product.stock)', 'totalStock')
      .addSelect('COUNT(*)', 'productCount')
      .groupBy('product.category')
      .getRawMany();

    const stockValue = await this.productsRepository
      .createQueryBuilder('product')
      .select('SUM(product.stock * product.costPrice)', 'totalValue')
      .getRawOne();

    return {
      overview: {
        totalProducts,
        activeProducts,
        lowStockProducts,
        expiringProducts,
        expiredProducts,
        totalStockValue: parseFloat(stockValue?.totalValue || '0'),
      },
      stockByCategory: stockByCategory.map(item => ({
        category: item.category,
        totalStock: parseInt(item.totalStock),
        productCount: parseInt(item.productCount),
      })),
    };
  }

  async getUsersAnalytics(period: 'week' | 'month' | 'quarter' | 'year' = 'month') {
    const days = this.getPeriodDays(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const userGrowth = await this.getUserGrowthData(startDate);
    const usersByRole = await this.usersRepository
      .createQueryBuilder('user')
      .select('user.role', 'role')
      .addSelect('COUNT(*)', 'count')
      .groupBy('user.role')
      .getRawMany();

    const activeUsers = await this.usersRepository.count({ where: { status: UserStatus.ACTIVE } });
    const inactiveUsers = await this.usersRepository.count({ where: { status: UserStatus.INACTIVE } });

    return {
      period,
      userGrowth,
      usersByRole: usersByRole.map(item => ({
        role: item.role,
        count: parseInt(item.count),
      })),
      userStatus: {
        active: activeUsers,
        inactive: inactiveUsers,
        total: activeUsers + inactiveUsers,
      },
    };
  }

  // Métodos auxiliares privados

  private getPeriodDays(period: string): number {
    switch (period) {
      case 'week': return 7;
      case 'month': return 30;
      case 'quarter': return 90;
      case 'year': return 365;
      default: return 30;
    }
  }

  private async generateSalesData(startDate: Date, endDate: Date) {
    const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const salesData = [];

    for (let i = 0; i < days; i++) {
      const date = new Date(startDate);
      date.setDate(date.getDate() + i);
      
      // Simular dados de vendas realistas
      const baseOrders = Math.floor(Math.random() * 50) + 10;
      const avgOrderValue = Math.floor(Math.random() * 100) + 50;
      
      salesData.push({
        date: date.toISOString().split('T')[0],
        orders: baseOrders,
        revenue: baseOrders * avgOrderValue,
        customers: Math.floor(baseOrders * 0.8), // 80% de conversão
      });
    }

    return salesData;
  }

  private async getRevenueByCategory(startDate: Date) {
    // Simular receita por categoria
    const categories = ['medication', 'cosmetics', 'supplements', 'hygiene', 'medical_devices'];
    
    return categories.map(category => ({
      category,
      revenue: Math.floor(Math.random() * 10000) + 1000,
      percentage: Math.floor(Math.random() * 30) + 10,
    }));
  }

  private async getLeadsOverTime(startDate: Date) {
    const leads = await this.leadsRepository
      .createQueryBuilder('lead')
      .select('DATE(lead.createdAt)', 'date')
      .addSelect('COUNT(*)', 'count')
      .where('lead.createdAt >= :startDate', { startDate })
      .groupBy('DATE(lead.createdAt)')
      .orderBy('DATE(lead.createdAt)', 'ASC')
      .getRawMany();

    return leads.map(item => ({
      date: item.date,
      count: parseInt(item.count),
    }));
  }

  private async getConversionFunnel() {
    const total = await this.leadsRepository.count();
    const contacted = await this.leadsRepository.count({ where: { status: LeadStatus.CONTACTED } });
    const qualified = await this.leadsRepository.count({ where: { status: LeadStatus.QUALIFIED } });
    const converted = await this.leadsRepository.count({ where: { status: LeadStatus.CONVERTED } });

    return {
      total,
      contacted,
      qualified,
      converted,
      contactedRate: total > 0 ? Math.round((contacted / total) * 100) : 0,
      qualifiedRate: contacted > 0 ? Math.round((qualified / contacted) * 100) : 0,
      conversionRate: qualified > 0 ? Math.round((converted / qualified) * 100) : 0,
    };
  }

  private async getLeadsBySource(startDate: Date) {
    const leadsBySource = await this.leadsRepository
      .createQueryBuilder('lead')
      .select('lead.source', 'source')
      .addSelect('COUNT(*)', 'count')
      .where('lead.createdAt >= :startDate', { startDate })
      .groupBy('lead.source')
      .getRawMany();

    return leadsBySource.map(item => ({
      source: item.source,
      count: parseInt(item.count),
    }));
  }

  private async getLeadsByTemperature() {
    const leadsByTemperature = await this.leadsRepository
      .createQueryBuilder('lead')
      .select('lead.temperature', 'temperature')
      .addSelect('COUNT(*)', 'count')
      .groupBy('lead.temperature')
      .getRawMany();

    return leadsByTemperature.map(item => ({
      temperature: item.temperature,
      count: parseInt(item.count),
    }));
  }

  private async getUserGrowthData(startDate: Date) {
    const userGrowth = await this.usersRepository
      .createQueryBuilder('user')
      .select('DATE(user.createdAt)', 'date')
      .addSelect('COUNT(*)', 'count')
      .where('user.createdAt >= :startDate', { startDate })
      .groupBy('DATE(user.createdAt)')
      .orderBy('DATE(user.createdAt)', 'ASC')
      .getRawMany();

    return userGrowth.map(item => ({
      date: item.date,
      count: parseInt(item.count),
    }));
  }
}

