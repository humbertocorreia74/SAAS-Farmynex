import { IsString, IsOptional, IsBoolean, IsEnum } from 'class-validator';
import { LogoPosition } from '../entities/pharmacy-branding.entity';

export class CreateBrandingDto {
  @IsString()
  pharmacyName: string;

  @IsOptional()
  @IsString()
  slogan?: string;

  @IsString()
  cnpj: string;

  @IsOptional()
  @IsString()
  inscricaoEstadual?: string;

  @IsOptional()
  @IsString()
  responsavelTecnico?: string;

  @IsOptional()
  @IsString()
  crf?: string;

  @IsString()
  endereco: string;

  @IsString()
  cidade: string;

  @IsString()
  estado: string;

  @IsString()
  cep: string;

  @IsOptional()
  @IsString()
  telefone?: string;

  @IsOptional()
  @IsString()
  email?: string;

  @IsOptional()
  @IsString()
  licencaFuncionamento?: string;

  @IsOptional()
  @IsString()
  autorizacaoAnvisa?: string;

  @IsOptional()
  @IsString()
  logoUrl?: string;

  @IsOptional()
  @IsEnum(LogoPosition)
  logoPosition?: LogoPosition;

  @IsOptional()
  @IsString()
  primaryColor?: string;

  @IsOptional()
  @IsString()
  secondaryColor?: string;

  @IsOptional()
  @IsBoolean()
  showLogo?: boolean;

  @IsOptional()
  @IsBoolean()
  showSlogan?: boolean;

  @IsOptional()
  @IsBoolean()
  showFiscalData?: boolean;
}

