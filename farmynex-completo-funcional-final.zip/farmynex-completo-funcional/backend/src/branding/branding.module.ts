import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BrandingController } from './branding.controller';
import { BrandingService } from './branding.service';
import { PharmacyBranding } from './entities/pharmacy-branding.entity';

@Module({
  imports: [TypeOrmModule.forFeature([PharmacyBranding])],
  controllers: [BrandingController],
  providers: [BrandingService],
  exports: [BrandingService],
})
export class BrandingModule {}

