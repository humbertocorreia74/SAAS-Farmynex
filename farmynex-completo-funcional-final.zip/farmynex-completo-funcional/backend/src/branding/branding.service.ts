import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PharmacyBranding, LogoPosition } from './entities/pharmacy-branding.entity';
import { CreateBrandingDto } from './dto/create-branding.dto';
import { UpdateBrandingDto } from './dto/update-branding.dto';

@Injectable()
export class BrandingService {
  constructor(
    @InjectRepository(PharmacyBranding)
    private brandingRepository: Repository<PharmacyBranding>,
  ) {}

  async create(userId: string, createBrandingDto: CreateBrandingDto): Promise<PharmacyBranding> {
    const branding = this.brandingRepository.create({
      ...createBrandingDto,
      userId,
    });
    return this.brandingRepository.save(branding);
  }

  async findByUserId(userId: string): Promise<PharmacyBranding> {
    const branding = await this.brandingRepository.findOne({
      where: { userId, isActive: true },
    });
    
    if (!branding) {
      throw new NotFoundException('Branding não encontrado para este usuário');
    }
    
    return branding;
  }

  async update(userId: string, updateBrandingDto: UpdateBrandingDto): Promise<PharmacyBranding> {
    const branding = await this.findByUserId(userId);
    Object.assign(branding, updateBrandingDto);
    return this.brandingRepository.save(branding);
  }

  async generateDashboardBranding(userId: string): Promise<any> {
    try {
      const branding = await this.findByUserId(userId);
      
      return {
        styles: this.generateCustomStyles(branding),
        logoHtml: this.generateLogoHtml(branding),
        pharmacyInfoHtml: this.generatePharmacyInfoHtml(branding),
        fiscalInfoHtml: this.generateFiscalInfoHtml(branding),
      };
    } catch (error) {
      return this.getDefaultBranding();
    }
  }

  private generateCustomStyles(branding: PharmacyBranding): string {
    return `
      :root {
        --primary-color: ${branding.primaryColor};
        --secondary-color: ${branding.secondaryColor};
      }
      
      .pharmacy-logo {
        position: ${this.getLogoPositionStyle(branding.logoPosition)};
      }
      
      .pharmacy-branding {
        color: var(--primary-color);
      }
      
      .pharmacy-info {
        font-size: 12px;
        opacity: 0.8;
      }
    `;
  }

  private generateLogoHtml(branding: PharmacyBranding): string {
    if (!branding.showLogo || !branding.logoUrl) {
      return '';
    }

    return `
      <div class="pharmacy-logo">
        <img src="${branding.logoUrl}" 
             alt="${branding.pharmacyName}" 
             style="max-width: 150px; max-height: 75px; object-fit: contain;" />
      </div>
    `;
  }

  private generatePharmacyInfoHtml(branding: PharmacyBranding): string {
    const parts = [];
    
    if (branding.showSlogan && branding.slogan) {
      parts.push(`<div class="pharmacy-slogan">${branding.slogan}</div>`);
    }
    
    if (branding.telefone) parts.push(`Tel: ${branding.telefone}`);
    if (branding.email) parts.push(`Email: ${branding.email}`);

    return parts.length > 0 ? `
      <div class="pharmacy-info">
        ${parts.join(' | ')}
      </div>
    ` : '';
  }

  private generateFiscalInfoHtml(branding: PharmacyBranding): string {
    if (!branding.showFiscalData) {
      return '';
    }

    const fiscalInfo = branding.getFiscalInfo();
    const address = branding.getFullAddress();

    return `
      <div class="pharmacy-fiscal-info" style="font-size: 10px; opacity: 0.7;">
        <div>${branding.pharmacyName}</div>
        <div>${fiscalInfo}</div>
        <div>${address}</div>
      </div>
    `;
  }

  private getLogoPositionStyle(position: LogoPosition): string {
    switch (position) {
      case LogoPosition.TOP_LEFT:
        return 'absolute; top: 10px; left: 10px;';
      case LogoPosition.TOP_RIGHT:
        return 'absolute; top: 10px; right: 10px;';
      case LogoPosition.BOTTOM_LEFT:
        return 'absolute; bottom: 10px; left: 10px;';
      case LogoPosition.BOTTOM_RIGHT:
        return 'absolute; bottom: 10px; right: 10px;';
      case LogoPosition.CENTER:
        return 'absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);';
      default:
        return 'absolute; bottom: 10px; left: 10px;';
    }
  }

  private getDefaultBranding(): any {
    return {
      styles: `
        :root {
          --primary-color: #1976d2;
          --secondary-color: #dc004e;
        }
      `,
      logoHtml: '',
      pharmacyInfoHtml: '',
      fiscalInfoHtml: `
        <div class="pharmacy-fiscal-info" style="font-size: 10px; opacity: 0.7;">
          <div>Farmynex - Sistema de Gestão Farmacêutica</div>
          <div>www.farmynex.com.br</div>
        </div>
      `,
    };
  }
}

