import { Controller, Get, Post, Put, Body, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { BrandingService } from './branding.service';
import { CreateBrandingDto } from './dto/create-branding.dto';
import { UpdateBrandingDto } from './dto/update-branding.dto';

@ApiTags('branding')
@ApiBearerAuth()
@Controller('branding')
export class BrandingController {
  constructor(private readonly brandingService: BrandingService) {}

  @Post()
  async create(@Body() createBrandingDto: CreateBrandingDto, @Request() req: any) {
    return this.brandingService.create(req.user.id, createBrandingDto);
  }

  @Get()
  async findMine(@Request() req: any) {
    return this.brandingService.findByUserId(req.user.id);
  }

  @Put()
  async update(@Body() updateBrandingDto: UpdateBrandingDto, @Request() req: any) {
    return this.brandingService.update(req.user.id, updateBrandingDto);
  }

  @Get('dashboard')
  async getDashboardBranding(@Request() req: any) {
    return this.brandingService.generateDashboardBranding(req.user.id);
  }
}

