import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

export enum LogoPosition {
  TOP_LEFT = 'top-left',
  TOP_RIGHT = 'top-right',
  BOTTOM_LEFT = 'bottom-left',
  BOTTOM_RIGHT = 'bottom-right',
  CENTER = 'center'
}

@Entity('pharmacy_branding')
export class PharmacyBranding {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  userId: string; // ID do usuário/farmácia

  // Informações da Farmácia
  @Column()
  pharmacyName: string;

  @Column({ nullable: true })
  slogan: string;

  // Dados Fiscais
  @Column()
  cnpj: string;

  @Column({ nullable: true })
  inscricaoEstadual: string;

  @Column({ nullable: true })
  responsavelTecnico: string;

  @Column({ nullable: true })
  crf: string; // Conselho Regional de Farmácia

  // Endereço
  @Column()
  endereco: string;

  @Column()
  cidade: string;

  @Column()
  estado: string;

  @Column()
  cep: string;

  @Column({ nullable: true })
  telefone: string;

  @Column({ nullable: true })
  email: string;

  // Licenças
  @Column({ nullable: true })
  licencaFuncionamento: string;

  @Column({ nullable: true })
  autorizacaoAnvisa: string;

  // Branding Visual
  @Column({ nullable: true })
  logoUrl: string;

  @Column({
    type: 'text',
    enum: LogoPosition,
    default: LogoPosition.BOTTOM_LEFT
  })
  logoPosition: LogoPosition;

  @Column({ default: '#1976d2' })
  primaryColor: string;

  @Column({ default: '#dc004e' })
  secondaryColor: string;

  // Configurações de Exibição
  @Column({ default: true })
  showLogo: boolean;

  @Column({ default: true })
  showSlogan: boolean;

  @Column({ default: true })
  showFiscalData: boolean;

  @Column({ default: true })
  isActive: boolean;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Método para obter informações fiscais formatadas
  getFiscalInfo(): string {
    const parts = [];
    
    if (this.cnpj) parts.push(`CNPJ: ${this.formatCNPJ(this.cnpj)}`);
    if (this.inscricaoEstadual) parts.push(`IE: ${this.inscricaoEstadual}`);
    if (this.responsavelTecnico && this.crf) {
      parts.push(`Resp. Técnico: ${this.responsavelTecnico} - CRF: ${this.crf}`);
    }
    
    return parts.join(' | ');
  }

  // Método para formatar CNPJ
  private formatCNPJ(cnpj: string): string {
    return cnpj.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
  }

  // Método para obter endereço completo
  getFullAddress(): string {
    return `${this.endereco}, ${this.cidade}/${this.estado} - CEP: ${this.cep}`;
  }
}

