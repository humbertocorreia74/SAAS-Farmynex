import { Injectable } from '@nestjs/common';
import { TypeOrmOptionsFactory, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { ConfigService } from '@nestjs/config';
import { User } from '../users/entities/user.entity';
import { Product } from '../products/entities/product.entity';
import { Lead } from '../leads/entities/lead.entity';
import { Campaign } from '../campaigns/entities/campaign.entity';

@Injectable()
export class DatabaseConfig implements TypeOrmOptionsFactory {
  constructor(private configService: ConfigService) {}

  createTypeOrmOptions(): TypeOrmModuleOptions {
    const isProduction = this.configService.get('NODE_ENV') === 'production';

    if (isProduction) {
      // Configuração para PostgreSQL em produção
      return {
        type: 'postgres',
        host: this.configService.get('DB_HOST', 'localhost'),
        port: this.configService.get('DB_PORT', 5432),
        username: this.configService.get('DB_USERNAME', 'farmynex'),
        password: this.configService.get('DB_PASSWORD', 'farmynex123'),
        database: this.configService.get('DB_DATABASE', 'farmynex'),
        entities: [User, Product, Lead, Campaign],
        synchronize: false, // Usar migrations em produção
        logging: false,
        ssl: this.configService.get('DB_SSL') === 'true' ? { rejectUnauthorized: false } : false,
      };
    } else {
      // Configuração para SQLite em desenvolvimento
      return {
        type: 'sqlite',
        database: 'farmynex.db',
        entities: [User, Product, Lead, Campaign],
        synchronize: true, // Auto-criar tabelas em desenvolvimento
        logging: true,
      };
    }
  }
}