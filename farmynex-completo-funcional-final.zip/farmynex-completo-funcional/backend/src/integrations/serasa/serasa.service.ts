import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';

export interface SerasaScore {
  cpf: string;
  nome: string;
  score: number;
  faixaScore: string;
  dataConsulta: string;
  probabilidadeInadimplencia: number;
  fatoresPositivos: string[];
  fatoresNegativos: string[];
  recomendacoes: string[];
}

export interface SerasaEmpresa {
  cnpj: string;
  razaoSocial: string;
  nomeFantasia: string;
  score: number;
  faixaScore: string;
  situacaoCredito: string;
  dataConsulta: string;
  indicadores: {
    pontualidadePagamento: number;
    relacionamentoBancario: number;
    experienciaCredito: number;
    comportamentoFinanceiro: number;
  };
  alertas: string[];
  recomendacoes: string[];
}

export interface SerasaRestricao {
  tipo: string;
  origem: string;
  valor: number;
  dataInclusao: string;
  dataVencimento: string;
  situacao: string;
}

@Injectable()
export class SerasaService {
  private readonly logger = new Logger(SerasaService.name);
  private readonly baseUrl = 'https://api.serasa.com.br';

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
  ) {}

  /**
   * Consulta score de pessoa física
   */
  async consultarScorePF(cpf: string): Promise<SerasaScore | null> {
    try {
      this.logger.log(`Consultando score Serasa PF: ${cpf}`);
      
      const cpfLimpo = cpf.replace(/[^\d]/g, '');
      
      if (cpfLimpo.length !== 11) {
        throw new Error('CPF deve conter 11 dígitos');
      }

      // Simulação de consulta de score
      const mockScore: SerasaScore = {
        cpf: cpfLimpo,
        nome: 'João da Silva',
        score: 650,
        faixaScore: 'REGULAR',
        dataConsulta: new Date().toISOString(),
        probabilidadeInadimplencia: 25.5,
        fatoresPositivos: [
          'Relacionamento bancário longo',
          'Histórico de pagamentos em dia',
          'Renda comprovada'
        ],
        fatoresNegativos: [
          'Consultas frequentes ao CPF',
          'Utilização alta do cartão de crédito'
        ],
        recomendacoes: [
          'Manter contas em dia',
          'Reduzir utilização do cartão de crédito',
          'Diversificar relacionamento bancário'
        ]
      };

      return mockScore;
    } catch (error) {
      this.logger.error(`Erro ao consultar score PF: ${error.message}`);
      throw new Error('Falha na consulta de score Serasa');
    }
  }

  /**
   * Consulta score de pessoa jurídica
   */
  async consultarScorePJ(cnpj: string): Promise<SerasaEmpresa | null> {
    try {
      this.logger.log(`Consultando score Serasa PJ: ${cnpj}`);
      
      const cnpjLimpo = cnpj.replace(/[^\d]/g, '');
      
      if (cnpjLimpo.length !== 14) {
        throw new Error('CNPJ deve conter 14 dígitos');
      }

      // Simulação de consulta de score empresarial
      const mockEmpresa: SerasaEmpresa = {
        cnpj: cnpjLimpo,
        razaoSocial: 'Farmácia Central Ltda',
        nomeFantasia: 'Farmácia Central',
        score: 720,
        faixaScore: 'BOM',
        situacaoCredito: 'POSITIVA',
        dataConsulta: new Date().toISOString(),
        indicadores: {
          pontualidadePagamento: 85,
          relacionamentoBancario: 78,
          experienciaCredito: 82,
          comportamentoFinanceiro: 75
        },
        alertas: [],
        recomendacoes: [
          'Manter pontualidade nos pagamentos',
          'Diversificar fornecedores',
          'Monitorar fluxo de caixa'
        ]
      };

      return mockEmpresa;
    } catch (error) {
      this.logger.error(`Erro ao consultar score PJ: ${error.message}`);
      throw new Error('Falha na consulta de score empresarial');
    }
  }

  /**
   * Consulta restrições de CPF
   */
  async consultarRestricoesPF(cpf: string): Promise<SerasaRestricao[]> {
    try {
      this.logger.log(`Consultando restrições Serasa PF: ${cpf}`);
      
      const cpfLimpo = cpf.replace(/[^\d]/g, '');
      
      if (cpfLimpo.length !== 11) {
        throw new Error('CPF deve conter 11 dígitos');
      }

      // Simulação de consulta de restrições
      const mockRestricoes: SerasaRestricao[] = [
        // Exemplo de CPF sem restrições
      ];

      return mockRestricoes;
    } catch (error) {
      this.logger.error(`Erro ao consultar restrições PF: ${error.message}`);
      throw new Error('Falha na consulta de restrições');
    }
  }

  /**
   * Consulta restrições de CNPJ
   */
  async consultarRestricoesPJ(cnpj: string): Promise<SerasaRestricao[]> {
    try {
      this.logger.log(`Consultando restrições Serasa PJ: ${cnpj}`);
      
      const cnpjLimpo = cnpj.replace(/[^\d]/g, '');
      
      if (cnpjLimpo.length !== 14) {
        throw new Error('CNPJ deve conter 14 dígitos');
      }

      // Simulação de consulta de restrições empresariais
      const mockRestricoes: SerasaRestricao[] = [
        // Exemplo de empresa sem restrições
      ];

      return mockRestricoes;
    } catch (error) {
      this.logger.error(`Erro ao consultar restrições PJ: ${error.message}`);
      throw new Error('Falha na consulta de restrições empresariais');
    }
  }

  /**
   * Analisa risco de crédito para pessoa física
   */
  async analisarRiscoPF(cpf: string, valorCredito: number): Promise<{
    aprovado: boolean;
    score: number;
    risco: string;
    limiteSugerido: number;
    condicoes: string[];
    observacoes: string[];
  }> {
    try {
      const score = await this.consultarScorePF(cpf);
      const restricoes = await this.consultarRestricoesPF(cpf);
      
      if (!score) {
        throw new Error('Não foi possível obter score do cliente');
      }

      let aprovado = false;
      let risco = 'ALTO';
      let limiteSugerido = 0;
      const condicoes: string[] = [];
      const observacoes: string[] = [];

      // Análise baseada no score
      if (score.score >= 700) {
        aprovado = true;
        risco = 'BAIXO';
        limiteSugerido = valorCredito;
        condicoes.push('Crédito pré-aprovado');
      } else if (score.score >= 500) {
        aprovado = true;
        risco = 'MÉDIO';
        limiteSugerido = Math.min(valorCredito, valorCredito * 0.7);
        condicoes.push('Análise de renda necessária');
        condicoes.push('Garantia adicional recomendada');
      } else {
        aprovado = false;
        risco = 'ALTO';
        limiteSugerido = 0;
        observacoes.push('Score abaixo do mínimo aceitável');
      }

      // Verifica restrições
      if (restricoes.length > 0) {
        aprovado = false;
        risco = 'ALTO';
        limiteSugerido = 0;
        observacoes.push('Cliente possui restrições ativas');
      }

      return {
        aprovado,
        score: score.score,
        risco,
        limiteSugerido,
        condicoes,
        observacoes
      };
    } catch (error) {
      this.logger.error(`Erro ao analisar risco PF: ${error.message}`);
      throw new Error('Falha na análise de risco');
    }
  }

  /**
   * Analisa risco de crédito para pessoa jurídica
   */
  async analisarRiscoPJ(cnpj: string, valorCredito: number): Promise<{
    aprovado: boolean;
    score: number;
    risco: string;
    limiteSugerido: number;
    condicoes: string[];
    observacoes: string[];
  }> {
    try {
      const empresa = await this.consultarScorePJ(cnpj);
      const restricoes = await this.consultarRestricoesPJ(cnpj);
      
      if (!empresa) {
        throw new Error('Não foi possível obter dados da empresa');
      }

      let aprovado = false;
      let risco = 'ALTO';
      let limiteSugerido = 0;
      const condicoes: string[] = [];
      const observacoes: string[] = [];

      // Análise baseada no score empresarial
      if (empresa.score >= 750) {
        aprovado = true;
        risco = 'BAIXO';
        limiteSugerido = valorCredito;
        condicoes.push('Crédito empresarial pré-aprovado');
      } else if (empresa.score >= 600) {
        aprovado = true;
        risco = 'MÉDIO';
        limiteSugerido = Math.min(valorCredito, valorCredito * 0.8);
        condicoes.push('Análise de faturamento necessária');
        condicoes.push('Garantia real recomendada');
      } else {
        aprovado = false;
        risco = 'ALTO';
        limiteSugerido = 0;
        observacoes.push('Score empresarial abaixo do mínimo');
      }

      // Verifica restrições
      if (restricoes.length > 0) {
        aprovado = false;
        risco = 'ALTO';
        limiteSugerido = 0;
        observacoes.push('Empresa possui restrições ativas');
      }

      // Verifica situação de crédito
      if (empresa.situacaoCredito !== 'POSITIVA') {
        risco = 'ALTO';
        observacoes.push(`Situação de crédito: ${empresa.situacaoCredito}`);
      }

      return {
        aprovado,
        score: empresa.score,
        risco,
        limiteSugerido,
        condicoes,
        observacoes
      };
    } catch (error) {
      this.logger.error(`Erro ao analisar risco PJ: ${error.message}`);
      throw new Error('Falha na análise de risco empresarial');
    }
  }

  /**
   * Monitora alterações no score
   */
  async monitorarScore(documento: string, tipo: 'CPF' | 'CNPJ'): Promise<{
    monitoramentoAtivo: boolean;
    ultimaConsulta: string;
    proximaVerificacao: string;
    alertasConfigurados: string[];
  }> {
    try {
      this.logger.log(`Configurando monitoramento de score: ${documento}`);
      
      // Simulação de configuração de monitoramento
      const monitoramento = {
        monitoramentoAtivo: true,
        ultimaConsulta: new Date().toISOString(),
        proximaVerificacao: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 dias
        alertasConfigurados: [
          'Alteração significativa no score',
          'Novas restrições incluídas',
          'Melhoria na classificação de risco'
        ]
      };

      return monitoramento;
    } catch (error) {
      this.logger.error(`Erro ao configurar monitoramento: ${error.message}`);
      throw new Error('Falha na configuração do monitoramento');
    }
  }

  /**
   * Gera relatório de análise de carteira
   */
  async gerarRelatorioCarteira(documentos: string[]): Promise<{
    totalClientes: number;
    distribuicaoScore: Record<string, number>;
    riscosIdentificados: number;
    recomendacoes: string[];
    detalhes: Array<{
      documento: string;
      nome: string;
      score: number;
      risco: string;
      restricoes: number;
    }>;
  }> {
    try {
      this.logger.log(`Gerando relatório de carteira: ${documentos.length} clientes`);
      
      const detalhes = [];
      const distribuicaoScore = {
        'EXCELENTE': 0,
        'BOM': 0,
        'REGULAR': 0,
        'RUIM': 0
      };
      let riscosIdentificados = 0;

      for (const documento of documentos) {
        try {
          const isCpf = documento.replace(/[^\d]/g, '').length === 11;
          
          if (isCpf) {
            const score = await this.consultarScorePF(documento);
            const restricoes = await this.consultarRestricoesPF(documento);
            
            if (score) {
              let faixaScore = 'RUIM';
              if (score.score >= 800) faixaScore = 'EXCELENTE';
              else if (score.score >= 650) faixaScore = 'BOM';
              else if (score.score >= 500) faixaScore = 'REGULAR';
              
              distribuicaoScore[faixaScore]++;
              
              if (restricoes.length > 0 || score.score < 500) {
                riscosIdentificados++;
              }
              
              detalhes.push({
                documento,
                nome: score.nome,
                score: score.score,
                risco: score.faixaScore,
                restricoes: restricoes.length
              });
            }
          } else {
            const empresa = await this.consultarScorePJ(documento);
            const restricoes = await this.consultarRestricoesPJ(documento);
            
            if (empresa) {
              let faixaScore = 'RUIM';
              if (empresa.score >= 800) faixaScore = 'EXCELENTE';
              else if (empresa.score >= 650) faixaScore = 'BOM';
              else if (empresa.score >= 500) faixaScore = 'REGULAR';
              
              distribuicaoScore[faixaScore]++;
              
              if (restricoes.length > 0 || empresa.score < 500) {
                riscosIdentificados++;
              }
              
              detalhes.push({
                documento,
                nome: empresa.razaoSocial,
                score: empresa.score,
                risco: empresa.faixaScore,
                restricoes: restricoes.length
              });
            }
          }
        } catch (error) {
          this.logger.warn(`Erro ao processar documento ${documento}: ${error.message}`);
        }
      }

      const recomendacoes = [
        'Monitorar clientes com score abaixo de 500',
        'Implementar política de crédito baseada em score',
        'Revisar limites de clientes com restrições',
        'Configurar alertas para mudanças significativas'
      ];

      return {
        totalClientes: detalhes.length,
        distribuicaoScore,
        riscosIdentificados,
        recomendacoes,
        detalhes
      };
    } catch (error) {
      this.logger.error(`Erro ao gerar relatório de carteira: ${error.message}`);
      throw new Error('Falha na geração do relatório de carteira');
    }
  }
}

