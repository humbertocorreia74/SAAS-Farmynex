import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';

export interface SefazNFe {
  chaveAcesso: string;
  numeroNota: string;
  serie: string;
  dataEmissao: string;
  dataAutorizacao: string;
  situacao: string;
  tipoOperacao: string;
  emitente: {
    cnpj: string;
    razaoSocial: string;
    inscricaoEstadual: string;
  };
  destinatario: {
    documento: string;
    nome: string;
    endereco: {
      logradouro: string;
      numero: string;
      bairro: string;
      municipio: string;
      uf: string;
      cep: string;
    };
  };
  itens: Array<{
    codigo: string;
    descricao: string;
    quantidade: number;
    unidade: string;
    valorUnitario: number;
    valorTotal: number;
    ncm: string;
    cfop: string;
    icms: {
      situacaoTributaria: string;
      aliquota: number;
      valor: number;
    };
  }>;
  totais: {
    valorProdutos: number;
    valorFrete: number;
    valorSeguro: number;
    valorDesconto: number;
    valorTotal: number;
    valorTributos: number;
  };
  protocolo: string;
}

export interface SefazCTe {
  chaveAcesso: string;
  numeroCte: string;
  serie: string;
  dataEmissao: string;
  situacao: string;
  emitente: {
    cnpj: string;
    razaoSocial: string;
  };
  remetente: {
    documento: string;
    nome: string;
  };
  destinatario: {
    documento: string;
    nome: string;
  };
  valorServico: number;
  valorReceber: number;
  protocolo: string;
}

@Injectable()
export class SefazService {
  private readonly logger = new Logger(SefazService.name);
  private readonly baseUrl = 'https://nfe.fazenda.gov.br/api';

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
  ) {}

  /**
   * Consulta NFe por chave de acesso
   */
  async consultarNFe(chaveAcesso: string): Promise<SefazNFe | null> {
    try {
      this.logger.log(`Consultando NFe SEFAZ: ${chaveAcesso}`);
      
      if (chaveAcesso.length !== 44) {
        throw new Error('Chave de acesso deve conter 44 dígitos');
      }

      // Simulação de consulta NFe
      const mockNFe: SefazNFe = {
        chaveAcesso,
        numeroNota: '000000123',
        serie: '001',
        dataEmissao: '2024-12-08',
        dataAutorizacao: '2024-12-08T10:30:00',
        situacao: 'AUTORIZADA',
        tipoOperacao: 'SAIDA',
        emitente: {
          cnpj: '12345678000190',
          razaoSocial: 'Distribuidora Farmacêutica Ltda',
          inscricaoEstadual: '123456789'
        },
        destinatario: {
          documento: '98765432000100',
          nome: 'Farmácia Central Ltda',
          endereco: {
            logradouro: 'Rua das Flores',
            numero: '123',
            bairro: 'Centro',
            municipio: 'São Paulo',
            uf: 'SP',
            cep: '01234567'
          }
        },
        itens: [
          {
            codigo: 'MED001',
            descricao: 'Dipirona Sódica 500mg - Caixa com 20 comprimidos',
            quantidade: 10,
            unidade: 'CX',
            valorUnitario: 15.50,
            valorTotal: 155.00,
            ncm: '30049099',
            cfop: '5102',
            icms: {
              situacaoTributaria: '00',
              aliquota: 18,
              valor: 27.90
            }
          },
          {
            codigo: 'MED002',
            descricao: 'Paracetamol 750mg - Caixa com 20 comprimidos',
            quantidade: 5,
            unidade: 'CX',
            valorUnitario: 12.80,
            valorTotal: 64.00,
            ncm: '30049099',
            cfop: '5102',
            icms: {
              situacaoTributaria: '00',
              aliquota: 18,
              valor: 11.52
            }
          }
        ],
        totais: {
          valorProdutos: 219.00,
          valorFrete: 0.00,
          valorSeguro: 0.00,
          valorDesconto: 0.00,
          valorTotal: 219.00,
          valorTributos: 39.42
        },
        protocolo: '135240000000123'
      };

      return mockNFe;
    } catch (error) {
      this.logger.error(`Erro ao consultar NFe: ${error.message}`);
      throw new Error('Falha na consulta NFe SEFAZ');
    }
  }

  /**
   * Consulta situação da NFe
   */
  async consultarSituacaoNFe(chaveAcesso: string): Promise<{
    chaveAcesso: string;
    situacao: string;
    dataConsulta: string;
    protocolo: string;
    motivo: string;
  }> {
    try {
      this.logger.log(`Consultando situação NFe: ${chaveAcesso}`);
      
      const nfe = await this.consultarNFe(chaveAcesso);
      
      if (!nfe) {
        return {
          chaveAcesso,
          situacao: 'NAO_ENCONTRADA',
          dataConsulta: new Date().toISOString(),
          protocolo: '',
          motivo: 'NFe não encontrada na base da SEFAZ'
        };
      }

      return {
        chaveAcesso,
        situacao: nfe.situacao,
        dataConsulta: new Date().toISOString(),
        protocolo: nfe.protocolo,
        motivo: 'Autorizado o uso da NFe'
      };
    } catch (error) {
      this.logger.error(`Erro ao consultar situação NFe: ${error.message}`);
      throw new Error('Falha na consulta de situação NFe');
    }
  }

  /**
   * Consulta CTe por chave de acesso
   */
  async consultarCTe(chaveAcesso: string): Promise<SefazCTe | null> {
    try {
      this.logger.log(`Consultando CTe SEFAZ: ${chaveAcesso}`);
      
      if (chaveAcesso.length !== 44) {
        throw new Error('Chave de acesso deve conter 44 dígitos');
      }

      // Simulação de consulta CTe
      const mockCTe: SefazCTe = {
        chaveAcesso,
        numeroCte: '000000456',
        serie: '001',
        dataEmissao: '2024-12-08',
        situacao: 'AUTORIZADO',
        emitente: {
          cnpj: '11222333000144',
          razaoSocial: 'Transportadora Express Ltda'
        },
        remetente: {
          documento: '12345678000190',
          nome: 'Distribuidora Farmacêutica Ltda'
        },
        destinatario: {
          documento: '98765432000100',
          nome: 'Farmácia Central Ltda'
        },
        valorServico: 25.00,
        valorReceber: 25.00,
        protocolo: '135240000000456'
      };

      return mockCTe;
    } catch (error) {
      this.logger.error(`Erro ao consultar CTe: ${error.message}`);
      throw new Error('Falha na consulta CTe SEFAZ');
    }
  }

  /**
   * Valida chave de acesso
   */
  async validarChaveAcesso(chaveAcesso: string): Promise<boolean> {
    try {
      if (chaveAcesso.length !== 44) {
        return false;
      }

      // Validação do dígito verificador da chave de acesso
      const chave = chaveAcesso.substring(0, 43);
      const dv = parseInt(chaveAcesso.substring(43, 44));
      
      let soma = 0;
      let peso = 2;
      
      for (let i = chave.length - 1; i >= 0; i--) {
        soma += parseInt(chave.charAt(i)) * peso;
        peso = peso === 9 ? 2 : peso + 1;
      }
      
      const resto = soma % 11;
      const dvCalculado = resto < 2 ? 0 : 11 - resto;
      
      return dv === dvCalculado;
    } catch (error) {
      this.logger.error(`Erro ao validar chave de acesso: ${error.message}`);
      return false;
    }
  }

  /**
   * Consulta NFes por CNPJ e período
   */
  async consultarNFesPorPeriodo(
    cnpj: string,
    dataInicio: string,
    dataFim: string
  ): Promise<SefazNFe[]> {
    try {
      this.logger.log(`Consultando NFes por período: ${cnpj} - ${dataInicio} a ${dataFim}`);
      
      // Simulação de consulta por período
      const mockNFes: SefazNFe[] = [
        {
          chaveAcesso: '35241212345678000190550010000001231234567890',
          numeroNota: '000000123',
          serie: '001',
          dataEmissao: '2024-12-08',
          dataAutorizacao: '2024-12-08T10:30:00',
          situacao: 'AUTORIZADA',
          tipoOperacao: 'SAIDA',
          emitente: {
            cnpj: '12345678000190',
            razaoSocial: 'Distribuidora Farmacêutica Ltda',
            inscricaoEstadual: '123456789'
          },
          destinatario: {
            documento: '98765432000100',
            nome: 'Farmácia Central Ltda',
            endereco: {
              logradouro: 'Rua das Flores',
              numero: '123',
              bairro: 'Centro',
              municipio: 'São Paulo',
              uf: 'SP',
              cep: '01234567'
            }
          },
          itens: [],
          totais: {
            valorProdutos: 219.00,
            valorFrete: 0.00,
            valorSeguro: 0.00,
            valorDesconto: 0.00,
            valorTotal: 219.00,
            valorTributos: 39.42
          },
          protocolo: '135240000000123'
        }
      ];

      return mockNFes;
    } catch (error) {
      this.logger.error(`Erro ao consultar NFes por período: ${error.message}`);
      throw new Error('Falha na consulta de NFes por período');
    }
  }

  /**
   * Gera relatório fiscal
   */
  async gerarRelatorioFiscal(
    cnpj: string,
    dataInicio: string,
    dataFim: string
  ): Promise<{
    periodo: { inicio: string; fim: string };
    resumo: {
      totalNFes: number;
      valorTotalVendas: number;
      valorTotalTributos: number;
      nfesAutorizadas: number;
      nfesCanceladas: number;
    };
    detalhamento: {
      porMes: Record<string, { quantidade: number; valor: number }>;
      porProduto: Record<string, { quantidade: number; valor: number }>;
      tributos: {
        icms: number;
        ipi: number;
        pis: number;
        cofins: number;
      };
    };
  }> {
    try {
      this.logger.log(`Gerando relatório fiscal: ${cnpj} - ${dataInicio} a ${dataFim}`);
      
      const nfes = await this.consultarNFesPorPeriodo(cnpj, dataInicio, dataFim);
      
      const resumo = {
        totalNFes: nfes.length,
        valorTotalVendas: nfes.reduce((acc, nfe) => acc + nfe.totais.valorTotal, 0),
        valorTotalTributos: nfes.reduce((acc, nfe) => acc + nfe.totais.valorTributos, 0),
        nfesAutorizadas: nfes.filter(nfe => nfe.situacao === 'AUTORIZADA').length,
        nfesCanceladas: nfes.filter(nfe => nfe.situacao === 'CANCELADA').length
      };

      const porMes: Record<string, { quantidade: number; valor: number }> = {};
      const porProduto: Record<string, { quantidade: number; valor: number }> = {};

      nfes.forEach(nfe => {
        const mes = nfe.dataEmissao.substring(0, 7); // YYYY-MM
        
        if (!porMes[mes]) {
          porMes[mes] = { quantidade: 0, valor: 0 };
        }
        porMes[mes].quantidade++;
        porMes[mes].valor += nfe.totais.valorTotal;

        nfe.itens.forEach(item => {
          if (!porProduto[item.codigo]) {
            porProduto[item.codigo] = { quantidade: 0, valor: 0 };
          }
          porProduto[item.codigo].quantidade += item.quantidade;
          porProduto[item.codigo].valor += item.valorTotal;
        });
      });

      const tributos = {
        icms: nfes.reduce((acc, nfe) => 
          acc + nfe.itens.reduce((itemAcc, item) => itemAcc + item.icms.valor, 0), 0
        ),
        ipi: 0, // Simulação
        pis: 0, // Simulação
        cofins: 0 // Simulação
      };

      return {
        periodo: { inicio: dataInicio, fim: dataFim },
        resumo,
        detalhamento: {
          porMes,
          porProduto,
          tributos
        }
      };
    } catch (error) {
      this.logger.error(`Erro ao gerar relatório fiscal: ${error.message}`);
      throw new Error('Falha na geração do relatório fiscal');
    }
  }

  /**
   * Verifica regularidade fiscal
   */
  async verificarRegularidadeFiscal(cnpj: string): Promise<{
    regular: boolean;
    situacao: string;
    pendencias: string[];
    ultimaVerificacao: string;
  }> {
    try {
      this.logger.log(`Verificando regularidade fiscal: ${cnpj}`);
      
      // Simulação de verificação de regularidade
      const regularidade = {
        regular: true,
        situacao: 'ATIVA',
        pendencias: [],
        ultimaVerificacao: new Date().toISOString()
      };

      return regularidade;
    } catch (error) {
      this.logger.error(`Erro ao verificar regularidade fiscal: ${error.message}`);
      throw new Error('Falha na verificação de regularidade fiscal');
    }
  }

  /**
   * Consulta regime tributário
   */
  async consultarRegimeTributario(cnpj: string): Promise<{
    regime: string;
    dataOpcao: string;
    situacao: string;
    observacoes: string[];
  }> {
    try {
      this.logger.log(`Consultando regime tributário: ${cnpj}`);
      
      // Simulação de consulta de regime tributário
      const regime = {
        regime: 'SIMPLES_NACIONAL',
        dataOpcao: '2020-01-01',
        situacao: 'ATIVO',
        observacoes: [
          'Optante pelo Simples Nacional',
          'Enquadramento como Microempresa',
          'Sem pendências tributárias'
        ]
      };

      return regime;
    } catch (error) {
      this.logger.error(`Erro ao consultar regime tributário: ${error.message}`);
      throw new Error('Falha na consulta de regime tributário');
    }
  }
}

