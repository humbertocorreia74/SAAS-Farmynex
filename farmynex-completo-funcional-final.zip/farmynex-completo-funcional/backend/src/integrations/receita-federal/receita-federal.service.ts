import { Injectable, Logger, HttpException, HttpStatus } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

export interface ReceitaFederalEmpresa {
  cnpj: string;
  razaoSocial: string;
  nomeFantasia?: string;
  situacaoCadastral: string;
  dataSituacaoCadastral: string;
  motivoSituacaoCadastral: string;
  naturezaJuridica: string;
  dataInicioAtividade: string;
  cnae: {
    principal: {
      codigo: string;
      descricao: string;
    };
    secundarios: Array<{
      codigo: string;
      descricao: string;
    }>;
  };
  endereco: {
    logradouro: string;
    numero: string;
    complemento?: string;
    bairro: string;
    cep: string;
    municipio: string;
    uf: string;
  };
  telefone?: string;
  email?: string;
  capitalSocial: number;
  porte: string;
  quadroSocietario: Array<{
    nome: string;
    qualificacao: string;
    dataEntrada?: string;
  }>;
  simples?: {
    optante: boolean;
    dataOpcao?: string;
    dataExclusao?: string;
  };
  mei?: {
    optante: boolean;
    dataOpcao?: string;
  };
}

export interface ReceitaFederalCpf {
  cpf: string;
  nome: string;
  situacao: string;
  dataNascimento?: string;
  tituloEleitor?: string;
}

@Injectable()
export class ReceitaFederalService {
  private readonly logger = new Logger(ReceitaFederalService.name);
  
  // URLs das APIs públicas disponíveis
  private readonly receitaWsUrl = 'https://www.receitaws.com.br/v1/cnpj';
  private readonly govApiUrl = 'https://www.gov.br/conecta/catalogo/apis/consulta-cnpj';
  private readonly brasilApiUrl = 'https://brasilapi.com.br/api/cnpj/v1';

  constructor(private readonly httpService: HttpService) {}

  /**
   * Consulta dados de empresa por CNPJ
   */
  async consultarCnpj(cnpj: string): Promise<ReceitaFederalEmpresa | null> {
    try {
      this.logger.log(`Consultando CNPJ: ${cnpj}`);

      // Remove formatação do CNPJ
      const cnpjLimpo = cnpj.replace(/\D/g, '');

      if (cnpjLimpo.length !== 14) {
        throw new HttpException('CNPJ inválido', HttpStatus.BAD_REQUEST);
      }

      // Tenta consultar na BrasilAPI primeiro (mais confiável)
      let empresa = await this.consultarBrasilApi(cnpjLimpo);
      
      if (!empresa) {
        // Se falhar, tenta ReceitaWS
        empresa = await this.consultarReceitaWs(cnpjLimpo);
      }

      return empresa;

    } catch (error) {
      this.logger.error(`Erro ao consultar CNPJ: ${error.message}`);
      
      if (error instanceof HttpException) {
        throw error;
      }
      
      throw new HttpException(
        'Erro ao consultar dados na Receita Federal',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Consulta via BrasilAPI
   */
  private async consultarBrasilApi(cnpj: string): Promise<ReceitaFederalEmpresa | null> {
    try {
      const response = await firstValueFrom(
        this.httpService.get(`${this.brasilApiUrl}/${cnpj}`, {
          timeout: 10000,
        }),
      );

      if (response.data) {
        return this.mapearBrasilApiResponse(response.data);
      }

      return null;
    } catch (error) {
      this.logger.warn(`Erro na BrasilAPI: ${error.message}`);
      return null;
    }
  }

  /**
   * Consulta via ReceitaWS
   */
  private async consultarReceitaWs(cnpj: string): Promise<ReceitaFederalEmpresa | null> {
    try {
      const response = await firstValueFrom(
        this.httpService.get(`${this.receitaWsUrl}/${cnpj}`, {
          timeout: 10000,
        }),
      );

      if (response.data && response.data.status !== 'ERROR') {
        return this.mapearReceitaWsResponse(response.data);
      }

      return null;
    } catch (error) {
      this.logger.warn(`Erro na ReceitaWS: ${error.message}`);
      return null;
    }
  }

  /**
   * Mapeia resposta da BrasilAPI
   */
  private mapearBrasilApiResponse(data: any): ReceitaFederalEmpresa {
    return {
      cnpj: data.cnpj,
      razaoSocial: data.razao_social || data.nome,
      nomeFantasia: data.nome_fantasia,
      situacaoCadastral: data.descricao_situacao_cadastral || data.situacao,
      dataSituacaoCadastral: data.data_situacao_cadastral,
      motivoSituacaoCadastral: data.descricao_motivo_situacao_cadastral || '',
      naturezaJuridica: data.descricao_natureza_juridica || '',
      dataInicioAtividade: data.data_inicio_atividade,
      cnae: {
        principal: {
          codigo: data.cnae_fiscal?.toString() || '',
          descricao: data.cnae_fiscal_descricao || '',
        },
        secundarios: (data.cnaes_secundarios || []).map((cnae: any) => ({
          codigo: cnae.codigo?.toString() || '',
          descricao: cnae.descricao || '',
        })),
      },
      endereco: {
        logradouro: data.logradouro || '',
        numero: data.numero || '',
        complemento: data.complemento,
        bairro: data.bairro || '',
        cep: data.cep || '',
        municipio: data.municipio || '',
        uf: data.uf || '',
      },
      telefone: data.ddd_telefone_1,
      email: data.email,
      capitalSocial: parseFloat(data.capital_social || '0'),
      porte: data.descricao_porte || '',
      quadroSocietario: (data.qsa || []).map((socio: any) => ({
        nome: socio.nome || '',
        qualificacao: socio.qualificacao || '',
        dataEntrada: socio.data_entrada_sociedade,
      })),
      simples: data.opcao_pelo_simples ? {
        optante: data.opcao_pelo_simples === 'Sim',
        dataOpcao: data.data_opcao_pelo_simples,
        dataExclusao: data.data_exclusao_do_simples,
      } : undefined,
      mei: data.opcao_pelo_mei ? {
        optante: data.opcao_pelo_mei === 'Sim',
        dataOpcao: data.data_opcao_pelo_mei,
      } : undefined,
    };
  }

  /**
   * Mapeia resposta da ReceitaWS
   */
  private mapearReceitaWsResponse(data: any): ReceitaFederalEmpresa {
    return {
      cnpj: data.cnpj,
      razaoSocial: data.nome,
      nomeFantasia: data.fantasia,
      situacaoCadastral: data.situacao,
      dataSituacaoCadastral: data.data_situacao,
      motivoSituacaoCadastral: data.motivo_situacao || '',
      naturezaJuridica: data.natureza_juridica || '',
      dataInicioAtividade: data.abertura,
      cnae: {
        principal: {
          codigo: data.atividade_principal?.[0]?.code || '',
          descricao: data.atividade_principal?.[0]?.text || '',
        },
        secundarios: (data.atividades_secundarias || []).map((atividade: any) => ({
          codigo: atividade.code || '',
          descricao: atividade.text || '',
        })),
      },
      endereco: {
        logradouro: data.logradouro || '',
        numero: data.numero || '',
        complemento: data.complemento,
        bairro: data.bairro || '',
        cep: data.cep || '',
        municipio: data.municipio || '',
        uf: data.uf || '',
      },
      telefone: data.telefone,
      email: data.email,
      capitalSocial: parseFloat(data.capital_social?.replace(/[^\d,]/g, '').replace(',', '.') || '0'),
      porte: data.porte || '',
      quadroSocietario: (data.qsa || []).map((socio: any) => ({
        nome: socio.nome || '',
        qualificacao: socio.qual || '',
      })),
    };
  }

  /**
   * Valida CNPJ (algoritmo oficial)
   */
  validarCnpj(cnpj: string): boolean {
    try {
      const cnpjLimpo = cnpj.replace(/\D/g, '');

      if (cnpjLimpo.length !== 14) {
        return false;
      }

      // Verifica se todos os dígitos são iguais
      if (/^(\d)\1{13}$/.test(cnpjLimpo)) {
        return false;
      }

      // Calcula primeiro dígito verificador
      let soma = 0;
      let peso = 2;
      
      for (let i = 11; i >= 0; i--) {
        soma += parseInt(cnpjLimpo[i]) * peso;
        peso = peso === 9 ? 2 : peso + 1;
      }
      
      const resto1 = soma % 11;
      const dv1 = resto1 < 2 ? 0 : 11 - resto1;

      if (parseInt(cnpjLimpo[12]) !== dv1) {
        return false;
      }

      // Calcula segundo dígito verificador
      soma = 0;
      peso = 2;
      
      for (let i = 12; i >= 0; i--) {
        soma += parseInt(cnpjLimpo[i]) * peso;
        peso = peso === 9 ? 2 : peso + 1;
      }
      
      const resto2 = soma % 11;
      const dv2 = resto2 < 2 ? 0 : 11 - resto2;

      return parseInt(cnpjLimpo[13]) === dv2;

    } catch (error) {
      return false;
    }
  }

  /**
   * Valida CPF (algoritmo oficial)
   */
  validarCpf(cpf: string): boolean {
    try {
      const cpfLimpo = cpf.replace(/\D/g, '');

      if (cpfLimpo.length !== 11) {
        return false;
      }

      // Verifica se todos os dígitos são iguais
      if (/^(\d)\1{10}$/.test(cpfLimpo)) {
        return false;
      }

      // Calcula primeiro dígito verificador
      let soma = 0;
      for (let i = 0; i < 9; i++) {
        soma += parseInt(cpfLimpo[i]) * (10 - i);
      }
      
      const resto1 = soma % 11;
      const dv1 = resto1 < 2 ? 0 : 11 - resto1;

      if (parseInt(cpfLimpo[9]) !== dv1) {
        return false;
      }

      // Calcula segundo dígito verificador
      soma = 0;
      for (let i = 0; i < 10; i++) {
        soma += parseInt(cpfLimpo[i]) * (11 - i);
      }
      
      const resto2 = soma % 11;
      const dv2 = resto2 < 2 ? 0 : 11 - resto2;

      return parseInt(cpfLimpo[10]) === dv2;

    } catch (error) {
      return false;
    }
  }

  /**
   * Verifica situação cadastral da empresa
   */
  async verificarSituacaoCadastral(cnpj: string): Promise<{
    ativa: boolean;
    situacao: string;
    motivo?: string;
    dataUltimaAtualizacao?: string;
  }> {
    try {
      const empresa = await this.consultarCnpj(cnpj);
      
      if (!empresa) {
        return {
          ativa: false,
          situacao: 'Não encontrada',
        };
      }

      const situacoesAtivas = [
        'ATIVA',
        'ATIVO',
        'OK',
        'REGULAR',
      ];

      const ativa = situacoesAtivas.some(situacao => 
        empresa.situacaoCadastral.toUpperCase().includes(situacao)
      );

      return {
        ativa,
        situacao: empresa.situacaoCadastral,
        motivo: empresa.motivoSituacaoCadastral,
        dataUltimaAtualizacao: empresa.dataSituacaoCadastral,
      };

    } catch (error) {
      this.logger.error(`Erro ao verificar situação cadastral: ${error.message}`);
      return {
        ativa: false,
        situacao: 'Erro na consulta',
      };
    }
  }

  /**
   * Verifica se empresa está apta para atividade farmacêutica
   */
  async verificarAptidaoFarmaceutica(cnpj: string): Promise<{
    apta: boolean;
    motivos: string[];
    cnaesRelacionados: string[];
  }> {
    try {
      const empresa = await this.consultarCnpj(cnpj);
      
      if (!empresa) {
        return {
          apta: false,
          motivos: ['Empresa não encontrada'],
          cnaesRelacionados: [],
        };
      }

      const motivos: string[] = [];
      const cnaesRelacionados: string[] = [];

      // Verifica situação cadastral
      const situacao = await this.verificarSituacaoCadastral(cnpj);
      if (!situacao.ativa) {
        motivos.push(`Situação cadastral: ${situacao.situacao}`);
      }

      // CNAEs relacionados à atividade farmacêutica
      const cnaesFarmaceuticos = [
        '4771-7', // Comércio varejista de produtos farmacêuticos
        '4772-5', // Comércio varejista de cosméticos, produtos de perfumaria
        '4773-3', // Comércio varejista de artigos médicos e ortopédicos
        '2121-1', // Fabricação de medicamentos alopáticos para uso humano
        '2122-0', // Fabricação de medicamentos homeopáticos para uso humano
        '2123-8', // Fabricação de medicamentos para uso veterinário
        '4644-2', // Comércio atacadista de medicamentos e drogas de uso humano
        '4645-1', // Comércio atacadista de instrumentos e materiais para uso médico
      ];

      // Verifica CNAE principal
      const cnaesPrincipal = empresa.cnae.principal.codigo.replace(/[^\d]/g, '');
      const temCnaePrincipalFarmaceutico = cnaesFarmaceuticos.some(cnae => 
        cnaesPrincipal.includes(cnae.replace(/[^\d]/g, ''))
      );

      if (temCnaePrincipalFarmaceutico) {
        cnaesRelacionados.push(empresa.cnae.principal.codigo);
      }

      // Verifica CNAEs secundários
      empresa.cnae.secundarios.forEach(cnae => {
        const codigoLimpo = cnae.codigo.replace(/[^\d]/g, '');
        const isFarmaceutico = cnaesFarmaceuticos.some(cnaeRef => 
          codigoLimpo.includes(cnaeRef.replace(/[^\d]/g, ''))
        );
        
        if (isFarmaceutico) {
          cnaesRelacionados.push(cnae.codigo);
        }
      });

      if (cnaesRelacionados.length === 0) {
        motivos.push('Não possui CNAE relacionado à atividade farmacêutica');
      }

      const apta = motivos.length === 0;

      return {
        apta,
        motivos,
        cnaesRelacionados,
      };

    } catch (error) {
      this.logger.error(`Erro ao verificar aptidão farmacêutica: ${error.message}`);
      return {
        apta: false,
        motivos: ['Erro na verificação'],
        cnaesRelacionados: [],
      };
    }
  }

  /**
   * Formata CNPJ
   */
  formatarCnpj(cnpj: string): string {
    const cnpjLimpo = cnpj.replace(/\D/g, '');
    
    if (cnpjLimpo.length !== 14) {
      return cnpj;
    }

    return cnpjLimpo.replace(
      /^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/,
      '$1.$2.$3/$4-$5'
    );
  }

  /**
   * Formata CPF
   */
  formatarCpf(cpf: string): string {
    const cpfLimpo = cpf.replace(/\D/g, '');
    
    if (cpfLimpo.length !== 11) {
      return cpf;
    }

    return cpfLimpo.replace(
      /^(\d{3})(\d{3})(\d{3})(\d{2})$/,
      '$1.$2.$3-$4'
    );
  }
}

