import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';

export interface OpenHealthPaciente {
  id: string;
  nome: string;
  cpf: string;
  dataNascimento: string;
  sexo: string;
  telefone: string;
  email: string;
  endereco: {
    logradouro: string;
    numero: string;
    complemento: string;
    bairro: string;
    cidade: string;
    uf: string;
    cep: string;
  };
  cartaoSus: string;
  planoSaude?: {
    operadora: string;
    numeroCartao: string;
    validade: string;
  };
  alergias: string[];
  medicamentosUso: string[];
}

export interface OpenHealthPrescricao {
  id: string;
  numeroReceita: string;
  dataEmissao: string;
  dataValidade: string;
  medico: {
    nome: string;
    crm: string;
    especialidade: string;
    telefone: string;
  };
  paciente: {
    nome: string;
    cpf: string;
    dataNascimento: string;
  };
  medicamentos: Array<{
    codigo: string;
    nome: string;
    principioAtivo: string;
    concentracao: string;
    formaFarmaceutica: string;
    quantidade: number;
    unidade: string;
    posologia: string;
    duracaoTratamento: string;
    observacoes: string;
  }>;
  diagnostico: string;
  observacoes: string;
  tipoReceita: 'COMUM' | 'CONTROLADA' | 'ESPECIAL';
  status: 'ATIVA' | 'DISPENSADA' | 'VENCIDA' | 'CANCELADA';
}

export interface OpenHealthInteracao {
  medicamento1: string;
  medicamento2: string;
  tipoInteracao: 'LEVE' | 'MODERADA' | 'GRAVE';
  descricao: string;
  recomendacoes: string[];
  referencias: string[];
}

@Injectable()
export class OpenHealthService {
  private readonly logger = new Logger(OpenHealthService.name);
  private readonly baseUrl = 'https://api.openhealth.org.br';

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
  ) {}

  /**
   * Consulta dados do paciente
   */
  async consultarPaciente(cpf: string): Promise<OpenHealthPaciente | null> {
    try {
      this.logger.log(`Consultando paciente OpenHealth: ${cpf}`);
      
      const cpfLimpo = cpf.replace(/[^\d]/g, '');
      
      if (cpfLimpo.length !== 11) {
        throw new Error('CPF deve conter 11 dígitos');
      }

      // Simulação de consulta de paciente
      const mockPaciente: OpenHealthPaciente = {
        id: 'pac_001',
        nome: 'Maria Silva Santos',
        cpf: cpfLimpo,
        dataNascimento: '1985-03-15',
        sexo: 'F',
        telefone: '(11) 98765-4321',
        email: 'maria.silva@email.com',
        endereco: {
          logradouro: 'Rua das Palmeiras',
          numero: '456',
          complemento: 'Apto 101',
          bairro: 'Jardim Paulista',
          cidade: 'São Paulo',
          uf: 'SP',
          cep: '01234567'
        },
        cartaoSus: '123456789012345',
        planoSaude: {
          operadora: 'Unimed',
          numeroCartao: '1234567890123456',
          validade: '2025-12-31'
        },
        alergias: [
          'Penicilina',
          'Dipirona'
        ],
        medicamentosUso: [
          'Losartana 50mg - 1x ao dia',
          'Sinvastatina 20mg - 1x ao dia'
        ]
      };

      return mockPaciente;
    } catch (error) {
      this.logger.error(`Erro ao consultar paciente: ${error.message}`);
      throw new Error('Falha na consulta de paciente OpenHealth');
    }
  }

  /**
   * Consulta prescrições do paciente
   */
  async consultarPrescricoes(cpf: string): Promise<OpenHealthPrescricao[]> {
    try {
      this.logger.log(`Consultando prescrições OpenHealth: ${cpf}`);
      
      // Simulação de consulta de prescrições
      const mockPrescricoes: OpenHealthPrescricao[] = [
        {
          id: 'presc_001',
          numeroReceita: 'REC-2024-001234',
          dataEmissao: '2024-12-08',
          dataValidade: '2025-01-07',
          medico: {
            nome: 'Dr. João Santos',
            crm: 'CRM-SP 123456',
            especialidade: 'Cardiologia',
            telefone: '(11) 3333-4444'
          },
          paciente: {
            nome: 'Maria Silva Santos',
            cpf: cpf.replace(/[^\d]/g, ''),
            dataNascimento: '1985-03-15'
          },
          medicamentos: [
            {
              codigo: 'MED001',
              nome: 'Losartana Potássica',
              principioAtivo: 'Losartana Potássica',
              concentracao: '50mg',
              formaFarmaceutica: 'Comprimido revestido',
              quantidade: 30,
              unidade: 'comprimidos',
              posologia: '1 comprimido ao dia, pela manhã',
              duracaoTratamento: '30 dias',
              observacoes: 'Tomar com água, preferencialmente no mesmo horário'
            }
          ],
          diagnostico: 'Hipertensão arterial sistêmica',
          observacoes: 'Paciente deve manter dieta com baixo teor de sódio',
          tipoReceita: 'COMUM',
          status: 'ATIVA'
        }
      ];

      return mockPrescricoes;
    } catch (error) {
      this.logger.error(`Erro ao consultar prescrições: ${error.message}`);
      throw new Error('Falha na consulta de prescrições');
    }
  }

  /**
   * Valida prescrição médica
   */
  async validarPrescricao(numeroReceita: string): Promise<{
    valida: boolean;
    status: string;
    motivo: string;
    prescricao?: OpenHealthPrescricao;
  }> {
    try {
      this.logger.log(`Validando prescrição OpenHealth: ${numeroReceita}`);
      
      // Simulação de validação de prescrição
      const prescricoesValidas = [
        'REC-2024-001234',
        'REC-2024-001235',
        'REC-2024-001236'
      ];

      if (prescricoesValidas.includes(numeroReceita)) {
        const prescricao: OpenHealthPrescricao = {
          id: 'presc_001',
          numeroReceita,
          dataEmissao: '2024-12-08',
          dataValidade: '2025-01-07',
          medico: {
            nome: 'Dr. João Santos',
            crm: 'CRM-SP 123456',
            especialidade: 'Cardiologia',
            telefone: '(11) 3333-4444'
          },
          paciente: {
            nome: 'Maria Silva Santos',
            cpf: '12345678901',
            dataNascimento: '1985-03-15'
          },
          medicamentos: [],
          diagnostico: 'Hipertensão arterial sistêmica',
          observacoes: '',
          tipoReceita: 'COMUM',
          status: 'ATIVA'
        };

        return {
          valida: true,
          status: 'ATIVA',
          motivo: 'Prescrição válida e ativa',
          prescricao
        };
      }

      return {
        valida: false,
        status: 'INVALIDA',
        motivo: 'Prescrição não encontrada ou inválida'
      };
    } catch (error) {
      this.logger.error(`Erro ao validar prescrição: ${error.message}`);
      throw new Error('Falha na validação de prescrição');
    }
  }

  /**
   * Verifica interações medicamentosas
   */
  async verificarInteracoes(medicamentos: string[]): Promise<OpenHealthInteracao[]> {
    try {
      this.logger.log(`Verificando interações medicamentosas: ${medicamentos.join(', ')}`);
      
      // Base de dados simulada de interações
      const interacoesConhecidas: OpenHealthInteracao[] = [
        {
          medicamento1: 'Varfarina',
          medicamento2: 'Aspirina',
          tipoInteracao: 'GRAVE',
          descricao: 'Aumento do risco de sangramento',
          recomendacoes: [
            'Monitorar INR mais frequentemente',
            'Observar sinais de sangramento',
            'Considerar alternativas terapêuticas'
          ],
          referencias: ['Micromedex', 'UpToDate']
        },
        {
          medicamento1: 'Sinvastatina',
          medicamento2: 'Claritromicina',
          tipoInteracao: 'GRAVE',
          descricao: 'Aumento do risco de miopatia e rabdomiólise',
          recomendacoes: [
            'Suspender sinvastatina durante tratamento com claritromicina',
            'Monitorar CK e função renal',
            'Orientar paciente sobre sintomas musculares'
          ],
          referencias: ['FDA', 'EMA']
        },
        {
          medicamento1: 'Losartana',
          medicamento2: 'Ibuprofeno',
          tipoInteracao: 'MODERADA',
          descricao: 'Redução do efeito anti-hipertensivo',
          recomendacoes: [
            'Monitorar pressão arterial',
            'Preferir paracetamol como analgésico',
            'Usar AINE por menor tempo possível'
          ],
          referencias: ['Micromedex']
        }
      ];

      const interacoesEncontradas: OpenHealthInteracao[] = [];

      // Verifica todas as combinações de medicamentos
      for (let i = 0; i < medicamentos.length; i++) {
        for (let j = i + 1; j < medicamentos.length; j++) {
          const med1 = medicamentos[i].toLowerCase();
          const med2 = medicamentos[j].toLowerCase();

          const interacao = interacoesConhecidas.find(int => 
            (int.medicamento1.toLowerCase().includes(med1) && int.medicamento2.toLowerCase().includes(med2)) ||
            (int.medicamento1.toLowerCase().includes(med2) && int.medicamento2.toLowerCase().includes(med1))
          );

          if (interacao) {
            interacoesEncontradas.push(interacao);
          }
        }
      }

      return interacoesEncontradas;
    } catch (error) {
      this.logger.error(`Erro ao verificar interações: ${error.message}`);
      throw new Error('Falha na verificação de interações medicamentosas');
    }
  }

  /**
   * Consulta informações de medicamento
   */
  async consultarMedicamento(codigo: string): Promise<{
    codigo: string;
    nome: string;
    principioAtivo: string;
    concentracao: string;
    formaFarmaceutica: string;
    fabricante: string;
    indicacoes: string[];
    contraindicacoes: string[];
    efeitosAdversos: string[];
    posologiaAdulto: string;
    posologiaPediatrica: string;
    interacoes: string[];
    precaucoes: string[];
  } | null> {
    try {
      this.logger.log(`Consultando medicamento OpenHealth: ${codigo}`);
      
      // Simulação de consulta de medicamento
      const medicamentosBase = {
        'MED001': {
          codigo: 'MED001',
          nome: 'Losartana Potássica 50mg',
          principioAtivo: 'Losartana Potássica',
          concentracao: '50mg',
          formaFarmaceutica: 'Comprimido revestido',
          fabricante: 'EMS S/A',
          indicacoes: [
            'Hipertensão arterial',
            'Insuficiência cardíaca',
            'Nefropatia diabética'
          ],
          contraindicacoes: [
            'Hipersensibilidade ao losartana',
            'Gravidez',
            'Estenose bilateral da artéria renal'
          ],
          efeitosAdversos: [
            'Tontura',
            'Fadiga',
            'Hipotensão',
            'Hipercalemia'
          ],
          posologiaAdulto: '25-100mg uma vez ao dia',
          posologiaPediatrica: 'Não recomendado para menores de 6 anos',
          interacoes: [
            'AINEs',
            'Diuréticos poupadores de potássio',
            'Suplementos de potássio'
          ],
          precaucoes: [
            'Monitorar função renal',
            'Monitorar níveis de potássio',
            'Cuidado em pacientes desidratados'
          ]
        }
      };

      return medicamentosBase[codigo] || null;
    } catch (error) {
      this.logger.error(`Erro ao consultar medicamento: ${error.message}`);
      throw new Error('Falha na consulta de medicamento');
    }
  }

  /**
   * Registra dispensação de medicamento
   */
  async registrarDispensacao(dispensacao: {
    numeroReceita: string;
    cpfPaciente: string;
    medicamentos: Array<{
      codigo: string;
      quantidade: number;
      lote: string;
      dataValidade: string;
    }>;
    farmaceutico: {
      nome: string;
      crf: string;
    };
    dataDispensacao: string;
    observacoes?: string;
  }): Promise<{
    protocoloDispensacao: string;
    dataRegistro: string;
    status: string;
  }> {
    try {
      this.logger.log(`Registrando dispensação OpenHealth: ${dispensacao.numeroReceita}`);
      
      // Validar prescrição
      const validacao = await this.validarPrescricao(dispensacao.numeroReceita);
      
      if (!validacao.valida) {
        throw new Error('Prescrição inválida para dispensação');
      }

      // Gerar protocolo de dispensação
      const protocoloDispensacao = `DISP${Date.now()}`;
      
      // Simulação de registro de dispensação
      const registro = {
        protocoloDispensacao,
        dataRegistro: new Date().toISOString(),
        status: 'REGISTRADA'
      };

      this.logger.log(`Dispensação registrada com protocolo: ${protocoloDispensacao}`);
      
      return registro;
    } catch (error) {
      this.logger.error(`Erro ao registrar dispensação: ${error.message}`);
      throw new Error('Falha no registro de dispensação');
    }
  }

  /**
   * Gera relatório de aderência ao tratamento
   */
  async gerarRelatorioAderencia(cpf: string, periodo: number = 90): Promise<{
    paciente: {
      nome: string;
      cpf: string;
    };
    periodo: {
      inicio: string;
      fim: string;
      dias: number;
    };
    medicamentos: Array<{
      nome: string;
      prescrito: number;
      dispensado: number;
      aderencia: number;
      status: string;
    }>;
    aderenciaGeral: number;
    recomendacoes: string[];
  }> {
    try {
      this.logger.log(`Gerando relatório de aderência: ${cpf}`);
      
      const paciente = await this.consultarPaciente(cpf);
      const prescricoes = await this.consultarPrescricoes(cpf);
      
      if (!paciente) {
        throw new Error('Paciente não encontrado');
      }

      const dataFim = new Date();
      const dataInicio = new Date(dataFim.getTime() - periodo * 24 * 60 * 60 * 1000);

      // Simulação de cálculo de aderência
      const medicamentos = [
        {
          nome: 'Losartana Potássica 50mg',
          prescrito: 90, // comprimidos prescritos no período
          dispensado: 75, // comprimidos dispensados
          aderencia: 83.3, // percentual de aderência
          status: 'REGULAR'
        }
      ];

      const aderenciaGeral = medicamentos.reduce((acc, med) => acc + med.aderencia, 0) / medicamentos.length;

      const recomendacoes = [
        'Orientar paciente sobre importância da aderência',
        'Considerar estratégias para melhorar aderência',
        'Agendar consulta de acompanhamento'
      ];

      return {
        paciente: {
          nome: paciente.nome,
          cpf: paciente.cpf
        },
        periodo: {
          inicio: dataInicio.toISOString().split('T')[0],
          fim: dataFim.toISOString().split('T')[0],
          dias: periodo
        },
        medicamentos,
        aderenciaGeral,
        recomendacoes
      };
    } catch (error) {
      this.logger.error(`Erro ao gerar relatório de aderência: ${error.message}`);
      throw new Error('Falha na geração do relatório de aderência');
    }
  }

  /**
   * Consulta alertas farmacoterapêuticos
   */
  async consultarAlertas(cpf: string): Promise<Array<{
    tipo: string;
    prioridade: 'BAIXA' | 'MEDIA' | 'ALTA';
    titulo: string;
    descricao: string;
    recomendacoes: string[];
    dataAlerta: string;
  }>> {
    try {
      this.logger.log(`Consultando alertas farmacoterapêuticos: ${cpf}`);
      
      const paciente = await this.consultarPaciente(cpf);
      
      if (!paciente) {
        return [];
      }

      // Simulação de alertas baseados no perfil do paciente
      const alertas = [
        {
          tipo: 'ALERGIA',
          prioridade: 'ALTA' as const,
          titulo: 'Alergia a Penicilina',
          descricao: 'Paciente possui alergia conhecida a Penicilina',
          recomendacoes: [
            'Evitar prescrição de antibióticos beta-lactâmicos',
            'Considerar alternativas como macrolídeos ou quinolonas',
            'Manter pulseira de identificação de alergia'
          ],
          dataAlerta: new Date().toISOString()
        },
        {
          tipo: 'INTERACAO',
          prioridade: 'MEDIA' as const,
          titulo: 'Possível interação medicamentosa',
          descricao: 'Uso concomitante de Losartana e anti-inflamatórios',
          recomendacoes: [
            'Monitorar pressão arterial',
            'Preferir paracetamol como analgésico',
            'Orientar sobre sinais de hipertensão'
          ],
          dataAlerta: new Date().toISOString()
        }
      ];

      return alertas;
    } catch (error) {
      this.logger.error(`Erro ao consultar alertas: ${error.message}`);
      throw new Error('Falha na consulta de alertas farmacoterapêuticos');
    }
  }
}

