import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';

export interface CnesEstabelecimento {
  cnes: string;
  nomeFantasia: string;
  razaoSocial: string;
  cnpj: string;
  tipoUnidade: string;
  naturezaOrganizacao: string;
  esferaAdministrativa: string;
  situacao: string;
  dataAtualizacao: string;
  endereco: {
    logradouro: string;
    numero: string;
    complemento: string;
    bairro: string;
    municipio: string;
    uf: string;
    cep: string;
  };
  telefone: string;
  email: string;
  responsavelTecnico: {
    nome: string;
    conselho: string;
    numeroRegistro: string;
  };
  servicos: string[];
  equipamentos: Array<{
    codigo: string;
    descricao: string;
    quantidade: number;
    situacao: string;
  }>;
}

export interface CnesProfissional {
  cpf: string;
  nome: string;
  cns: string;
  conselhoProfissional: string;
  numeroRegistro: string;
  especialidades: string[];
  vinculos: Array<{
    cnes: string;
    nomeEstabelecimento: string;
    tipoVinculo: string;
    cargaHoraria: number;
    dataInicio: string;
    dataFim?: string;
  }>;
}

@Injectable()
export class CnesService {
  private readonly logger = new Logger(CnesService.name);
  private readonly baseUrl = 'http://cnes.datasus.gov.br/api';

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
  ) {}

  /**
   * Consulta estabelecimento por código CNES
   */
  async consultarEstabelecimento(cnes: string): Promise<CnesEstabelecimento | null> {
    try {
      this.logger.log(`Consultando estabelecimento CNES: ${cnes}`);
      
      // Remove formatação do CNES
      const cnesLimpo = cnes.replace(/[^\d]/g, '');
      
      if (cnesLimpo.length !== 7) {
        throw new Error('CNES deve conter 7 dígitos');
      }

      // Simulação de consulta ao CNES
      const mockEstabelecimento: CnesEstabelecimento = {
        cnes: cnesLimpo,
        nomeFantasia: 'Farmácia Central',
        razaoSocial: 'Farmácia Central Ltda',
        cnpj: '12345678000190',
        tipoUnidade: 'FARMACIA',
        naturezaOrganizacao: 'Empresa Privada',
        esferaAdministrativa: 'Privada',
        situacao: 'ATIVO',
        dataAtualizacao: '2024-12-01',
        endereco: {
          logradouro: 'Rua das Flores',
          numero: '123',
          complemento: 'Loja 1',
          bairro: 'Centro',
          municipio: 'São Paulo',
          uf: 'SP',
          cep: '01234567'
        },
        telefone: '(11) 1234-5678',
        email: 'contato@farmaciacentral.com.br',
        responsavelTecnico: {
          nome: 'Dr. João Silva',
          conselho: 'CRF-SP',
          numeroRegistro: '12345'
        },
        servicos: [
          'Dispensação de medicamentos',
          'Aplicação de injetáveis',
          'Aferição de pressão arterial',
          'Teste de glicemia'
        ],
        equipamentos: [
          {
            codigo: 'EQ001',
            descricao: 'Balança digital',
            quantidade: 1,
            situacao: 'ATIVO'
          },
          {
            codigo: 'EQ002',
            descricao: 'Esfigmomanômetro',
            quantidade: 2,
            situacao: 'ATIVO'
          }
        ]
      };

      return mockEstabelecimento;
    } catch (error) {
      this.logger.error(`Erro ao consultar estabelecimento CNES: ${error.message}`);
      throw new Error('Falha na consulta ao CNES');
    }
  }

  /**
   * Busca estabelecimentos por município
   */
  async buscarEstabelecimentosPorMunicipio(
    codigoMunicipio: string,
    tipoUnidade?: string
  ): Promise<CnesEstabelecimento[]> {
    try {
      this.logger.log(`Buscando estabelecimentos CNES no município: ${codigoMunicipio}`);
      
      // Simulação de busca por município
      const mockEstabelecimentos: CnesEstabelecimento[] = [
        {
          cnes: '1234567',
          nomeFantasia: 'Farmácia Central',
          razaoSocial: 'Farmácia Central Ltda',
          cnpj: '12345678000190',
          tipoUnidade: 'FARMACIA',
          naturezaOrganizacao: 'Empresa Privada',
          esferaAdministrativa: 'Privada',
          situacao: 'ATIVO',
          dataAtualizacao: '2024-12-01',
          endereco: {
            logradouro: 'Rua das Flores',
            numero: '123',
            complemento: 'Loja 1',
            bairro: 'Centro',
            municipio: 'São Paulo',
            uf: 'SP',
            cep: '01234567'
          },
          telefone: '(11) 1234-5678',
          email: 'contato@farmaciacentral.com.br',
          responsavelTecnico: {
            nome: 'Dr. João Silva',
            conselho: 'CRF-SP',
            numeroRegistro: '12345'
          },
          servicos: ['Dispensação de medicamentos'],
          equipamentos: []
        }
      ];

      if (tipoUnidade) {
        return mockEstabelecimentos.filter(est => 
          est.tipoUnidade.toLowerCase().includes(tipoUnidade.toLowerCase())
        );
      }

      return mockEstabelecimentos;
    } catch (error) {
      this.logger.error(`Erro ao buscar estabelecimentos por município: ${error.message}`);
      throw new Error('Falha na busca de estabelecimentos CNES');
    }
  }

  /**
   * Consulta profissional por CPF
   */
  async consultarProfissional(cpf: string): Promise<CnesProfissional | null> {
    try {
      this.logger.log(`Consultando profissional CNES: ${cpf}`);
      
      const cpfLimpo = cpf.replace(/[^\d]/g, '');
      
      if (cpfLimpo.length !== 11) {
        throw new Error('CPF deve conter 11 dígitos');
      }

      // Simulação de consulta de profissional
      const mockProfissional: CnesProfissional = {
        cpf: cpfLimpo,
        nome: 'Dr. João Silva',
        cns: '123456789012345',
        conselhoProfissional: 'CRF-SP',
        numeroRegistro: '12345',
        especialidades: [
          'Farmácia Clínica',
          'Farmácia Hospitalar'
        ],
        vinculos: [
          {
            cnes: '1234567',
            nomeEstabelecimento: 'Farmácia Central',
            tipoVinculo: 'Responsável Técnico',
            cargaHoraria: 40,
            dataInicio: '2020-01-15'
          }
        ]
      };

      return mockProfissional;
    } catch (error) {
      this.logger.error(`Erro ao consultar profissional CNES: ${error.message}`);
      throw new Error('Falha na consulta de profissional CNES');
    }
  }

  /**
   * Valida se estabelecimento está habilitado para atividade farmacêutica
   */
  async validarHabilitacaoFarmaceutica(cnes: string): Promise<{
    habilitado: boolean;
    motivos: string[];
    servicos: string[];
  }> {
    try {
      const estabelecimento = await this.consultarEstabelecimento(cnes);
      
      if (!estabelecimento) {
        return {
          habilitado: false,
          motivos: ['Estabelecimento não encontrado no CNES'],
          servicos: []
        };
      }

      const motivos: string[] = [];
      let habilitado = true;

      // Verifica situação
      if (estabelecimento.situacao !== 'ATIVO') {
        habilitado = false;
        motivos.push(`Situação no CNES: ${estabelecimento.situacao}`);
      }

      // Verifica tipo de unidade
      const tiposFarmaceuticos = ['FARMACIA', 'DROGARIA', 'UNIDADE MISTA'];
      if (!tiposFarmaceuticos.includes(estabelecimento.tipoUnidade)) {
        habilitado = false;
        motivos.push('Tipo de unidade não é farmacêutica');
      }

      // Verifica responsável técnico
      if (!estabelecimento.responsavelTecnico.numeroRegistro) {
        habilitado = false;
        motivos.push('Responsável técnico não cadastrado');
      }

      if (habilitado) {
        motivos.push('Estabelecimento habilitado para atividade farmacêutica');
      }

      return {
        habilitado,
        motivos,
        servicos: estabelecimento.servicos
      };
    } catch (error) {
      this.logger.error(`Erro ao validar habilitação farmacêutica: ${error.message}`);
      return {
        habilitado: false,
        motivos: ['Erro na validação de habilitação'],
        servicos: []
      };
    }
  }

  /**
   * Consulta equipamentos do estabelecimento
   */
  async consultarEquipamentos(cnes: string): Promise<Array<{
    codigo: string;
    descricao: string;
    quantidade: number;
    situacao: string;
  }>> {
    try {
      const estabelecimento = await this.consultarEstabelecimento(cnes);
      
      if (!estabelecimento) {
        return [];
      }

      return estabelecimento.equipamentos;
    } catch (error) {
      this.logger.error(`Erro ao consultar equipamentos CNES: ${error.message}`);
      throw new Error('Falha na consulta de equipamentos CNES');
    }
  }

  /**
   * Verifica vínculos de profissional
   */
  async verificarVinculosProfissional(cpf: string): Promise<Array<{
    cnes: string;
    nomeEstabelecimento: string;
    tipoVinculo: string;
    ativo: boolean;
  }>> {
    try {
      const profissional = await this.consultarProfissional(cpf);
      
      if (!profissional) {
        return [];
      }

      return profissional.vinculos.map(vinculo => ({
        cnes: vinculo.cnes,
        nomeEstabelecimento: vinculo.nomeEstabelecimento,
        tipoVinculo: vinculo.tipoVinculo,
        ativo: !vinculo.dataFim
      }));
    } catch (error) {
      this.logger.error(`Erro ao verificar vínculos profissional: ${error.message}`);
      throw new Error('Falha na verificação de vínculos');
    }
  }

  /**
   * Gera relatório de estabelecimentos por região
   */
  async gerarRelatorioRegional(uf: string, tipoUnidade?: string): Promise<{
    uf: string;
    totalEstabelecimentos: number;
    estabelecimentosAtivos: number;
    estabelecimentosInativos: number;
    tiposUnidade: Record<string, number>;
    estabelecimentos: CnesEstabelecimento[];
  }> {
    try {
      this.logger.log(`Gerando relatório regional CNES: ${uf}`);
      
      // Simulação de relatório regional
      const mockEstabelecimentos: CnesEstabelecimento[] = [
        {
          cnes: '1234567',
          nomeFantasia: 'Farmácia Central',
          razaoSocial: 'Farmácia Central Ltda',
          cnpj: '12345678000190',
          tipoUnidade: 'FARMACIA',
          naturezaOrganizacao: 'Empresa Privada',
          esferaAdministrativa: 'Privada',
          situacao: 'ATIVO',
          dataAtualizacao: '2024-12-01',
          endereco: {
            logradouro: 'Rua das Flores',
            numero: '123',
            complemento: 'Loja 1',
            bairro: 'Centro',
            municipio: 'São Paulo',
            uf: uf,
            cep: '01234567'
          },
          telefone: '(11) 1234-5678',
          email: 'contato@farmaciacentral.com.br',
          responsavelTecnico: {
            nome: 'Dr. João Silva',
            conselho: 'CRF-SP',
            numeroRegistro: '12345'
          },
          servicos: ['Dispensação de medicamentos'],
          equipamentos: []
        }
      ];

      let estabelecimentos = mockEstabelecimentos;
      
      if (tipoUnidade) {
        estabelecimentos = estabelecimentos.filter(est => 
          est.tipoUnidade.toLowerCase().includes(tipoUnidade.toLowerCase())
        );
      }

      const ativos = estabelecimentos.filter(est => est.situacao === 'ATIVO').length;
      const inativos = estabelecimentos.length - ativos;

      const tiposUnidade = estabelecimentos.reduce((acc, est) => {
        acc[est.tipoUnidade] = (acc[est.tipoUnidade] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      return {
        uf,
        totalEstabelecimentos: estabelecimentos.length,
        estabelecimentosAtivos: ativos,
        estabelecimentosInativos: inativos,
        tiposUnidade,
        estabelecimentos
      };
    } catch (error) {
      this.logger.error(`Erro ao gerar relatório regional: ${error.message}`);
      throw new Error('Falha na geração do relatório regional CNES');
    }
  }
}

