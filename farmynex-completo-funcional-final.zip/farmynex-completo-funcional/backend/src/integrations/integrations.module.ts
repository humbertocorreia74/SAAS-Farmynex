import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { ConfigModule } from '@nestjs/config';

// Serviços de integração implementados
import { AnvisaService } from './anvisa/anvisa.service';
import { SngpcService } from './sngpc/sngpc.service';
import { ReceitaFederalService } from './receita-federal/receita-federal.service';
import { CnesService } from './cnes/cnes.service';
import { SerasaService } from './serasa/serasa.service';
import { SefazService } from './sefaz/sefaz.service';
import { OpenHealthService } from './openhealth/openhealth.service';

// Controllers implementados
import { AnvisaController } from './anvisa/anvisa.controller';

@Module({
  imports: [HttpModule, ConfigModule],
  controllers: [
    AnvisaController,
  ],
  providers: [
    AnvisaService,
    SngpcService,
    ReceitaFederalService,
    CnesService,
    SerasaService,
    SefazService,
    OpenHealthService,
  ],
  exports: [
    AnvisaService,
    SngpcService,
    ReceitaFederalService,
    CnesService,
    SerasaService,
    SefazService,
    OpenHealthService,
  ],
})
export class IntegrationsModule {}

