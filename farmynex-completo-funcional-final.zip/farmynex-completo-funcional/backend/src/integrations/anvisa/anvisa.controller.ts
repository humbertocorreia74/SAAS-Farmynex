import {
  Controller,
  Get,
  Query,
  Param,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { AnvisaService } from './anvisa.service';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';

@ApiTags('anvisa')
@Controller('integrations/anvisa')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class AnvisaController {
  constructor(private readonly anvisaService: AnvisaService) {}

  @Get('produto/:codigo')
  @ApiOperation({ summary: 'Consultar produto por código na ANVISA' })
  @ApiResponse({ status: 200, description: 'Produto encontrado com sucesso' })
  @ApiResponse({ status: 404, description: 'Produto não encontrado' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  async consultarProduto(@Param('codigo') codigo: string) {
    try {
      const produto = await this.anvisaService.consultarProduto(codigo);
      
      if (!produto) {
        return {
          success: false,
          message: 'Produto não encontrado na base da ANVISA',
        };
      }

      return {
        success: true,
        data: produto,
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Get('estabelecimento/:cnpj')
  @ApiOperation({ summary: 'Consultar estabelecimento farmacêutico na ANVISA' })
  @ApiResponse({ status: 200, description: 'Estabelecimento encontrado com sucesso' })
  @ApiResponse({ status: 404, description: 'Estabelecimento não encontrado' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  async consultarEstabelecimento(@Param('cnpj') cnpj: string) {
    try {
      const estabelecimento = await this.anvisaService.consultarEstabelecimento(cnpj);

      return {
        success: true,
        data: estabelecimento,
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Get('produto/:codigo/controlado')
  @ApiOperation({ summary: 'Verificar se um produto é controlado' })
  @ApiResponse({ status: 200, description: 'Verificação realizada com sucesso' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  async verificarProdutoControlado(@Param('codigo') codigo: string) {
    try {
      const controlado = await this.anvisaService.verificarProdutoControlado(codigo);

      return {
        success: true,
        data: {
          codigo,
          produtoControlado: controlado,
        },
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Get('alertas')
  @ApiOperation({ summary: 'Consultar alertas e notificações da ANVISA' })
  @ApiQuery({ name: 'categoria', description: 'Categoria dos alertas', required: false })
  @ApiResponse({ status: 200, description: 'Alertas obtidos com sucesso' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  async consultarAlertas(@Query('categoria') categoria?: string) {
    try {
      const alertas = await this.anvisaService.consultarAlertas(categoria);

      return {
        success: true,
        data: alertas,
        total: alertas.length,
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Get('validar-comercializacao/:cnpj/:codigoProduto')
  @ApiOperation({ summary: 'Validar se estabelecimento pode comercializar produto' })
  @ApiResponse({ status: 200, description: 'Validação realizada com sucesso' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  async validarComercializacao(
    @Param('cnpj') cnpj: string,
    @Param('codigoProduto') codigoProduto: string,
  ) {
    try {
      const validacao = await this.anvisaService.validarComercializacao(cnpj, codigoProduto);

      return {
        success: true,
        data: validacao,
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }
}

