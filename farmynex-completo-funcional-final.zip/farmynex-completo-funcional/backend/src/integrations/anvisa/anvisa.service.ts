import { Injectable, Logger, HttpException, HttpStatus } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

export interface AnvisaProduct {
  numeroRegistro: string;
  nomeProduto: string;
  nomeEmpresa: string;
  situacaoRegistro: string;
  dataVencimentoRegistro: string;
  principioAtivo: string;
  categoria: string;
  classeRisco?: string;
}

export interface AnvisaEstabelecimento {
  cnpj: string;
  razaoSocial: string;
  nomeFantasia: string;
  situacao: string;
  endereco: {
    logradouro: string;
    numero: string;
    bairro: string;
    cidade: string;
    uf: string;
    cep: string;
  };
  licencas: Array<{
    numero: string;
    tipo: string;
    dataVencimento: string;
    situacao: string;
  }>;
}

@Injectable()
export class AnvisaService {
  private readonly logger = new Logger(AnvisaService.name);
  private readonly baseUrl = 'https://dados.gov.br/api/publico/conjuntos-dados';
  private readonly consultaUrl = 'https://consultas.anvisa.gov.br/api';

  constructor(private readonly httpService: HttpService) {}

  /**
   * Consulta produto por código de barras ou número de registro
   */
  async consultarProduto(codigo: string): Promise<AnvisaProduct | null> {
    try {
      this.logger.log(`Consultando produto ANVISA: ${codigo}`);

      // Primeiro tenta buscar nos dados abertos de medicamentos
      const medicamentosResponse = await this.consultarMedicamentos(codigo);
      if (medicamentosResponse) {
        return medicamentosResponse;
      }

      // Se não encontrar, tenta buscar em outros produtos regulamentados
      const produtosResponse = await this.consultarProdutosRegulamentados(codigo);
      return produtosResponse;

    } catch (error) {
      this.logger.error(`Erro ao consultar produto ANVISA: ${error.message}`);
      throw new HttpException(
        'Erro ao consultar produto na ANVISA',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Consulta medicamentos registrados
   */
  private async consultarMedicamentos(codigo: string): Promise<AnvisaProduct | null> {
    try {
      // URL dos dados abertos de medicamentos da ANVISA
      const url = 'https://dados.gov.br/api/publico/conjuntos-dados/medicamentos-registrados-no-brasil';
      
      const response = await firstValueFrom(
        this.httpService.get(url, {
          params: {
            q: codigo,
            format: 'json',
            limit: 10,
          },
          timeout: 10000,
        }),
      );

      if (response.data && response.data.result && response.data.result.length > 0) {
        const medicamento = response.data.result[0];
        
        return {
          numeroRegistro: medicamento.numero_registro || codigo,
          nomeProduto: medicamento.nome_produto || 'Produto não identificado',
          nomeEmpresa: medicamento.empresa || 'Empresa não identificada',
          situacaoRegistro: medicamento.situacao || 'Não informado',
          dataVencimentoRegistro: medicamento.data_vencimento || 'Não informado',
          principioAtivo: medicamento.principio_ativo || 'Não informado',
          categoria: 'Medicamento',
        };
      }

      return null;
    } catch (error) {
      this.logger.warn(`Erro ao consultar medicamentos: ${error.message}`);
      return null;
    }
  }

  /**
   * Consulta produtos regulamentados em geral
   */
  private async consultarProdutosRegulamentados(codigo: string): Promise<AnvisaProduct | null> {
    try {
      // Simula consulta a API de produtos regulamentados
      // Em produção, seria necessário usar a API oficial da ANVISA
      
      // Por enquanto, retorna dados simulados baseados no código
      if (codigo.length >= 8) {
        return {
          numeroRegistro: codigo,
          nomeProduto: `Produto ${codigo.substring(0, 8)}`,
          nomeEmpresa: 'Empresa Farmacêutica Ltda',
          situacaoRegistro: 'Válido',
          dataVencimentoRegistro: '2025-12-31',
          principioAtivo: 'Princípio ativo não identificado',
          categoria: 'Produto para Saúde',
        };
      }

      return null;
    } catch (error) {
      this.logger.warn(`Erro ao consultar produtos regulamentados: ${error.message}`);
      return null;
    }
  }

  /**
   * Consulta estabelecimento por CNPJ
   */
  async consultarEstabelecimento(cnpj: string): Promise<AnvisaEstabelecimento | null> {
    try {
      this.logger.log(`Consultando estabelecimento ANVISA: ${cnpj}`);

      // Remove formatação do CNPJ
      const cnpjLimpo = cnpj.replace(/\D/g, '');

      // Simula consulta a base de estabelecimentos da ANVISA
      // Em produção, seria necessário usar a API oficial
      
      return {
        cnpj: cnpjLimpo,
        razaoSocial: 'Farmácia e Drogaria Exemplo Ltda',
        nomeFantasia: 'Farmácia Exemplo',
        situacao: 'Ativa',
        endereco: {
          logradouro: 'Rua das Flores',
          numero: '123',
          bairro: 'Centro',
          cidade: 'São Paulo',
          uf: 'SP',
          cep: '01234-567',
        },
        licencas: [
          {
            numero: 'LIC-2024-001',
            tipo: 'Licença de Funcionamento',
            dataVencimento: '2025-12-31',
            situacao: 'Válida',
          },
          {
            numero: 'AFE-2024-002',
            tipo: 'Autorização de Funcionamento',
            dataVencimento: '2025-12-31',
            situacao: 'Válida',
          },
        ],
      };

    } catch (error) {
      this.logger.error(`Erro ao consultar estabelecimento ANVISA: ${error.message}`);
      throw new HttpException(
        'Erro ao consultar estabelecimento na ANVISA',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Verifica se um produto está na lista de medicamentos controlados
   */
  async verificarProdutoControlado(codigo: string): Promise<boolean> {
    try {
      this.logger.log(`Verificando se produto é controlado: ${codigo}`);

      // Consulta o produto primeiro
      const produto = await this.consultarProduto(codigo);
      
      if (!produto) {
        return false;
      }

      // Lista de princípios ativos controlados (simplificada)
      const principiosControlados = [
        'clonazepam',
        'diazepam',
        'alprazolam',
        'lorazepam',
        'codeína',
        'tramadol',
        'morfina',
        'fentanil',
        'metilfenidato',
        'anfetamina',
      ];

      const principioAtivo = produto.principioAtivo.toLowerCase();
      return principiosControlados.some(controlado => 
        principioAtivo.includes(controlado)
      );

    } catch (error) {
      this.logger.error(`Erro ao verificar produto controlado: ${error.message}`);
      return false;
    }
  }

  /**
   * Consulta alertas e notificações da ANVISA
   */
  async consultarAlertas(categoria?: string): Promise<any[]> {
    try {
      this.logger.log(`Consultando alertas ANVISA: ${categoria || 'todos'}`);

      // Simula consulta a alertas da ANVISA
      const alertas = [
        {
          id: 'ALERT-2024-001',
          titulo: 'Recolhimento de lote de medicamento',
          categoria: 'Medicamento',
          descricao: 'Recolhimento voluntário do lote XYZ123 devido a desvio de qualidade',
          dataPublicacao: '2024-12-01',
          gravidade: 'Alta',
          produtos: ['Produto A', 'Produto B'],
        },
        {
          id: 'ALERT-2024-002',
          titulo: 'Alerta sobre produto falsificado',
          categoria: 'Medicamento',
          descricao: 'Identificação de produto falsificado no mercado',
          dataPublicacao: '2024-11-28',
          gravidade: 'Crítica',
          produtos: ['Produto C'],
        },
      ];

      if (categoria) {
        return alertas.filter(alerta => 
          alerta.categoria.toLowerCase() === categoria.toLowerCase()
        );
      }

      return alertas;

    } catch (error) {
      this.logger.error(`Erro ao consultar alertas ANVISA: ${error.message}`);
      throw new HttpException(
        'Erro ao consultar alertas da ANVISA',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Valida se um estabelecimento pode comercializar determinado produto
   */
  async validarComercializacao(cnpj: string, codigoProduto: string): Promise<{
    autorizado: boolean;
    motivo?: string;
    licencasNecessarias?: string[];
  }> {
    try {
      this.logger.log(`Validando comercialização: ${cnpj} - ${codigoProduto}`);

      const estabelecimento = await this.consultarEstabelecimento(cnpj);
      const produto = await this.consultarProduto(codigoProduto);

      if (!estabelecimento) {
        return {
          autorizado: false,
          motivo: 'Estabelecimento não encontrado na ANVISA',
        };
      }

      if (!produto) {
        return {
          autorizado: false,
          motivo: 'Produto não registrado na ANVISA',
        };
      }

      // Verifica se o estabelecimento tem licenças válidas
      const licencasValidas = estabelecimento.licencas.filter(
        licenca => licenca.situacao === 'Válida' && 
        new Date(licenca.dataVencimento) > new Date()
      );

      if (licencasValidas.length === 0) {
        return {
          autorizado: false,
          motivo: 'Estabelecimento sem licenças válidas',
          licencasNecessarias: ['Licença de Funcionamento', 'Autorização de Funcionamento'],
        };
      }

      // Verifica se é produto controlado
      const isControlado = await this.verificarProdutoControlado(codigoProduto);
      
      if (isControlado) {
        const temLicencaControlados = licencasValidas.some(
          licenca => licenca.tipo.includes('Controlados')
        );
        
        if (!temLicencaControlados) {
          return {
            autorizado: false,
            motivo: 'Produto controlado requer licença específica',
            licencasNecessarias: ['Licença para Produtos Controlados'],
          };
        }
      }

      return {
        autorizado: true,
      };

    } catch (error) {
      this.logger.error(`Erro ao validar comercialização: ${error.message}`);
      throw new HttpException(
        'Erro ao validar comercialização',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}

