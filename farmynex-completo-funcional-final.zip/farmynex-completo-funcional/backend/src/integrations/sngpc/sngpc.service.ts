import { Injectable, Logger, HttpException, HttpStatus } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import * as xml2js from 'xml2js';

export interface SngpcMovimentacao {
  tipoMovimentacao: 'ENTRADA' | 'SAIDA';
  codigoProduto: string;
  nomeProduto: string;
  quantidade: number;
  lote: string;
  dataVencimento: string;
  dataMovimentacao: string;
  numeroNotaFiscal?: string;
  cnpjFornecedor?: string;
  cpfPaciente?: string;
  numeroReceita?: string;
  crfMedico?: string;
}

export interface SngpcInventario {
  codigoProduto: string;
  nomeProduto: string;
  quantidade: number;
  lote: string;
  dataVencimento: string;
  dataInventario: string;
}

export interface SngpcRelatorio {
  periodo: {
    dataInicio: string;
    dataFim: string;
  };
  movimentacoes: SngpcMovimentacao[];
  inventarios: SngpcInventario[];
  resumo: {
    totalEntradas: number;
    totalSaidas: number;
    saldoAtual: number;
  };
}

@Injectable()
export class SngpcService {
  private readonly logger = new Logger(SngpcService.name);
  private readonly sngpcUrl = 'https://sngpc.anvisa.gov.br/webservice/sngpc.asmx';
  private readonly usuario = process.env.SNGPC_USUARIO;
  private readonly senha = process.env.SNGPC_SENHA;

  constructor(private readonly httpService: HttpService) {}

  /**
   * Valida usuário no SNGPC
   */
  async validarUsuario(): Promise<boolean> {
    try {
      this.logger.log('Validando usuário SNGPC');

      if (!this.usuario || !this.senha) {
        this.logger.warn('Credenciais SNGPC não configuradas');
        return false;
      }

      const soapEnvelope = `
        <?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
                       xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
                       xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
          <soap:Body>
            <ValidarUsuario xmlns="http://tempuri.org/">
              <usuario>${this.usuario}</usuario>
              <senha>${this.senha}</senha>
            </ValidarUsuario>
          </soap:Body>
        </soap:Envelope>
      `;

      const response = await firstValueFrom(
        this.httpService.post(this.sngpcUrl, soapEnvelope, {
          headers: {
            'Content-Type': 'text/xml; charset=utf-8',
            'SOAPAction': 'http://tempuri.org/ValidarUsuario',
          },
          timeout: 30000,
        }),
      );

      // Parse da resposta XML
      const parser = new xml2js.Parser();
      const result = await parser.parseStringPromise(response.data);
      
      const validacao = result?.['soap:Envelope']?.['soap:Body']?.[0]?.['ValidarUsuarioResponse']?.[0]?.['ValidarUsuarioResult']?.[0];
      
      return validacao === 'true' || validacao === true;

    } catch (error) {
      this.logger.error(`Erro ao validar usuário SNGPC: ${error.message}`);
      return false;
    }
  }

  /**
   * Envia arquivo XML de movimentação para o SNGPC
   */
  async enviarMovimentacao(movimentacoes: SngpcMovimentacao[]): Promise<{
    sucesso: boolean;
    protocolo?: string;
    erros?: string[];
  }> {
    try {
      this.logger.log(`Enviando ${movimentacoes.length} movimentações para SNGPC`);

      // Valida usuário primeiro
      const usuarioValido = await this.validarUsuario();
      if (!usuarioValido) {
        throw new HttpException('Usuário SNGPC inválido', HttpStatus.UNAUTHORIZED);
      }

      // Gera XML das movimentações
      const xmlMovimentacoes = this.gerarXmlMovimentacoes(movimentacoes);
      
      const soapEnvelope = `
        <?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
                       xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
                       xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
          <soap:Body>
            <EnviaArquivoSNGPC xmlns="http://tempuri.org/">
              <usuario>${this.usuario}</usuario>
              <senha>${this.senha}</senha>
              <arquivo>${Buffer.from(xmlMovimentacoes).toString('base64')}</arquivo>
            </EnviaArquivoSNGPC>
          </soap:Body>
        </soap:Envelope>
      `;

      const response = await firstValueFrom(
        this.httpService.post(this.sngpcUrl, soapEnvelope, {
          headers: {
            'Content-Type': 'text/xml; charset=utf-8',
            'SOAPAction': 'http://tempuri.org/EnviaArquivoSNGPC',
          },
          timeout: 60000,
        }),
      );

      // Parse da resposta
      const parser = new xml2js.Parser();
      const result = await parser.parseStringPromise(response.data);
      
      const envioResult = result?.['soap:Envelope']?.['soap:Body']?.[0]?.['EnviaArquivoSNGPCResponse']?.[0]?.['EnviaArquivoSNGPCResult']?.[0];
      
      if (envioResult && envioResult.includes('SUCESSO')) {
        const protocolo = this.extrairProtocolo(envioResult);
        return {
          sucesso: true,
          protocolo,
        };
      } else {
        const erros = this.extrairErros(envioResult);
        return {
          sucesso: false,
          erros,
        };
      }

    } catch (error) {
      this.logger.error(`Erro ao enviar movimentação SNGPC: ${error.message}`);
      throw new HttpException(
        'Erro ao enviar dados para SNGPC',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Consulta dados de arquivo enviado
   */
  async consultarArquivo(protocolo: string): Promise<{
    status: string;
    dataProcessamento?: string;
    erros?: string[];
  }> {
    try {
      this.logger.log(`Consultando arquivo SNGPC: ${protocolo}`);

      const soapEnvelope = `
        <?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
                       xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
                       xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
          <soap:Body>
            <ConsultaDadosArquivoSNGPC xmlns="http://tempuri.org/">
              <usuario>${this.usuario}</usuario>
              <senha>${this.senha}</senha>
              <protocolo>${protocolo}</protocolo>
            </ConsultaDadosArquivoSNGPC>
          </soap:Body>
        </soap:Envelope>
      `;

      const response = await firstValueFrom(
        this.httpService.post(this.sngpcUrl, soapEnvelope, {
          headers: {
            'Content-Type': 'text/xml; charset=utf-8',
            'SOAPAction': 'http://tempuri.org/ConsultaDadosArquivoSNGPC',
          },
          timeout: 30000,
        }),
      );

      // Parse da resposta
      const parser = new xml2js.Parser();
      const result = await parser.parseStringPromise(response.data);
      
      const consultaResult = result?.['soap:Envelope']?.['soap:Body']?.[0]?.['ConsultaDadosArquivoSNGPCResponse']?.[0]?.['ConsultaDadosArquivoSNGPCResult']?.[0];
      
      return this.parseConsultaResult(consultaResult);

    } catch (error) {
      this.logger.error(`Erro ao consultar arquivo SNGPC: ${error.message}`);
      throw new HttpException(
        'Erro ao consultar arquivo no SNGPC',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Registra venda de medicamento controlado
   */
  async registrarVenda(venda: {
    codigoProduto: string;
    quantidade: number;
    lote: string;
    dataVencimento: string;
    cpfPaciente: string;
    numeroReceita: string;
    crfMedico: string;
    dataVenda: string;
  }): Promise<boolean> {
    try {
      this.logger.log(`Registrando venda SNGPC: ${venda.codigoProduto}`);

      const movimentacao: SngpcMovimentacao = {
        tipoMovimentacao: 'SAIDA',
        codigoProduto: venda.codigoProduto,
        nomeProduto: await this.obterNomeProduto(venda.codigoProduto),
        quantidade: venda.quantidade,
        lote: venda.lote,
        dataVencimento: venda.dataVencimento,
        dataMovimentacao: venda.dataVenda,
        cpfPaciente: venda.cpfPaciente,
        numeroReceita: venda.numeroReceita,
        crfMedico: venda.crfMedico,
      };

      const resultado = await this.enviarMovimentacao([movimentacao]);
      return resultado.sucesso;

    } catch (error) {
      this.logger.error(`Erro ao registrar venda SNGPC: ${error.message}`);
      return false;
    }
  }

  /**
   * Registra entrada de medicamento controlado
   */
  async registrarEntrada(entrada: {
    codigoProduto: string;
    quantidade: number;
    lote: string;
    dataVencimento: string;
    numeroNotaFiscal: string;
    cnpjFornecedor: string;
    dataEntrada: string;
  }): Promise<boolean> {
    try {
      this.logger.log(`Registrando entrada SNGPC: ${entrada.codigoProduto}`);

      const movimentacao: SngpcMovimentacao = {
        tipoMovimentacao: 'ENTRADA',
        codigoProduto: entrada.codigoProduto,
        nomeProduto: await this.obterNomeProduto(entrada.codigoProduto),
        quantidade: entrada.quantidade,
        lote: entrada.lote,
        dataVencimento: entrada.dataVencimento,
        dataMovimentacao: entrada.dataEntrada,
        numeroNotaFiscal: entrada.numeroNotaFiscal,
        cnpjFornecedor: entrada.cnpjFornecedor,
      };

      const resultado = await this.enviarMovimentacao([movimentacao]);
      return resultado.sucesso;

    } catch (error) {
      this.logger.error(`Erro ao registrar entrada SNGPC: ${error.message}`);
      return false;
    }
  }

  /**
   * Gera relatório de movimentações
   */
  async gerarRelatorio(dataInicio: string, dataFim: string): Promise<SngpcRelatorio> {
    try {
      this.logger.log(`Gerando relatório SNGPC: ${dataInicio} a ${dataFim}`);

      // Em um sistema real, isso consultaria a base de dados local
      // das movimentações enviadas ao SNGPC
      
      const movimentacoes: SngpcMovimentacao[] = [
        // Dados simulados - em produção viria do banco de dados
      ];

      const inventarios: SngpcInventario[] = [
        // Dados simulados - em produção viria do banco de dados
      ];

      const totalEntradas = movimentacoes
        .filter(m => m.tipoMovimentacao === 'ENTRADA')
        .reduce((sum, m) => sum + m.quantidade, 0);

      const totalSaidas = movimentacoes
        .filter(m => m.tipoMovimentacao === 'SAIDA')
        .reduce((sum, m) => sum + m.quantidade, 0);

      return {
        periodo: {
          dataInicio,
          dataFim,
        },
        movimentacoes,
        inventarios,
        resumo: {
          totalEntradas,
          totalSaidas,
          saldoAtual: totalEntradas - totalSaidas,
        },
      };

    } catch (error) {
      this.logger.error(`Erro ao gerar relatório SNGPC: ${error.message}`);
      throw new HttpException(
        'Erro ao gerar relatório SNGPC',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Verifica se um produto é controlado pelo SNGPC
   */
  async verificarProdutoControlado(codigoProduto: string): Promise<boolean> {
    try {
      // Lista simplificada de produtos controlados
      // Em produção, isso consultaria a base oficial da ANVISA
      const produtosControlados = [
        // Benzodiazepínicos
        '7896658003011', // Clonazepam
        '7896658003028', // Diazepam
        '7896658003035', // Alprazolam
        
        // Opioides
        '7896658004011', // Codeína
        '7896658004028', // Tramadol
        '7896658004035', // Morfina
        
        // Estimulantes
        '7896658005011', // Metilfenidato
        '7896658005028', // Anfetamina
      ];

      return produtosControlados.includes(codigoProduto);

    } catch (error) {
      this.logger.error(`Erro ao verificar produto controlado: ${error.message}`);
      return false;
    }
  }

  // Métodos auxiliares privados

  private gerarXmlMovimentacoes(movimentacoes: SngpcMovimentacao[]): string {
    const dataAtual = new Date().toISOString().split('T')[0];
    
    let xml = `<?xml version="1.0" encoding="UTF-8"?>
<SNGPC>
  <CABECALHO>
    <CNPJ_FARMACIA>${process.env.FARMACIA_CNPJ || '00000000000000'}</CNPJ_FARMACIA>
    <DATA_INICIAL>${dataAtual}</DATA_INICIAL>
    <DATA_FINAL>${dataAtual}</DATA_FINAL>
  </CABECALHO>
  <MOVIMENTACOES>`;

    movimentacoes.forEach((mov, index) => {
      xml += `
    <MOVIMENTACAO>
      <SEQUENCIAL>${index + 1}</SEQUENCIAL>
      <TIPO_MOVIMENTACAO>${mov.tipoMovimentacao}</TIPO_MOVIMENTACAO>
      <CODIGO_PRODUTO>${mov.codigoProduto}</CODIGO_PRODUTO>
      <NOME_PRODUTO>${mov.nomeProduto}</NOME_PRODUTO>
      <QUANTIDADE>${mov.quantidade}</QUANTIDADE>
      <LOTE>${mov.lote}</LOTE>
      <DATA_VENCIMENTO>${mov.dataVencimento}</DATA_VENCIMENTO>
      <DATA_MOVIMENTACAO>${mov.dataMovimentacao}</DATA_MOVIMENTACAO>`;
      
      if (mov.numeroNotaFiscal) {
        xml += `
      <NUMERO_NOTA_FISCAL>${mov.numeroNotaFiscal}</NUMERO_NOTA_FISCAL>`;
      }
      
      if (mov.cnpjFornecedor) {
        xml += `
      <CNPJ_FORNECEDOR>${mov.cnpjFornecedor}</CNPJ_FORNECEDOR>`;
      }
      
      if (mov.cpfPaciente) {
        xml += `
      <CPF_PACIENTE>${mov.cpfPaciente}</CPF_PACIENTE>`;
      }
      
      if (mov.numeroReceita) {
        xml += `
      <NUMERO_RECEITA>${mov.numeroReceita}</NUMERO_RECEITA>`;
      }
      
      if (mov.crfMedico) {
        xml += `
      <CRF_MEDICO>${mov.crfMedico}</CRF_MEDICO>`;
      }
      
      xml += `
    </MOVIMENTACAO>`;
    });

    xml += `
  </MOVIMENTACOES>
</SNGPC>`;

    return xml;
  }

  private extrairProtocolo(resultado: string): string {
    const match = resultado.match(/PROTOCOLO:\s*(\w+)/i);
    return match ? match[1] : '';
  }

  private extrairErros(resultado: string): string[] {
    if (!resultado) return ['Erro desconhecido'];
    
    const erros = resultado.split('\n')
      .filter(linha => linha.includes('ERRO') || linha.includes('ERROR'))
      .map(linha => linha.trim());
    
    return erros.length > 0 ? erros : [resultado];
  }

  private parseConsultaResult(resultado: string): {
    status: string;
    dataProcessamento?: string;
    erros?: string[];
  } {
    if (!resultado) {
      return { status: 'ERRO', erros: ['Resposta inválida'] };
    }

    if (resultado.includes('PROCESSADO')) {
      return {
        status: 'PROCESSADO',
        dataProcessamento: new Date().toISOString(),
      };
    }

    if (resultado.includes('PROCESSANDO')) {
      return { status: 'PROCESSANDO' };
    }

    return {
      status: 'ERRO',
      erros: this.extrairErros(resultado),
    };
  }

  private async obterNomeProduto(codigoProduto: string): Promise<string> {
    // Em produção, consultaria a base de produtos
    return `Produto ${codigoProduto}`;
  }
}

