import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToMany } from 'typeorm';
import { EquipmentLog } from './equipment-log.entity';

export enum EquipmentType {
  PRINTER = 'printer',
  FISCAL_PRINTER = 'fiscal_printer',
  SCALE = 'scale',
  COLD_CHAIN = 'cold_chain',
  BARCODE_READER = 'barcode_reader',
  POS_TERMINAL = 'pos_terminal',
  CAMERA = 'camera'
}

export enum EquipmentStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  MAINTENANCE = 'maintenance',
  ERROR = 'error'
}

@Entity('equipment')
export class Equipment {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  userId: string;

  @Column()
  name: string;

  @Column({
    type: 'text',
    enum: EquipmentType
  })
  type: EquipmentType;

  @Column()
  brand: string;

  @Column()
  model: string;

  @Column({ nullable: true })
  serialNumber: string;

  @Column({ nullable: true })
  ipAddress: string;

  @Column({ nullable: true })
  port: string;

  @Column({ nullable: true })
  connectionType: string; // USB, Network, Serial, Bluetooth

  @Column({
    type: 'text',
    enum: EquipmentStatus,
    default: EquipmentStatus.INACTIVE
  })
  status: EquipmentStatus;

  @Column({ type: 'json', nullable: true })
  configuration: any;

  @Column({ type: 'json', nullable: true })
  capabilities: any;

  @Column({ default: false })
  isCalibrated: boolean;

  @Column({ nullable: true })
  lastCalibration: Date;

  @Column({ nullable: true })
  nextCalibration: Date;

  @Column({ nullable: true })
  location: string;

  @Column({ default: true })
  isActive: boolean;

  @OneToMany(() => EquipmentLog, log => log.equipment)
  logs: EquipmentLog[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Métodos auxiliares
  needsCalibration(): boolean {
    if (!this.nextCalibration) return true;
    return new Date() > this.nextCalibration;
  }

  isOnline(): boolean {
    return this.status === EquipmentStatus.ACTIVE;
  }

  getConnectionString(): string {
    if (this.connectionType === 'Network' && this.ipAddress) {
      return `${this.ipAddress}:${this.port || '9100'}`;
    }
    return this.port || 'USB';
  }
}

