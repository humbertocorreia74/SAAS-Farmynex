import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Equipment } from './equipment.entity';

export enum LogType {
  CONNECTION = 'connection',
  DISCONNECTION = 'disconnection',
  ERROR = 'error',
  CALIBRATION = 'calibration',
  MAINTENANCE = 'maintenance',
  USAGE = 'usage'
}

@Entity('equipment_logs')
export class EquipmentLog {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  equipmentId: string;

  @Column({
    type: 'text',
    enum: LogType
  })
  type: LogType;

  @Column()
  message: string;

  @Column({ type: 'json', nullable: true })
  data: any;

  @Column({ nullable: true })
  userId: string;

  @ManyToOne(() => Equipment, equipment => equipment.logs)
  @JoinColumn({ name: 'equipmentId' })
  equipment: Equipment;

  @CreateDateColumn()
  createdAt: Date;
}

