import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Equipment, EquipmentType, EquipmentStatus } from '../entities/equipment.entity';
import { EquipmentLog, LogType } from '../entities/equipment-log.entity';

@Injectable()
export class EquipmentService {
  private readonly logger = new Logger(EquipmentService.name);

  constructor(
    @InjectRepository(Equipment)
    private equipmentRepository: Repository<Equipment>,
    @InjectRepository(EquipmentLog)
    private logRepository: Repository<EquipmentLog>,
  ) {}

  async findAllByUser(userId: string): Promise<Equipment[]> {
    return this.equipmentRepository.find({
      where: { userId, isActive: true },
      relations: ['logs'],
      order: { createdAt: 'DESC' },
    });
  }

  async findByType(userId: string, type: EquipmentType): Promise<Equipment[]> {
    return this.equipmentRepository.find({
      where: { userId, type, isActive: true },
    });
  }

  async create(userId: string, equipmentData: Partial<Equipment>): Promise<Equipment> {
    const equipment = this.equipmentRepository.create({
      ...equipmentData,
      userId,
    });
    
    const saved = await this.equipmentRepository.save(equipment);
    
    await this.logActivity(saved.id, LogType.CONNECTION, 'Equipamento registrado no sistema', userId);
    
    return saved;
  }

  async updateStatus(equipmentId: string, status: EquipmentStatus, userId?: string): Promise<Equipment> {
    const equipment = await this.equipmentRepository.findOne({
      where: { id: equipmentId },
    });

    if (!equipment) {
      throw new Error('Equipamento não encontrado');
    }

    equipment.status = status;
    const updated = await this.equipmentRepository.save(equipment);

    await this.logActivity(
      equipmentId,
      status === EquipmentStatus.ACTIVE ? LogType.CONNECTION : LogType.DISCONNECTION,
      `Status alterado para: ${status}`,
      userId
    );

    return updated;
  }

  async testConnection(equipmentId: string): Promise<boolean> {
    const equipment = await this.equipmentRepository.findOne({
      where: { id: equipmentId },
    });

    if (!equipment) {
      return false;
    }

    try {
      // Simular teste de conexão baseado no tipo
      const isConnected = await this.performConnectionTest(equipment);
      
      if (isConnected) {
        await this.updateStatus(equipmentId, EquipmentStatus.ACTIVE);
        await this.logActivity(equipmentId, LogType.CONNECTION, 'Teste de conexão bem-sucedido');
      } else {
        await this.updateStatus(equipmentId, EquipmentStatus.ERROR);
        await this.logActivity(equipmentId, LogType.ERROR, 'Falha no teste de conexão');
      }

      return isConnected;
    } catch (error) {
      this.logger.error(`Erro ao testar conexão do equipamento ${equipmentId}:`, error);
      await this.logActivity(equipmentId, LogType.ERROR, `Erro na conexão: ${error.message}`);
      return false;
    }
  }

  private async performConnectionTest(equipment: Equipment): Promise<boolean> {
    // Implementação específica por tipo de equipamento
    switch (equipment.type) {
      case EquipmentType.PRINTER:
      case EquipmentType.FISCAL_PRINTER:
        return this.testPrinterConnection(equipment);
      
      case EquipmentType.SCALE:
        return this.testScaleConnection(equipment);
      
      case EquipmentType.COLD_CHAIN:
        return this.testColdChainConnection(equipment);
      
      default:
        return true; // Assumir sucesso para tipos não implementados
    }
  }

  private async testPrinterConnection(equipment: Equipment): Promise<boolean> {
    // Implementar teste específico para impressoras
    // Por enquanto, simular baseado na configuração
    return equipment.ipAddress ? true : false;
  }

  private async testScaleConnection(equipment: Equipment): Promise<boolean> {
    // Implementar teste específico para balanças
    return equipment.port ? true : false;
  }

  private async testColdChainConnection(equipment: Equipment): Promise<boolean> {
    // Implementar teste específico para câmara fria
    return equipment.ipAddress ? true : false;
  }

  async logActivity(
    equipmentId: string,
    type: LogType,
    message: string,
    userId?: string,
    data?: any
  ): Promise<EquipmentLog> {
    const log = this.logRepository.create({
      equipmentId,
      type,
      message,
      userId,
      data,
    });

    return this.logRepository.save(log);
  }

  async getEquipmentLogs(equipmentId: string, limit = 50): Promise<EquipmentLog[]> {
    return this.logRepository.find({
      where: { equipmentId },
      order: { createdAt: 'DESC' },
      take: limit,
    });
  }

  async getEquipmentsThatNeedCalibration(userId: string): Promise<Equipment[]> {
    const equipment = await this.findAllByUser(userId);
    return equipment.filter(eq => eq.needsCalibration());
  }
}

