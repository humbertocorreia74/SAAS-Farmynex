import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EquipmentController } from './controllers/equipment.controller';
import { EquipmentService } from './services/equipment.service';
import { PrinterService } from './services/printer.service';
import { ScaleService } from './services/scale.service';
import { ColdChainService } from './services/cold-chain.service';
import { Equipment } from './entities/equipment.entity';
import { EquipmentLog } from './entities/equipment-log.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Equipment, EquipmentLog])],
  controllers: [EquipmentController],
  providers: [
    EquipmentService,
    PrinterService,
    ScaleService,
    ColdChainService,
  ],
  exports: [
    EquipmentService,
    PrinterService,
    ScaleService,
    ColdChainService,
  ],
})
export class EquipmentModule {}

