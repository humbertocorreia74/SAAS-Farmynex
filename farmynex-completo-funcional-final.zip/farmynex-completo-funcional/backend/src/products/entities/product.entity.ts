import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';

export enum ProductStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  OUT_OF_STOCK = 'out_of_stock',
  DISCONTINUED = 'discontinued',
}

export enum ProductCategory {
  MEDICATION = 'medication',
  COSMETICS = 'cosmetics',
  SUPPLEMENTS = 'supplements',
  HYGIENE = 'hygiene',
  MEDICAL_DEVICES = 'medical_devices',
  BABY_CARE = 'baby_care',
  OTHER = 'other',
}

@Entity('products')
@Index(['barcode'], { unique: true })
@Index(['name'])
@Index(['category'])
@Index(['status'])
export class Product {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ unique: true })
  barcode: string;

  @Column({ nullable: true })
  sku: string;

  @Column({
    type: 'varchar',
    default: ProductCategory.OTHER,
  })
  category: ProductCategory;

  @Column({ nullable: true })
  brand: string;

  @Column({ nullable: true })
  manufacturer: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  price: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  costPrice: number;

  @Column({ type: 'int', default: 0 })
  stock: number;

  @Column({ type: 'int', default: 10 })
  minStock: number;

  @Column({ type: 'int', default: 1000 })
  maxStock: number;

  @Column({
    type: 'varchar',
    default: ProductStatus.ACTIVE,
  })
  status: ProductStatus;

  @Column({ nullable: true })
  unit: string; // unidade (mg, ml, comprimidos, etc.)

  @Column({ type: 'date', nullable: true })
  expirationDate: Date;

  @Column({ nullable: true })
  batch: string;

  @Column({ nullable: true })
  location: string; // localização no estoque

  @Column({ type: 'json', nullable: true })
  images: string[];

  @Column({ type: 'json', nullable: true })
  tags: string[];

  @Column({ type: 'boolean', default: false })
  requiresPrescription: boolean;

  @Column({ type: 'boolean', default: false })
  isControlled: boolean;

  @Column({ type: 'text', nullable: true })
  activeIngredient: string;

  @Column({ type: 'text', nullable: true })
  dosage: string;

  @Column({ type: 'text', nullable: true })
  instructions: string;

  @Column({ type: 'text', nullable: true })
  contraindications: string;

  @Column({ type: 'text', nullable: true })
  sideEffects: string;

  @Column({ type: 'int', default: 0 })
  salesCount: number;

  @Column({ type: 'decimal', precision: 3, scale: 2, default: 0 })
  rating: number;

  @Column({ type: 'int', default: 0 })
  reviewsCount: number;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Getters calculados
  get isLowStock(): boolean {
    return this.stock <= this.minStock;
  }

  get isExpiringSoon(): boolean {
    if (!this.expirationDate) return false;
    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
    return this.expirationDate <= thirtyDaysFromNow;
  }

  get isExpired(): boolean {
    if (!this.expirationDate) return false;
    return this.expirationDate <= new Date();
  }

  get profitMargin(): number {
    if (!this.costPrice || this.costPrice === 0) return 0;
    return ((this.price - this.costPrice) / this.costPrice) * 100;
  }
}

