import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsNotEmpty,
  IsEnum,
  IsOptional,
  IsNumber,
  IsPositive,
  IsInt,
  Min,
  IsArray,
  IsBoolean,
  IsDateString,
  IsDecimal,
} from 'class-validator';
import { ProductCategory, ProductStatus } from '../entities/product.entity';
import { Transform } from 'class-transformer';

export class CreateProductDto {
  @ApiProperty({
    description: 'Nome do produto',
    example: 'Dipirona 500mg',
  })
  @IsString({ message: 'Nome deve ser uma string' })
  @IsNotEmpty({ message: 'Nome é obrigatório' })
  name: string;

  @ApiProperty({
    description: 'Descrição do produto',
    example: 'Analgésico e antitérmico',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Descrição deve ser uma string' })
  description?: string;

  @ApiProperty({
    description: 'Código de barras',
    example: '7891234567890',
  })
  @IsString({ message: 'Código de barras deve ser uma string' })
  @IsNotEmpty({ message: 'Código de barras é obrigatório' })
  barcode: string;

  @ApiProperty({
    description: 'SKU do produto',
    example: 'DIP-500-001',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'SKU deve ser uma string' })
  sku?: string;

  @ApiProperty({
    description: 'Categoria do produto',
    enum: ProductCategory,
    example: ProductCategory.MEDICATION,
  })
  @IsEnum(ProductCategory, { message: 'Categoria deve ser um valor válido' })
  category: ProductCategory;

  @ApiProperty({
    description: 'Marca do produto',
    example: 'Medley',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Marca deve ser uma string' })
  brand?: string;

  @ApiProperty({
    description: 'Fabricante do produto',
    example: 'Sanofi',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Fabricante deve ser uma string' })
  manufacturer?: string;

  @ApiProperty({
    description: 'Preço de venda',
    example: 15.99,
  })
  @IsNumber({}, { message: 'Preço deve ser um número' })
  @IsPositive({ message: 'Preço deve ser positivo' })
  @Transform(({ value }) => parseFloat(value))
  price: number;

  @ApiProperty({
    description: 'Preço de custo',
    example: 8.50,
    required: false,
  })
  @IsOptional()
  @IsNumber({}, { message: 'Preço de custo deve ser um número' })
  @IsPositive({ message: 'Preço de custo deve ser positivo' })
  @Transform(({ value }) => parseFloat(value))
  costPrice?: number;

  @ApiProperty({
    description: 'Quantidade em estoque',
    example: 100,
    default: 0,
  })
  @IsOptional()
  @IsInt({ message: 'Estoque deve ser um número inteiro' })
  @Min(0, { message: 'Estoque não pode ser negativo' })
  stock?: number;

  @ApiProperty({
    description: 'Estoque mínimo',
    example: 10,
    default: 10,
  })
  @IsOptional()
  @IsInt({ message: 'Estoque mínimo deve ser um número inteiro' })
  @Min(0, { message: 'Estoque mínimo não pode ser negativo' })
  minStock?: number;

  @ApiProperty({
    description: 'Estoque máximo',
    example: 1000,
    default: 1000,
  })
  @IsOptional()
  @IsInt({ message: 'Estoque máximo deve ser um número inteiro' })
  @Min(1, { message: 'Estoque máximo deve ser pelo menos 1' })
  maxStock?: number;

  @ApiProperty({
    description: 'Status do produto',
    enum: ProductStatus,
    example: ProductStatus.ACTIVE,
    default: ProductStatus.ACTIVE,
  })
  @IsOptional()
  @IsEnum(ProductStatus, { message: 'Status deve ser um valor válido' })
  status?: ProductStatus;

  @ApiProperty({
    description: 'Unidade do produto',
    example: 'comprimidos',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Unidade deve ser uma string' })
  unit?: string;

  @ApiProperty({
    description: 'Data de validade',
    example: '2025-12-31',
    required: false,
  })
  @IsOptional()
  @IsDateString({}, { message: 'Data de validade deve ser uma data válida' })
  expirationDate?: string;

  @ApiProperty({
    description: 'Lote do produto',
    example: 'L001234',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Lote deve ser uma string' })
  batch?: string;

  @ApiProperty({
    description: 'Localização no estoque',
    example: 'A1-B2-C3',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Localização deve ser uma string' })
  location?: string;

  @ApiProperty({
    description: 'URLs das imagens',
    example: ['https://example.com/image1.jpg'],
    required: false,
  })
  @IsOptional()
  @IsArray({ message: 'Imagens devem ser um array' })
  @IsString({ each: true, message: 'Cada imagem deve ser uma string' })
  images?: string[];

  @ApiProperty({
    description: 'Tags do produto',
    example: ['analgésico', 'antitérmico'],
    required: false,
  })
  @IsOptional()
  @IsArray({ message: 'Tags devem ser um array' })
  @IsString({ each: true, message: 'Cada tag deve ser uma string' })
  tags?: string[];

  @ApiProperty({
    description: 'Requer prescrição médica',
    example: false,
    default: false,
  })
  @IsOptional()
  @IsBoolean({ message: 'Requer prescrição deve ser um booleano' })
  requiresPrescription?: boolean;

  @ApiProperty({
    description: 'É medicamento controlado',
    example: false,
    default: false,
  })
  @IsOptional()
  @IsBoolean({ message: 'É controlado deve ser um booleano' })
  isControlled?: boolean;

  @ApiProperty({
    description: 'Princípio ativo',
    example: 'Dipirona Sódica',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Princípio ativo deve ser uma string' })
  activeIngredient?: string;

  @ApiProperty({
    description: 'Dosagem',
    example: '500mg',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Dosagem deve ser uma string' })
  dosage?: string;

  @ApiProperty({
    description: 'Instruções de uso',
    example: 'Tomar 1 comprimido a cada 6 horas',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Instruções devem ser uma string' })
  instructions?: string;

  @ApiProperty({
    description: 'Contraindicações',
    example: 'Não usar em caso de alergia ao princípio ativo',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Contraindicações devem ser uma string' })
  contraindications?: string;

  @ApiProperty({
    description: 'Efeitos colaterais',
    example: 'Pode causar sonolência',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Efeitos colaterais devem ser uma string' })
  sideEffects?: string;
}

