import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like, In } from 'typeorm';
import { Product, ProductStatus, ProductCategory } from './entities/product.entity';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Product)
    private productsRepository: Repository<Product>,
  ) {}

  async create(createProductDto: CreateProductDto): Promise<Product> {
    // Verificar se código de barras já existe
    const existingProduct = await this.productsRepository.findOne({
      where: { barcode: createProductDto.barcode },
    });

    if (existingProduct) {
      throw new ConflictException('Código de barras já está em uso');
    }

    const product = this.productsRepository.create(createProductDto);
    return this.productsRepository.save(product);
  }

  async findAll(filters?: {
    category?: ProductCategory;
    status?: ProductStatus;
    search?: string;
    lowStock?: boolean;
    expiring?: boolean;
    page?: number;
    limit?: number;
  }): Promise<{ products: Product[]; total: number; page: number; totalPages: number }> {
    const page = filters?.page || 1;
    const limit = filters?.limit || 20;
    const skip = (page - 1) * limit;

    const queryBuilder = this.productsRepository.createQueryBuilder('product');

    // Filtros
    if (filters?.category) {
      queryBuilder.andWhere('product.category = :category', { category: filters.category });
    }

    if (filters?.status) {
      queryBuilder.andWhere('product.status = :status', { status: filters.status });
    }

    if (filters?.search) {
      queryBuilder.andWhere(
        '(product.name ILIKE :search OR product.barcode ILIKE :search OR product.brand ILIKE :search)',
        { search: `%${filters.search}%` }
      );
    }

    if (filters?.lowStock) {
      queryBuilder.andWhere('product.stock <= product.minStock');
    }

    if (filters?.expiring) {
      const thirtyDaysFromNow = new Date();
      thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
      queryBuilder.andWhere('product.expirationDate <= :expirationDate', {
        expirationDate: thirtyDaysFromNow,
      });
    }

    // Ordenação
    queryBuilder.orderBy('product.name', 'ASC');

    // Paginação
    queryBuilder.skip(skip).take(limit);

    const [products, total] = await queryBuilder.getManyAndCount();
    const totalPages = Math.ceil(total / limit);

    return {
      products,
      total,
      page,
      totalPages,
    };
  }

  async findOne(id: string): Promise<Product> {
    const product = await this.productsRepository.findOne({ where: { id } });
    
    if (!product) {
      throw new NotFoundException('Produto não encontrado');
    }
    
    return product;
  }

  async findByBarcode(barcode: string): Promise<Product> {
    const product = await this.productsRepository.findOne({ where: { barcode } });
    
    if (!product) {
      throw new NotFoundException('Produto não encontrado');
    }
    
    return product;
  }

  async update(id: string, updateProductDto: UpdateProductDto): Promise<Product> {
    const product = await this.findOne(id);

    // Verificar se código de barras já existe (se estiver sendo alterado)
    if (updateProductDto.barcode && updateProductDto.barcode !== product.barcode) {
      const existingProduct = await this.productsRepository.findOne({
        where: { barcode: updateProductDto.barcode },
      });

      if (existingProduct) {
        throw new ConflictException('Código de barras já está em uso');
      }
    }

    Object.assign(product, updateProductDto);
    return this.productsRepository.save(product);
  }

  async updateStock(id: string, quantity: number, operation: 'add' | 'subtract'): Promise<Product> {
    const product = await this.findOne(id);

    if (operation === 'add') {
      product.stock += quantity;
    } else {
      product.stock = Math.max(0, product.stock - quantity);
    }

    // Atualizar status baseado no estoque
    if (product.stock === 0) {
      product.status = ProductStatus.OUT_OF_STOCK;
    } else if (product.status === ProductStatus.OUT_OF_STOCK) {
      product.status = ProductStatus.ACTIVE;
    }

    return this.productsRepository.save(product);
  }

  async remove(id: string): Promise<void> {
    const product = await this.findOne(id);
    await this.productsRepository.remove(product);
  }

  async getStats() {
    const total = await this.productsRepository.count();
    const active = await this.productsRepository.count({ where: { status: ProductStatus.ACTIVE } });
    const lowStock = await this.productsRepository
      .createQueryBuilder('product')
      .where('product.stock <= product.minStock')
      .getCount();
    
    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
    
    const expiring = await this.productsRepository.count({
      where: {
        expirationDate: In([thirtyDaysFromNow]),
      },
    });

    const outOfStock = await this.productsRepository.count({
      where: { status: ProductStatus.OUT_OF_STOCK },
    });

    return {
      total,
      active,
      lowStock,
      expiring,
      outOfStock,
      activePercentage: total > 0 ? Math.round((active / total) * 100) : 0,
    };
  }

  async getTopSelling(limit: number = 10): Promise<Product[]> {
    return this.productsRepository.find({
      order: { salesCount: 'DESC' },
      take: limit,
    });
  }

  async getLowStockProducts(): Promise<Product[]> {
    return this.productsRepository
      .createQueryBuilder('product')
      .where('product.stock <= product.minStock')
      .andWhere('product.status = :status', { status: ProductStatus.ACTIVE })
      .orderBy('product.stock', 'ASC')
      .getMany();
  }

  async getExpiringProducts(days: number = 30): Promise<Product[]> {
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + days);

    return this.productsRepository
      .createQueryBuilder('product')
      .where('product.expirationDate <= :targetDate', { targetDate })
      .andWhere('product.expirationDate > :now', { now: new Date() })
      .orderBy('product.expirationDate', 'ASC')
      .getMany();
  }

  async getExpiredProducts(): Promise<Product[]> {
    return this.productsRepository
      .createQueryBuilder('product')
      .where('product.expirationDate <= :now', { now: new Date() })
      .orderBy('product.expirationDate', 'ASC')
      .getMany();
  }

  async searchProducts(query: string): Promise<Product[]> {
    return this.productsRepository
      .createQueryBuilder('product')
      .where(
        'product.name ILIKE :query OR product.barcode ILIKE :query OR product.brand ILIKE :query OR product.activeIngredient ILIKE :query',
        { query: `%${query}%` }
      )
      .andWhere('product.status = :status', { status: ProductStatus.ACTIVE })
      .orderBy('product.name', 'ASC')
      .take(50)
      .getMany();
  }
}

