import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Query,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';
import { ProductsService } from './products.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ProductCategory, ProductStatus } from './entities/product.entity';

@ApiTags('products')
@Controller('products')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  @Post()
  @ApiOperation({ summary: 'Criar novo produto' })
  @ApiResponse({
    status: 201,
    description: 'Produto criado com sucesso',
  })
  @ApiResponse({
    status: 409,
    description: 'Código de barras já está em uso',
  })
  async create(@Body() createProductDto: CreateProductDto) {
    const product = await this.productsService.create(createProductDto);
    
    return {
      success: true,
      message: 'Produto criado com sucesso',
      data: product,
    };
  }

  @Get()
  @ApiOperation({ summary: 'Listar produtos com filtros' })
  @ApiQuery({ name: 'category', enum: ProductCategory, required: false })
  @ApiQuery({ name: 'status', enum: ProductStatus, required: false })
  @ApiQuery({ name: 'search', required: false })
  @ApiQuery({ name: 'lowStock', type: Boolean, required: false })
  @ApiQuery({ name: 'expiring', type: Boolean, required: false })
  @ApiQuery({ name: 'page', type: Number, required: false })
  @ApiQuery({ name: 'limit', type: Number, required: false })
  @ApiResponse({
    status: 200,
    description: 'Lista de produtos retornada com sucesso',
  })
  async findAll(
    @Query('category') category?: ProductCategory,
    @Query('status') status?: ProductStatus,
    @Query('search') search?: string,
    @Query('lowStock') lowStock?: boolean,
    @Query('expiring') expiring?: boolean,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
  ) {
    const result = await this.productsService.findAll({
      category,
      status,
      search,
      lowStock,
      expiring,
      page,
      limit,
    });

    return {
      success: true,
      data: result.products,
      pagination: {
        page: result.page,
        limit: limit || 20,
        total: result.total,
        totalPages: result.totalPages,
      },
    };
  }

  @Get('stats')
  @ApiOperation({ summary: 'Estatísticas de produtos' })
  @ApiResponse({
    status: 200,
    description: 'Estatísticas retornadas com sucesso',
  })
  async getStats() {
    const stats = await this.productsService.getStats();
    
    return {
      success: true,
      data: stats,
    };
  }

  @Get('top-selling')
  @ApiOperation({ summary: 'Produtos mais vendidos' })
  @ApiQuery({ name: 'limit', type: Number, required: false })
  @ApiResponse({
    status: 200,
    description: 'Produtos mais vendidos retornados com sucesso',
  })
  async getTopSelling(@Query('limit') limit?: number) {
    const products = await this.productsService.getTopSelling(limit);
    
    return {
      success: true,
      data: products,
      total: products.length,
    };
  }

  @Get('low-stock')
  @ApiOperation({ summary: 'Produtos com estoque baixo' })
  @ApiResponse({
    status: 200,
    description: 'Produtos com estoque baixo retornados com sucesso',
  })
  async getLowStockProducts() {
    const products = await this.productsService.getLowStockProducts();
    
    return {
      success: true,
      data: products,
      total: products.length,
    };
  }

  @Get('expiring')
  @ApiOperation({ summary: 'Produtos próximos ao vencimento' })
  @ApiQuery({ name: 'days', type: Number, required: false })
  @ApiResponse({
    status: 200,
    description: 'Produtos próximos ao vencimento retornados com sucesso',
  })
  async getExpiringProducts(@Query('days') days?: number) {
    const products = await this.productsService.getExpiringProducts(days);
    
    return {
      success: true,
      data: products,
      total: products.length,
    };
  }

  @Get('expired')
  @ApiOperation({ summary: 'Produtos vencidos' })
  @ApiResponse({
    status: 200,
    description: 'Produtos vencidos retornados com sucesso',
  })
  async getExpiredProducts() {
    const products = await this.productsService.getExpiredProducts();
    
    return {
      success: true,
      data: products,
      total: products.length,
    };
  }

  @Get('search')
  @ApiOperation({ summary: 'Buscar produtos' })
  @ApiQuery({ name: 'q', description: 'Termo de busca' })
  @ApiResponse({
    status: 200,
    description: 'Resultados da busca retornados com sucesso',
  })
  async searchProducts(@Query('q') query: string) {
    const products = await this.productsService.searchProducts(query);
    
    return {
      success: true,
      data: products,
      total: products.length,
    };
  }

  @Get('barcode/:barcode')
  @ApiOperation({ summary: 'Buscar produto por código de barras' })
  @ApiParam({ name: 'barcode', description: 'Código de barras do produto' })
  @ApiResponse({
    status: 200,
    description: 'Produto encontrado',
  })
  @ApiResponse({
    status: 404,
    description: 'Produto não encontrado',
  })
  async findByBarcode(@Param('barcode') barcode: string) {
    const product = await this.productsService.findByBarcode(barcode);
    
    return {
      success: true,
      data: product,
    };
  }

  @Get(':id')
  @ApiOperation({ summary: 'Buscar produto por ID' })
  @ApiParam({ name: 'id', description: 'ID do produto' })
  @ApiResponse({
    status: 200,
    description: 'Produto encontrado',
  })
  @ApiResponse({
    status: 404,
    description: 'Produto não encontrado',
  })
  async findOne(@Param('id') id: string) {
    const product = await this.productsService.findOne(id);
    
    return {
      success: true,
      data: product,
    };
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar produto' })
  @ApiParam({ name: 'id', description: 'ID do produto' })
  @ApiResponse({
    status: 200,
    description: 'Produto atualizado com sucesso',
  })
  async update(
    @Param('id') id: string,
    @Body() updateProductDto: UpdateProductDto,
  ) {
    const product = await this.productsService.update(id, updateProductDto);
    
    return {
      success: true,
      message: 'Produto atualizado com sucesso',
      data: product,
    };
  }

  @Patch(':id/stock')
  @ApiOperation({ summary: 'Atualizar estoque do produto' })
  @ApiParam({ name: 'id', description: 'ID do produto' })
  @ApiQuery({ name: 'quantity', type: Number })
  @ApiQuery({ name: 'operation', enum: ['add', 'subtract'] })
  @ApiResponse({
    status: 200,
    description: 'Estoque atualizado com sucesso',
  })
  async updateStock(
    @Param('id') id: string,
    @Query('quantity') quantity: number,
    @Query('operation') operation: 'add' | 'subtract',
  ) {
    const product = await this.productsService.updateStock(id, quantity, operation);
    
    return {
      success: true,
      message: 'Estoque atualizado com sucesso',
      data: product,
    };
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Remover produto' })
  @ApiParam({ name: 'id', description: 'ID do produto' })
  @ApiResponse({
    status: 200,
    description: 'Produto removido com sucesso',
  })
  async remove(@Param('id') id: string) {
    await this.productsService.remove(id);
    
    return {
      success: true,
      message: 'Produto removido com sucesso',
    };
  }
}

