import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { HttpModule } from '@nestjs/axios';
import { JwtModule } from '@nestjs/jwt';

// Serviços
import { MobileAuthService } from './auth/mobile-auth.service';
import { MobileSyncService } from './sync/mobile-sync.service';

// Controllers
import { MobileAuthController } from './auth/mobile-auth.controller';

// Entidades
import { MobileDevice } from './entities/mobile-device.entity';
import { MobileSession } from './entities/mobile-session.entity';
import { MobileNotification } from './entities/mobile-notification.entity';

// Módulos relacionados
import { UsersModule } from '../users/users.module';
import { ProductsModule } from '../products/products.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      MobileDevice,
      MobileSession,
      MobileNotification,
    ]),
    ConfigModule,
    HttpModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET || 'farmynex-mobile-secret',
      signOptions: { expiresIn: '7d' },
    }),
    UsersModule,
    ProductsModule,
  ],
  controllers: [
    MobileAuthController,
  ],
  providers: [
    MobileAuthService,
    MobileSyncService,
  ],
  exports: [
    MobileAuthService,
    MobileSyncService,
  ],
})
export class MobileModule {}

