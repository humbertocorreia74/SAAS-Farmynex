import {
  Controller,
  Post,
  Get,
  Delete,
  Body,
  Headers,
  Param,
  UseGuards,
  Request,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { MobileAuthService, MobileLoginDto } from './mobile-auth.service';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';

@ApiTags('mobile-auth')
@Controller('mobile/auth')
export class MobileAuthController {
  constructor(private readonly mobileAuthService: MobileAuthService) {}

  @Post('login')
  @ApiOperation({ summary: 'Login no aplicativo móvel' })
  @ApiResponse({ status: 200, description: 'Login realizado com sucesso' })
  @ApiResponse({ status: 401, description: 'Credenciais inválidas' })
  async mobileLogin(@Body() loginDto: MobileLoginDto) {
    try {
      const result = await this.mobileAuthService.mobileLogin(loginDto);
      
      return {
        success: true,
        data: result,
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Post('refresh')
  @ApiOperation({ summary: 'Renovar token de acesso' })
  @ApiResponse({ status: 200, description: 'Token renovado com sucesso' })
  @ApiResponse({ status: 401, description: 'Refresh token inválido' })
  async refreshToken(@Body() body: { refreshToken: string }) {
    try {
      const result = await this.mobileAuthService.refreshToken(body.refreshToken);
      
      return {
        success: true,
        data: result,
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Post('logout')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Logout do aplicativo móvel' })
  @ApiResponse({ status: 200, description: 'Logout realizado com sucesso' })
  async mobileLogout(@Headers('authorization') authorization: string) {
    try {
      const token = authorization?.replace('Bearer ', '');
      await this.mobileAuthService.mobileLogout(token);
      
      return {
        success: true,
        message: 'Logout realizado com sucesso',
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Get('devices')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Listar dispositivos do usuário' })
  @ApiResponse({ status: 200, description: 'Dispositivos listados com sucesso' })
  async getUserDevices(@Request() req) {
    try {
      const devices = await this.mobileAuthService.getUserDevices(req.user.id);
      
      return {
        success: true,
        data: devices,
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Delete('devices/:deviceId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Remover dispositivo' })
  @ApiResponse({ status: 200, description: 'Dispositivo removido com sucesso' })
  async removeDevice(@Request() req, @Param('deviceId') deviceId: string) {
    try {
      await this.mobileAuthService.removeDevice(req.user.id, deviceId);
      
      return {
        success: true,
        message: 'Dispositivo removido com sucesso',
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Post('push-token')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Atualizar token de push notification' })
  @ApiResponse({ status: 200, description: 'Push token atualizado com sucesso' })
  async updatePushToken(
    @Request() req,
    @Body() body: { pushToken: string }
  ) {
    try {
      await this.mobileAuthService.updatePushToken(req.user.deviceId, body.pushToken);
      
      return {
        success: true,
        message: 'Push token atualizado com sucesso',
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Get('session/validate')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Validar sessão atual' })
  @ApiResponse({ status: 200, description: 'Sessão válida' })
  async validateSession(@Request() req) {
    try {
      return {
        success: true,
        data: {
          valid: true,
          user: req.user,
          device: req.device,
        },
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }
}

