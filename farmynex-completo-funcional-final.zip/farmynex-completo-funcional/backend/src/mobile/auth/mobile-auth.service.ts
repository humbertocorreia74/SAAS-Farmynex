import { Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';

import { MobileDevice, DeviceType, DeviceStatus } from '../entities/mobile-device.entity';
import { MobileSession, SessionStatus } from '../entities/mobile-session.entity';
import { UsersService } from '../../users/users.service';

export interface MobileLoginDto {
  email: string;
  password: string;
  deviceId: string;
  deviceName: string;
  deviceType: DeviceType;
  osVersion: string;
  appVersion: string;
  pushToken?: string;
  deviceInfo?: {
    manufacturer?: string;
    model?: string;
    screenResolution?: string;
    timezone?: string;
    language?: string;
  };
}

export interface MobileAuthResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  user: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    role: string;
  };
  device: {
    id: string;
    deviceId: string;
    deviceName: string;
    lastSyncAt: Date;
  };
}

@Injectable()
export class MobileAuthService {
  private readonly logger = new Logger(MobileAuthService.name);

  constructor(
    @InjectRepository(MobileDevice)
    private readonly deviceRepository: Repository<MobileDevice>,
    @InjectRepository(MobileSession)
    private readonly sessionRepository: Repository<MobileSession>,
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  /**
   * Autentica usuário no app mobile
   */
  async mobileLogin(loginDto: MobileLoginDto): Promise<MobileAuthResponse> {
    try {
      this.logger.log(`Login mobile: ${loginDto.email} - Device: ${loginDto.deviceId}`);

      // Validar credenciais do usuário
      const user = await this.usersService.validateUser(loginDto.email, loginDto.password);
      if (!user) {
        throw new UnauthorizedException('Credenciais inválidas');
      }

      // Buscar ou criar dispositivo
      let device = await this.deviceRepository.findOne({
        where: { deviceId: loginDto.deviceId, userId: user.id },
      });

      if (!device) {
        device = this.deviceRepository.create({
          deviceId: loginDto.deviceId,
          deviceName: loginDto.deviceName,
          deviceType: loginDto.deviceType,
          osVersion: loginDto.osVersion,
          appVersion: loginDto.appVersion,
          pushToken: loginDto.pushToken,
          deviceInfo: loginDto.deviceInfo,
          status: DeviceStatus.ACTIVE,
          userId: user.id,
          lastActiveAt: new Date(),
        });
        await this.deviceRepository.save(device);
      } else {
        // Atualizar informações do dispositivo
        device.deviceName = loginDto.deviceName;
        device.osVersion = loginDto.osVersion;
        device.appVersion = loginDto.appVersion;
        device.pushToken = loginDto.pushToken;
        device.deviceInfo = loginDto.deviceInfo;
        device.lastActiveAt = new Date();
        device.status = DeviceStatus.ACTIVE;
        await this.deviceRepository.save(device);
      }

      // Revogar sessões ativas antigas do mesmo dispositivo
      await this.sessionRepository.update(
        { deviceId: device.id, status: SessionStatus.ACTIVE },
        { status: SessionStatus.REVOKED }
      );

      // Criar nova sessão
      const sessionToken = this.generateSessionToken();
      const refreshToken = this.generateRefreshToken();
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 horas
      const refreshExpiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 dias

      const session = this.sessionRepository.create({
        sessionToken,
        refreshToken,
        status: SessionStatus.ACTIVE,
        expiresAt,
        refreshExpiresAt,
        deviceId: device.id,
        lastActivityAt: new Date(),
      });
      await this.sessionRepository.save(session);

      // Gerar JWT
      const payload = {
        sub: user.id,
        email: user.email,
        deviceId: device.id,
        sessionId: session.id,
        type: 'mobile',
      };

      const accessToken = this.jwtService.sign(payload, {
        expiresIn: '24h',
      });

      return {
        accessToken,
        refreshToken,
        expiresIn: 24 * 60 * 60, // 24 horas em segundos
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        },
        device: {
          id: device.id,
          deviceId: device.deviceId,
          deviceName: device.deviceName,
          lastSyncAt: device.lastSyncAt,
        },
      };
    } catch (error) {
      this.logger.error(`Erro no login mobile: ${error.message}`);
      throw error;
    }
  }

  /**
   * Renova token de acesso usando refresh token
   */
  async refreshToken(refreshToken: string): Promise<{
    accessToken: string;
    expiresIn: number;
  }> {
    try {
      this.logger.log('Renovando token mobile');

      const session = await this.sessionRepository.findOne({
        where: { refreshToken, status: SessionStatus.ACTIVE },
        relations: ['device', 'device.user'],
      });

      if (!session) {
        throw new UnauthorizedException('Refresh token inválido');
      }

      if (session.refreshExpiresAt < new Date()) {
        session.status = SessionStatus.EXPIRED;
        await this.sessionRepository.save(session);
        throw new UnauthorizedException('Refresh token expirado');
      }

      // Atualizar última atividade
      session.lastActivityAt = new Date();
      await this.sessionRepository.save(session);

      // Gerar novo access token
      const payload = {
        sub: session.device.user.id,
        email: session.device.user.email,
        deviceId: session.device.id,
        sessionId: session.id,
        type: 'mobile',
      };

      const accessToken = this.jwtService.sign(payload, {
        expiresIn: '24h',
      });

      return {
        accessToken,
        expiresIn: 24 * 60 * 60,
      };
    } catch (error) {
      this.logger.error(`Erro ao renovar token: ${error.message}`);
      throw error;
    }
  }

  /**
   * Logout do dispositivo móvel
   */
  async mobileLogout(sessionToken: string): Promise<void> {
    try {
      this.logger.log('Logout mobile');

      const session = await this.sessionRepository.findOne({
        where: { sessionToken, status: SessionStatus.ACTIVE },
      });

      if (session) {
        session.status = SessionStatus.REVOKED;
        await this.sessionRepository.save(session);
      }
    } catch (error) {
      this.logger.error(`Erro no logout mobile: ${error.message}`);
      throw error;
    }
  }

  /**
   * Valida sessão móvel
   */
  async validateMobileSession(sessionToken: string): Promise<{
    valid: boolean;
    user?: any;
    device?: MobileDevice;
  }> {
    try {
      const session = await this.sessionRepository.findOne({
        where: { sessionToken, status: SessionStatus.ACTIVE },
        relations: ['device', 'device.user'],
      });

      if (!session) {
        return { valid: false };
      }

      if (session.expiresAt < new Date()) {
        session.status = SessionStatus.EXPIRED;
        await this.sessionRepository.save(session);
        return { valid: false };
      }

      // Atualizar última atividade
      session.lastActivityAt = new Date();
      session.device.lastActiveAt = new Date();
      await this.sessionRepository.save(session);
      await this.deviceRepository.save(session.device);

      return {
        valid: true,
        user: session.device.user,
        device: session.device,
      };
    } catch (error) {
      this.logger.error(`Erro ao validar sessão: ${error.message}`);
      return { valid: false };
    }
  }

  /**
   * Lista dispositivos do usuário
   */
  async getUserDevices(userId: string): Promise<MobileDevice[]> {
    try {
      return await this.deviceRepository.find({
        where: { userId },
        order: { lastActiveAt: 'DESC' },
      });
    } catch (error) {
      this.logger.error(`Erro ao listar dispositivos: ${error.message}`);
      throw error;
    }
  }

  /**
   * Remove dispositivo
   */
  async removeDevice(userId: string, deviceId: string): Promise<void> {
    try {
      const device = await this.deviceRepository.findOne({
        where: { id: deviceId, userId },
      });

      if (!device) {
        throw new Error('Dispositivo não encontrado');
      }

      // Revogar todas as sessões do dispositivo
      await this.sessionRepository.update(
        { deviceId: device.id },
        { status: SessionStatus.REVOKED }
      );

      // Marcar dispositivo como inativo
      device.status = DeviceStatus.INACTIVE;
      await this.deviceRepository.save(device);
    } catch (error) {
      this.logger.error(`Erro ao remover dispositivo: ${error.message}`);
      throw error;
    }
  }

  /**
   * Atualiza push token do dispositivo
   */
  async updatePushToken(deviceId: string, pushToken: string): Promise<void> {
    try {
      await this.deviceRepository.update(
        { id: deviceId },
        { pushToken }
      );
    } catch (error) {
      this.logger.error(`Erro ao atualizar push token: ${error.message}`);
      throw error;
    }
  }

  private generateSessionToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  private generateRefreshToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }
}

