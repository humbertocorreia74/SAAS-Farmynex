import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  OneToMany,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { MobileSession } from './mobile-session.entity';

export enum DeviceType {
  ANDROID = 'android',
  IOS = 'ios',
  WEB = 'web',
}

export enum DeviceStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  BLOCKED = 'blocked',
}

@Entity('mobile_devices')
export class MobileDevice {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  deviceId: string;

  @Column()
  deviceName: string;

  @Column({
    type: 'varchar',
    length: 20,
  })
  deviceType: DeviceType;

  @Column()
  osVersion: string;

  @Column()
  appVersion: string;

  @Column({
    type: 'varchar',
    length: 20,
    default: DeviceStatus.ACTIVE,
  })
  status: DeviceStatus;

  @Column({ nullable: true })
  pushToken: string;

  @Column({ type: 'json', nullable: true })
  deviceInfo: {
    manufacturer?: string;
    model?: string;
    screenResolution?: string;
    timezone?: string;
    language?: string;
  };

  @Column({ type: 'datetime', nullable: true })
  lastActiveAt: Date;

  @Column({ type: 'datetime', nullable: true })
  lastSyncAt: Date;

  @ManyToOne(() => User, (user) => user.id)
  user: User;

  @Column()
  userId: string;

  @OneToMany(() => MobileSession, (session) => session.device)
  sessions: MobileSession[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

