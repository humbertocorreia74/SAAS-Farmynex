import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { MobileDevice } from './mobile-device.entity';

export enum SessionStatus {
  ACTIVE = 'active',
  EXPIRED = 'expired',
  REVOKED = 'revoked',
}

@Entity('mobile_sessions')
export class MobileSession {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  sessionToken: string;

  @Column({ unique: true })
  refreshToken: string;

  @Column({
    type: 'varchar',
    length: 20,
    default: SessionStatus.ACTIVE,
  })
  status: SessionStatus;

  @Column({ type: 'datetime' })
  expiresAt: Date;

  @Column({ type: 'datetime' })
  refreshExpiresAt: Date;

  @Column({ type: 'json', nullable: true })
  sessionData: {
    ipAddress?: string;
    userAgent?: string;
    location?: {
      latitude: number;
      longitude: number;
      accuracy: number;
    };
  };

  @Column({ type: 'datetime', nullable: true })
  lastActivityAt: Date;

  @ManyToOne(() => MobileDevice, (device) => device.sessions)
  device: MobileDevice;

  @Column()
  deviceId: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

