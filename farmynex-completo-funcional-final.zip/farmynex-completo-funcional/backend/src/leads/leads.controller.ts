import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Query,
  Request,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';
import { LeadsService } from './leads.service';
import { CreateLeadDto } from './dto/create-lead.dto';
import { UpdateLeadDto } from './dto/update-lead.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { LeadStatus, LeadTemperature, LeadPriority } from './entities/lead.entity';

@ApiTags('leads')
@Controller('leads')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class LeadsController {
  constructor(private readonly leadsService: LeadsService) {}

  @Post()
  @ApiOperation({ summary: 'Criar novo lead' })
  @ApiResponse({
    status: 201,
    description: 'Lead criado com sucesso',
  })
  @ApiResponse({
    status: 409,
    description: 'Lead com este email já existe',
  })
  async create(@Body() createLeadDto: CreateLeadDto) {
    const lead = await this.leadsService.create(createLeadDto);
    
    return {
      success: true,
      message: 'Lead criado com sucesso',
      data: lead,
    };
  }

  @Get()
  @ApiOperation({ summary: 'Listar leads com filtros' })
  @ApiQuery({ name: 'status', enum: LeadStatus, required: false })
  @ApiQuery({ name: 'temperature', enum: LeadTemperature, required: false })
  @ApiQuery({ name: 'priority', enum: LeadPriority, required: false })
  @ApiQuery({ name: 'assignedTo', required: false })
  @ApiQuery({ name: 'search', required: false })
  @ApiQuery({ name: 'tags', required: false })
  @ApiQuery({ name: 'page', type: Number, required: false })
  @ApiQuery({ name: 'limit', type: Number, required: false })
  @ApiResponse({
    status: 200,
    description: 'Lista de leads retornada com sucesso',
  })
  async findAll(
    @Query('status') status?: LeadStatus,
    @Query('temperature') temperature?: LeadTemperature,
    @Query('priority') priority?: LeadPriority,
    @Query('assignedTo') assignedTo?: string,
    @Query('search') search?: string,
    @Query('tags') tags?: string,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
  ) {
    const tagsArray = tags ? tags.split(',') : undefined;
    
    const result = await this.leadsService.findAll({
      status,
      temperature,
      priority,
      assignedTo,
      search,
      tags: tagsArray,
      page,
      limit,
    });

    return {
      success: true,
      data: result.leads,
      pagination: {
        page: result.page,
        limit: limit || 20,
        total: result.total,
        totalPages: result.totalPages,
      },
    };
  }

  @Get('stats')
  @ApiOperation({ summary: 'Estatísticas de leads' })
  @ApiResponse({
    status: 200,
    description: 'Estatísticas retornadas com sucesso',
  })
  async getStats() {
    const stats = await this.leadsService.getLeadsStats();
    
    return {
      success: true,
      data: stats,
    };
  }

  @Get('by-temperature')
  @ApiOperation({ summary: 'Leads agrupados por temperatura' })
  @ApiResponse({
    status: 200,
    description: 'Leads agrupados por temperatura retornados com sucesso',
  })
  async getLeadsByTemperature() {
    const leads = await this.leadsService.getLeadsByTemperature();
    
    return {
      success: true,
      data: leads,
    };
  }

  @Get('follow-up')
  @ApiOperation({ summary: 'Leads que precisam de follow-up' })
  @ApiResponse({
    status: 200,
    description: 'Leads para follow-up retornados com sucesso',
  })
  async getLeadsNeedingFollowUp() {
    const leads = await this.leadsService.getLeadsNeedingFollowUp();
    
    return {
      success: true,
      data: leads,
      total: leads.length,
    };
  }

  @Get(':id')
  @ApiOperation({ summary: 'Buscar lead por ID' })
  @ApiParam({ name: 'id', description: 'ID do lead' })
  @ApiResponse({
    status: 200,
    description: 'Lead encontrado',
  })
  @ApiResponse({
    status: 404,
    description: 'Lead não encontrado',
  })
  async findOne(@Param('id') id: string) {
    const lead = await this.leadsService.findOne(id);
    
    return {
      success: true,
      data: lead,
    };
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar lead' })
  @ApiParam({ name: 'id', description: 'ID do lead' })
  @ApiResponse({
    status: 200,
    description: 'Lead atualizado com sucesso',
  })
  async update(
    @Param('id') id: string,
    @Body() updateLeadDto: UpdateLeadDto,
  ) {
    const lead = await this.leadsService.update(id, updateLeadDto);
    
    return {
      success: true,
      message: 'Lead atualizado com sucesso',
      data: lead,
    };
  }

  @Patch(':id/status')
  @ApiOperation({ summary: 'Atualizar status do lead' })
  @ApiParam({ name: 'id', description: 'ID do lead' })
  @ApiQuery({ name: 'status', enum: LeadStatus })
  @ApiResponse({
    status: 200,
    description: 'Status atualizado com sucesso',
  })
  async updateStatus(
    @Param('id') id: string,
    @Query('status') status: LeadStatus,
  ) {
    const lead = await this.leadsService.updateStatus(id, status);
    
    return {
      success: true,
      message: 'Status atualizado com sucesso',
      data: lead,
    };
  }

  @Patch(':id/score')
  @ApiOperation({ summary: 'Atualizar score do lead' })
  @ApiParam({ name: 'id', description: 'ID do lead' })
  @ApiQuery({ name: 'score', type: Number })
  @ApiResponse({
    status: 200,
    description: 'Score atualizado com sucesso',
  })
  async updateScore(
    @Param('id') id: string,
    @Query('score') score: number,
  ) {
    const lead = await this.leadsService.updateScore(id, score);
    
    return {
      success: true,
      message: 'Score atualizado com sucesso',
      data: lead,
    };
  }

  @Patch('bulk/temperature')
  @ApiOperation({ summary: 'Atualizar temperatura de múltiplos leads' })
  @ApiResponse({
    status: 200,
    description: 'Temperatura atualizada com sucesso',
  })
  async bulkUpdateTemperature(
    @Body() body: { leadIds: string[]; temperature: LeadTemperature },
  ) {
    await this.leadsService.bulkUpdateTemperature(body.leadIds, body.temperature);
    
    return {
      success: true,
      message: 'Temperatura atualizada com sucesso',
    };
  }

  @Patch('bulk/assign')
  @ApiOperation({ summary: 'Atribuir múltiplos leads a um usuário' })
  @ApiResponse({
    status: 200,
    description: 'Leads atribuídos com sucesso',
  })
  async assignLeads(
    @Body() body: { leadIds: string[]; assignedTo: string },
  ) {
    await this.leadsService.assignLeads(body.leadIds, body.assignedTo);
    
    return {
      success: true,
      message: 'Leads atribuídos com sucesso',
    };
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Remover lead' })
  @ApiParam({ name: 'id', description: 'ID do lead' })
  @ApiResponse({
    status: 200,
    description: 'Lead removido com sucesso',
  })
  async remove(@Param('id') id: string) {
    await this.leadsService.remove(id);
    
    return {
      success: true,
      message: 'Lead removido com sucesso',
    };
  }
}

