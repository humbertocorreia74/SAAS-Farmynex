import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import { Lead, LeadStatus, LeadTemperature, LeadPriority } from './entities/lead.entity';
import { CreateLeadDto } from './dto/create-lead.dto';
import { UpdateLeadDto } from './dto/update-lead.dto';
import { ProductsService } from '../products/products.service';

@Injectable()
export class LeadsService {
  constructor(
    @InjectRepository(Lead)
    private leadsRepository: Repository<Lead>,
    private productsService: ProductsService,
  ) {}

  async create(createLeadDto: CreateLeadDto): Promise<Lead> {
    // Verificar se email já existe
    const existingLead = await this.leadsRepository.findOne({
      where: { email: createLeadDto.email },
    });

    if (existingLead) {
      throw new ConflictException('Lead com este email já existe');
    }

    const lead = this.leadsRepository.create({
      ...createLeadDto,
      ...(createLeadDto.utmParams || {}),
    });

    // Aplicar classificação IA inicial
    await this.classifyLeadWithAI(lead);

    // Sugerir produtos baseado nos interesses
    if (createLeadDto.interests?.length > 0) {
      await this.suggestProductsForLead(lead);
    }

    return this.leadsRepository.save(lead);
  }

  async findAll(filters?: {
    status?: LeadStatus;
    temperature?: LeadTemperature;
    priority?: LeadPriority;
    assignedTo?: string;
    search?: string;
    tags?: string[];
    page?: number;
    limit?: number;
  }): Promise<{ leads: Lead[]; total: number; page: number; totalPages: number }> {
    const page = filters?.page || 1;
    const limit = filters?.limit || 20;
    const skip = (page - 1) * limit;

    const queryBuilder = this.leadsRepository.createQueryBuilder('lead');

    // Filtros
    if (filters?.status) {
      queryBuilder.andWhere('lead.status = :status', { status: filters.status });
    }

    if (filters?.temperature) {
      queryBuilder.andWhere('lead.temperature = :temperature', { temperature: filters.temperature });
    }

    if (filters?.priority) {
      queryBuilder.andWhere('lead.priority = :priority', { priority: filters.priority });
    }

    if (filters?.assignedTo) {
      queryBuilder.andWhere('lead.assignedTo = :assignedTo', { assignedTo: filters.assignedTo });
    }

    if (filters?.search) {
      queryBuilder.andWhere(
        '(lead.firstName ILIKE :search OR lead.lastName ILIKE :search OR lead.email ILIKE :search OR lead.company ILIKE :search)',
        { search: `%${filters.search}%` }
      );
    }

    if (filters?.tags?.length > 0) {
      queryBuilder.andWhere('lead.tags && :tags', { tags: filters.tags });
    }

    // Ordenação por score (IA) e data de criação
    queryBuilder.orderBy('lead.score', 'DESC').addOrderBy('lead.createdAt', 'DESC');

    // Paginação
    queryBuilder.skip(skip).take(limit);

    const [leads, total] = await queryBuilder.getManyAndCount();
    const totalPages = Math.ceil(total / limit);

    return {
      leads,
      total,
      page,
      totalPages,
    };
  }

  async findOne(id: string): Promise<Lead> {
    const lead = await this.leadsRepository.findOne({ where: { id } });
    
    if (!lead) {
      throw new NotFoundException('Lead não encontrado');
    }
    
    return lead;
  }

  async update(id: string, updateLeadDto: UpdateLeadDto): Promise<Lead> {
    const lead = await this.findOne(id);

    Object.assign(lead, updateLeadDto);

    // Reclassificar com IA se houve mudanças relevantes
    if (updateLeadDto.interests || updateLeadDto.notes || updateLeadDto.estimatedValue) {
      await this.classifyLeadWithAI(lead);
    }

    return this.leadsRepository.save(lead);
  }

  async remove(id: string): Promise<void> {
    const lead = await this.findOne(id);
    await this.leadsRepository.remove(lead);
  }

  async updateStatus(id: string, status: LeadStatus): Promise<Lead> {
    const lead = await this.findOne(id);
    lead.status = status;
    lead.lastActivityAt = new Date();

    if (status === LeadStatus.CONTACTED) {
      lead.lastContactAt = new Date();
    }

    return this.leadsRepository.save(lead);
  }

  async updateScore(id: string, score: number): Promise<Lead> {
    const lead = await this.findOne(id);
    lead.score = Math.max(0, Math.min(100, score));
    
    // Atualizar temperatura baseada no score
    if (lead.score >= 80) {
      lead.temperature = LeadTemperature.HOT;
      lead.priority = LeadPriority.HIGH;
    } else if (lead.score >= 50) {
      lead.temperature = LeadTemperature.WARM;
      lead.priority = LeadPriority.MEDIUM;
    } else {
      lead.temperature = LeadTemperature.COLD;
      lead.priority = LeadPriority.LOW;
    }

    return this.leadsRepository.save(lead);
  }

  async getLeadsByTemperature(): Promise<{
    hot: Lead[];
    warm: Lead[];
    cold: Lead[];
  }> {
    const hot = await this.leadsRepository.find({
      where: { temperature: LeadTemperature.HOT },
      order: { score: 'DESC' },
      take: 10,
    });

    const warm = await this.leadsRepository.find({
      where: { temperature: LeadTemperature.WARM },
      order: { score: 'DESC' },
      take: 10,
    });

    const cold = await this.leadsRepository.find({
      where: { temperature: LeadTemperature.COLD },
      order: { createdAt: 'DESC' },
      take: 10,
    });

    return { hot, warm, cold };
  }

  async getLeadsStats() {
    const total = await this.leadsRepository.count();
    const hot = await this.leadsRepository.count({ where: { temperature: LeadTemperature.HOT } });
    const warm = await this.leadsRepository.count({ where: { temperature: LeadTemperature.WARM } });
    const cold = await this.leadsRepository.count({ where: { temperature: LeadTemperature.COLD } });
    
    const converted = await this.leadsRepository.count({ where: { status: LeadStatus.CONVERTED } });
    const qualified = await this.leadsRepository.count({ where: { status: LeadStatus.QUALIFIED } });

    const avgScore = await this.leadsRepository
      .createQueryBuilder('lead')
      .select('AVG(lead.score)', 'avgScore')
      .getRawOne();

    return {
      total,
      hot,
      warm,
      cold,
      converted,
      qualified,
      conversionRate: total > 0 ? Math.round((converted / total) * 100) : 0,
      averageScore: Math.round(avgScore?.avgScore || 0),
    };
  }

  async getLeadsNeedingFollowUp(): Promise<Lead[]> {
    const threeDaysAgo = new Date();
    threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);

    return this.leadsRepository
      .createQueryBuilder('lead')
      .where('lead.status IN (:...statuses)', { 
        statuses: [LeadStatus.NEW, LeadStatus.CONTACTED] 
      })
      .andWhere('(lead.lastContactAt IS NULL OR lead.lastContactAt < :threeDaysAgo)', { 
        threeDaysAgo 
      })
      .orderBy('lead.score', 'DESC')
      .getMany();
  }

  // Método de IA para classificar leads
  private async classifyLeadWithAI(lead: Lead): Promise<void> {
    let score = 0;

    // Pontuação baseada em dados do lead
    if (lead.company) score += 20;
    if (lead.position) score += 15;
    if (lead.phone) score += 10;
    if (lead.estimatedValue && lead.estimatedValue > 1000) score += 25;
    if (lead.interests && lead.interests.length > 0) score += 20;

    // Pontuação baseada na fonte
    switch (lead.source) {
      case 'referral':
        score += 30;
        break;
      case 'website':
        score += 20;
        break;
      case 'social_media':
        score += 15;
        break;
      default:
        score += 10;
    }

    // Análise de texto das notas (simulação de NLP)
    if (lead.notes) {
      const positiveKeywords = ['interessado', 'urgente', 'comprar', 'orçamento', 'proposta'];
      const negativeKeywords = ['talvez', 'futuro', 'pensando', 'não sei'];
      
      const notesLower = lead.notes.toLowerCase();
      
      positiveKeywords.forEach(keyword => {
        if (notesLower.includes(keyword)) score += 10;
      });
      
      negativeKeywords.forEach(keyword => {
        if (notesLower.includes(keyword)) score -= 5;
      });
    }

    // Garantir que o score está entre 0 e 100
    lead.score = Math.max(0, Math.min(100, score));

    // Definir temperatura baseada no score
    if (lead.score >= 80) {
      lead.temperature = LeadTemperature.HOT;
      lead.priority = LeadPriority.HIGH;
    } else if (lead.score >= 50) {
      lead.temperature = LeadTemperature.WARM;
      lead.priority = LeadPriority.MEDIUM;
    } else {
      lead.temperature = LeadTemperature.COLD;
      lead.priority = LeadPriority.LOW;
    }
  }

  // Método de IA para sugerir produtos
  private async suggestProductsForLead(lead: Lead): Promise<void> {
    if (!lead.interests || lead.interests.length === 0) return;

    const suggestedProducts = [];

    for (const interest of lead.interests) {
      try {
        // Buscar produtos relacionados ao interesse
        const products = await this.productsService.searchProducts(interest);
        
        // Pegar os 2 melhores produtos por interesse
        const topProducts = products
          .slice(0, 2)
          .map(product => product.id);
        
        suggestedProducts.push(...topProducts);
      } catch (error) {
        // Ignorar erros de busca de produtos
        console.log(`Erro ao buscar produtos para interesse ${interest}:`, error.message);
      }
    }

    // Remover duplicatas e limitar a 5 produtos
    lead.suggestedProducts = [...new Set(suggestedProducts)].slice(0, 5);
  }

  async bulkUpdateTemperature(leadIds: string[], temperature: LeadTemperature): Promise<void> {
    await this.leadsRepository.update(
      { id: In(leadIds) },
      { temperature, lastActivityAt: new Date() }
    );
  }

  async assignLeads(leadIds: string[], assignedTo: string): Promise<void> {
    await this.leadsRepository.update(
      { id: In(leadIds) },
      { assignedTo, lastActivityAt: new Date() }
    );
  }
}

