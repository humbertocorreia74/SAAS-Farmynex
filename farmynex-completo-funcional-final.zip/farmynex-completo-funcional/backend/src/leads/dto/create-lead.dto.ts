import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsNotEmpty,
  IsEmail,
  IsOptional,
  IsEnum,
  IsArray,
  IsNumber,
  Min,
  Max,
  IsPhoneNumber,
  IsObject,
} from 'class-validator';
import { LeadSource, LeadTemperature, LeadPriority } from '../entities/lead.entity';

export class CreateLeadDto {
  @ApiProperty({
    description: 'Primeiro nome do lead',
    example: 'João',
  })
  @IsString({ message: 'Primeiro nome deve ser uma string' })
  @IsNotEmpty({ message: 'Primeiro nome é obrigatório' })
  firstName: string;

  @ApiProperty({
    description: 'Último nome do lead',
    example: 'Silva',
  })
  @IsString({ message: 'Último nome deve ser uma string' })
  @IsNotEmpty({ message: 'Último nome é obrigatório' })
  lastName: string;

  @ApiProperty({
    description: 'Email do lead',
    example: 'joao.silva@email.com',
  })
  @IsEmail({}, { message: 'Email deve ter um formato válido' })
  @IsNotEmpty({ message: 'Email é obrigatório' })
  email: string;

  @ApiProperty({
    description: 'Telefone do lead',
    example: '+5511999999999',
    required: false,
  })
  @IsOptional()
  @IsPhoneNumber('BR', { message: 'Telefone deve ter um formato válido' })
  phone?: string;

  @ApiProperty({
    description: 'Empresa do lead',
    example: 'Farmácia Central',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Empresa deve ser uma string' })
  company?: string;

  @ApiProperty({
    description: 'Cargo do lead',
    example: 'Farmacêutico Responsável',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Cargo deve ser uma string' })
  position?: string;

  @ApiProperty({
    description: 'Fonte do lead',
    enum: LeadSource,
    example: LeadSource.WEBSITE,
    default: LeadSource.WEBSITE,
  })
  @IsOptional()
  @IsEnum(LeadSource, { message: 'Fonte deve ser um valor válido' })
  source?: LeadSource;

  @ApiProperty({
    description: 'Temperatura do lead',
    enum: LeadTemperature,
    example: LeadTemperature.WARM,
    default: LeadTemperature.COLD,
  })
  @IsOptional()
  @IsEnum(LeadTemperature, { message: 'Temperatura deve ser um valor válido' })
  temperature?: LeadTemperature;

  @ApiProperty({
    description: 'Prioridade do lead',
    enum: LeadPriority,
    example: LeadPriority.HIGH,
    default: LeadPriority.MEDIUM,
  })
  @IsOptional()
  @IsEnum(LeadPriority, { message: 'Prioridade deve ser um valor válido' })
  priority?: LeadPriority;

  @ApiProperty({
    description: 'Score do lead (0-100)',
    example: 75,
    minimum: 0,
    maximum: 100,
    required: false,
  })
  @IsOptional()
  @IsNumber({}, { message: 'Score deve ser um número' })
  @Min(0, { message: 'Score deve ser pelo menos 0' })
  @Max(100, { message: 'Score deve ser no máximo 100' })
  score?: number;

  @ApiProperty({
    description: 'Notas sobre o lead',
    example: 'Lead interessado em produtos para diabetes',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Notas devem ser uma string' })
  notes?: string;

  @ApiProperty({
    description: 'Interesses do lead',
    example: ['medicamentos', 'suplementos'],
    required: false,
  })
  @IsOptional()
  @IsArray({ message: 'Interesses devem ser um array' })
  @IsString({ each: true, message: 'Cada interesse deve ser uma string' })
  interests?: string[];

  @ApiProperty({
    description: 'Valor estimado do lead',
    example: 1500.00,
    required: false,
  })
  @IsOptional()
  @IsNumber({}, { message: 'Valor estimado deve ser um número' })
  @Min(0, { message: 'Valor estimado deve ser positivo' })
  estimatedValue?: number;

  @ApiProperty({
    description: 'ID do usuário responsável',
    example: 'uuid-do-usuario',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Responsável deve ser uma string' })
  assignedTo?: string;

  @ApiProperty({
    description: 'Tags do lead',
    example: ['vip', 'farmacia-grande'],
    required: false,
  })
  @IsOptional()
  @IsArray({ message: 'Tags devem ser um array' })
  @IsString({ each: true, message: 'Cada tag deve ser uma string' })
  tags?: string[];

  @ApiProperty({
    description: 'ID da campanha de origem',
    example: 'uuid-da-campanha',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'ID da campanha deve ser uma string' })
  campaignId?: string;

  @ApiProperty({
    description: 'Parâmetros UTM',
    example: {
      utmSource: 'google',
      utmMedium: 'cpc',
      utmCampaign: 'farmacia-digital',
    },
    required: false,
  })
  @IsOptional()
  @IsObject({ message: 'Parâmetros UTM devem ser um objeto' })
  utmParams?: {
    utmSource?: string;
    utmMedium?: string;
    utmCampaign?: string;
    utmContent?: string;
    utmTerm?: string;
  };

  @ApiProperty({
    description: 'Campos customizados',
    example: { segmento: 'farmacia-popular', regiao: 'sudeste' },
    required: false,
  })
  @IsOptional()
  @IsObject({ message: 'Campos customizados devem ser um objeto' })
  customFields?: Record<string, any>;
}

