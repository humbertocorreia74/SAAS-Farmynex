import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';

export enum LeadStatus {
  NEW = 'new',
  CONTACTED = 'contacted',
  QUALIFIED = 'qualified',
  CONVERTED = 'converted',
  LOST = 'lost',
}

export enum LeadSource {
  WEBSITE = 'website',
  SOCIAL_MEDIA = 'social_media',
  EMAIL_CAMPAIGN = 'email_campaign',
  REFERRAL = 'referral',
  PHONE_CALL = 'phone_call',
  WALK_IN = 'walk_in',
  OTHER = 'other',
}

export enum LeadTemperature {
  HOT = 'hot',
  WARM = 'warm',
  COLD = 'cold',
}

export enum LeadPriority {
  HIGH = 'high',
  MEDIUM = 'medium',
  LOW = 'low',
}

@Entity('leads')
@Index(['email'], { unique: true })
@Index(['phone'])
@Index(['status'])
@Index(['temperature'])
@Index(['createdAt'])
export class Lead {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column({ unique: true })
  email: string;

  @Column({ nullable: true })
  phone: string;

  @Column({ nullable: true })
  company: string;

  @Column({ nullable: true })
  position: string;

  @Column({
    type: 'varchar',
    default: LeadStatus.NEW,
  })
  status: LeadStatus;

  @Column({
    type: 'varchar',
    default: LeadSource.WEBSITE,
  })
  source: LeadSource;

  @Column({
    type: 'varchar',
    default: LeadTemperature.COLD,
  })
  temperature: LeadTemperature;

  @Column({
    type: 'varchar',
    default: LeadPriority.MEDIUM,
  })
  priority: LeadPriority;

  @Column({ type: 'int', default: 0 })
  score: number; // Score de 0-100 baseado em IA

  @Column({ type: 'text', nullable: true })
  notes: string;

  @Column({ type: 'json', nullable: true })
  interests: string[]; // Produtos/categorias de interesse

  @Column({ type: 'json', nullable: true })
  suggestedProducts: string[]; // IDs dos produtos sugeridos pela IA

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  estimatedValue: number; // Valor estimado do lead

  @Column({ type: 'datetime', nullable: true })
  lastContactAt: Date;

  @Column({ type: 'datetime', nullable: true })
  nextFollowUpAt: Date;

  @Column({ nullable: true })
  assignedTo: string; // ID do usuário responsável

  @Column({ type: 'json', nullable: true })
  tags: string[];

  @Column({ type: 'json', nullable: true })
  customFields: Record<string, any>;

  // Campos para tracking de campanhas
  @Column({ nullable: true })
  campaignId: string;

  @Column({ nullable: true })
  utmSource: string;

  @Column({ nullable: true })
  utmMedium: string;

  @Column({ nullable: true })
  utmCampaign: string;

  @Column({ nullable: true })
  utmContent: string;

  @Column({ nullable: true })
  utmTerm: string;

  // Campos de atividade
  @Column({ type: 'int', default: 0 })
  emailsSent: number;

  @Column({ type: 'int', default: 0 })
  emailsOpened: number;

  @Column({ type: 'int', default: 0 })
  emailsClicked: number;

  @Column({ type: 'int', default: 0 })
  websiteVisits: number;

  @Column({ type: 'datetime', nullable: true })
  lastActivityAt: Date;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Getters calculados
  get fullName(): string {
    return `${this.firstName} ${this.lastName}`;
  }

  get engagementRate(): number {
    if (this.emailsSent === 0) return 0;
    return Math.round(((this.emailsOpened + this.emailsClicked) / this.emailsSent) * 100);
  }

  get isHot(): boolean {
    return this.temperature === LeadTemperature.HOT || this.score >= 80;
  }

  get isWarm(): boolean {
    return this.temperature === LeadTemperature.WARM || (this.score >= 50 && this.score < 80);
  }

  get isCold(): boolean {
    return this.temperature === LeadTemperature.COLD || this.score < 50;
  }

  get daysSinceCreated(): number {
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - this.createdAt.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  get daysSinceLastContact(): number {
    if (!this.lastContactAt) return this.daysSinceCreated;
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - this.lastContactAt.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }
}

