import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Request,
  Query,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';
import { UsersService } from './users.service';
import { UpdateUserDto } from './dto/update-user.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { UserStatus } from './entities/user.entity';

@ApiTags('users')
@Controller('users')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  @ApiOperation({ summary: 'Listar todos os usuários' })
  @ApiResponse({
    status: 200,
    description: 'Lista de usuários retornada com sucesso',
  })
  async findAll() {
    const users = await this.usersService.findAll();
    return {
      success: true,
      data: users,
      total: users.length,
    };
  }

  @Get('pharmacists')
  @ApiOperation({ summary: 'Listar farmacêuticos' })
  @ApiResponse({
    status: 200,
    description: 'Lista de farmacêuticos retornada com sucesso',
  })
  async getPharmacists() {
    const pharmacists = await this.usersService.getPharmacists();
    return {
      success: true,
      data: pharmacists,
      total: pharmacists.length,
    };
  }

  @Get('stats')
  @ApiOperation({ summary: 'Estatísticas de usuários' })
  @ApiResponse({
    status: 200,
    description: 'Estatísticas retornadas com sucesso',
  })
  async getUserStats() {
    const stats = await this.usersService.getUserStats();
    return {
      success: true,
      data: stats,
    };
  }

  @Get(':id')
  @ApiOperation({ summary: 'Buscar usuário por ID' })
  @ApiParam({ name: 'id', description: 'ID do usuário' })
  @ApiResponse({
    status: 200,
    description: 'Usuário encontrado',
  })
  @ApiResponse({
    status: 404,
    description: 'Usuário não encontrado',
  })
  async findOne(@Param('id') id: string) {
    const user = await this.usersService.findById(id);
    const { password: _, ...userWithoutPassword } = user;
    
    return {
      success: true,
      data: userWithoutPassword,
    };
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar usuário' })
  @ApiParam({ name: 'id', description: 'ID do usuário' })
  @ApiResponse({
    status: 200,
    description: 'Usuário atualizado com sucesso',
  })
  async update(
    @Param('id') id: string,
    @Body() updateUserDto: UpdateUserDto,
  ) {
    const user = await this.usersService.update(id, updateUserDto);
    const { password: _, ...userWithoutPassword } = user;
    
    return {
      success: true,
      message: 'Usuário atualizado com sucesso',
      data: userWithoutPassword,
    };
  }

  @Patch(':id/status')
  @ApiOperation({ summary: 'Atualizar status do usuário' })
  @ApiParam({ name: 'id', description: 'ID do usuário' })
  @ApiQuery({ name: 'status', enum: UserStatus })
  @ApiResponse({
    status: 200,
    description: 'Status atualizado com sucesso',
  })
  async updateStatus(
    @Param('id') id: string,
    @Query('status') status: UserStatus,
  ) {
    const user = await this.usersService.updateStatus(id, status);
    const { password: _, ...userWithoutPassword } = user;
    
    return {
      success: true,
      message: 'Status atualizado com sucesso',
      data: userWithoutPassword,
    };
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Remover usuário' })
  @ApiParam({ name: 'id', description: 'ID do usuário' })
  @ApiResponse({
    status: 200,
    description: 'Usuário removido com sucesso',
  })
  async remove(@Param('id') id: string) {
    await this.usersService.remove(id);
    
    return {
      success: true,
      message: 'Usuário removido com sucesso',
    };
  }
}

