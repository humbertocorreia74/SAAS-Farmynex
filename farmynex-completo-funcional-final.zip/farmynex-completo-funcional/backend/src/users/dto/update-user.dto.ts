import { ApiProperty } from '@nestjs/swagger';
import {
  IsEmail,
  IsString,
  IsEnum,
  IsOptional,
  IsPhoneNumber,
  IsArray,
  MinLength,
} from 'class-validator';
import { UserRole, UserStatus } from '../entities/user.entity';

export class UpdateUserDto {
  @ApiProperty({
    description: 'Email do usuário',
    example: 'farmaceutico@farmynex.com',
    required: false,
  })
  @IsOptional()
  @IsEmail({}, { message: 'Email deve ter um formato válido' })
  email?: string;

  @ApiProperty({
    description: 'Nova senha',
    example: 'novaSenha123',
    minLength: 6,
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Senha deve ser uma string' })
  @MinLength(6, { message: 'Senha deve ter pelo menos 6 caracteres' })
  password?: string;

  @ApiProperty({
    description: 'Primeiro nome',
    example: 'João',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Primeiro nome deve ser uma string' })
  firstName?: string;

  @ApiProperty({
    description: 'Último nome',
    example: 'Silva',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Último nome deve ser uma string' })
  lastName?: string;

  @ApiProperty({
    description: 'Telefone do usuário',
    example: '+5511999999999',
    required: false,
  })
  @IsOptional()
  @IsPhoneNumber('BR', { message: 'Telefone deve ter um formato válido' })
  phone?: string;

  @ApiProperty({
    description: 'Papel do usuário',
    enum: UserRole,
    example: UserRole.PHARMACIST,
    required: false,
  })
  @IsOptional()
  @IsEnum(UserRole, { message: 'Papel deve ser um valor válido' })
  role?: UserRole;

  @ApiProperty({
    description: 'Status do usuário',
    enum: UserStatus,
    example: UserStatus.ACTIVE,
    required: false,
  })
  @IsOptional()
  @IsEnum(UserStatus, { message: 'Status deve ser um valor válido' })
  status?: UserStatus;

  @ApiProperty({
    description: 'CRF do farmacêutico',
    example: 'CRF-SP 12345',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'CRF deve ser uma string' })
  crf?: string;

  @ApiProperty({
    description: 'URL do avatar',
    example: 'https://example.com/avatar.jpg',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Avatar deve ser uma string' })
  avatar?: string;

  @ApiProperty({
    description: 'Permissões do usuário',
    example: ['read_products', 'write_products'],
    required: false,
  })
  @IsOptional()
  @IsArray({ message: 'Permissões devem ser um array' })
  @IsString({ each: true, message: 'Cada permissão deve ser uma string' })
  permissions?: string[];
}

