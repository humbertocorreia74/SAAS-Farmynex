import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User, UserRole, UserStatus } from '../../users/entities/user.entity';
import { Product, ProductCategory, ProductStatus } from '../../products/entities/product.entity';
import { Lead, LeadTemperature, LeadStatus, LeadSource } from '../../leads/entities/lead.entity';
import { Campaign, CampaignType, CampaignStatus, CampaignObjective } from '../../campaigns/entities/campaign.entity';

@Injectable()
export class InitialDataSeed {
  constructor(
    @InjectRepository(User)
    private usersRepository: Repository<User>,
    @InjectRepository(Product)
    private productsRepository: Repository<Product>,
    @InjectRepository(Lead)
    private leadsRepository: Repository<Lead>,
    @InjectRepository(Campaign)
    private campaignsRepository: Repository<Campaign>,
  ) {}

  async run() {
    console.log('🌱 Iniciando seed de dados...');

    await this.seedUsers();
    await this.seedProducts();
    await this.seedLeads();
    await this.seedCampaigns();

    console.log('✅ Seed de dados concluído!');
  }

  private async seedUsers() {
    const existingUsers = await this.usersRepository.count();
    if (existingUsers > 0) {
      console.log('👥 Usuários já existem, pulando seed...');
      return;
    }

    const users = [
      {
        email: 'admin@farmynex.com',
        password: 'admin123',
        firstName: 'Admin',
        lastName: 'Farmynex',
        role: UserRole.ADMIN,
        status: UserStatus.ACTIVE,
        permissions: ['all'],
      },
      {
        email: 'farmaceutico@farmynex.com',
        password: 'farm123',
        firstName: 'Dr. João',
        lastName: 'Silva',
        role: UserRole.PHARMACIST,
        status: UserStatus.ACTIVE,
        crf: 'CRF-SP 12345',
        phone: '+5511999999999',
      },
      {
        email: 'gerente@farmynex.com',
        password: 'ger123',
        firstName: 'Maria',
        lastName: 'Santos',
        role: UserRole.MANAGER,
        status: UserStatus.ACTIVE,
        phone: '+5511888888888',
      },
      {
        email: 'funcionario@farmynex.com',
        password: 'func123',
        firstName: 'Pedro',
        lastName: 'Costa',
        role: UserRole.EMPLOYEE,
        status: UserStatus.ACTIVE,
        phone: '+5511777777777',
      },
    ];

    for (const userData of users) {
      const user = this.usersRepository.create(userData);
      await this.usersRepository.save(user);
    }

    console.log('👥 Usuários criados com sucesso!');
  }

  private async seedProducts() {
    const existingProducts = await this.productsRepository.count();
    if (existingProducts > 0) {
      console.log('💊 Produtos já existem, pulando seed...');
      return;
    }

    const products = [
      {
        name: 'Dipirona 500mg',
        description: 'Analgésico e antitérmico',
        barcode: '7891234567890',
        sku: 'DIP-500-001',
        category: ProductCategory.MEDICATION,
        brand: 'Medley',
        manufacturer: 'Sanofi',
        price: 15.99,
        costPrice: 8.50,
        stock: 100,
        minStock: 10,
        maxStock: 500,
        status: ProductStatus.ACTIVE,
        unit: 'comprimidos',
        expirationDate: new Date('2025-12-31'),
        batch: 'L001234',
        location: 'A1-B2-C3',
        requiresPrescription: false,
        isControlled: false,
        activeIngredient: 'Dipirona Sódica',
        dosage: '500mg',
        instructions: 'Tomar 1 comprimido a cada 6 horas',
        salesCount: 150,
        rating: 4.5,
        reviewsCount: 25,
      },
      {
        name: 'Paracetamol 750mg',
        description: 'Analgésico e antitérmico',
        barcode: '7891234567891',
        sku: 'PAR-750-001',
        category: ProductCategory.MEDICATION,
        brand: 'EMS',
        manufacturer: 'EMS Pharma',
        price: 12.50,
        costPrice: 6.25,
        stock: 80,
        minStock: 15,
        maxStock: 400,
        status: ProductStatus.ACTIVE,
        unit: 'comprimidos',
        expirationDate: new Date('2025-11-30'),
        batch: 'L001235',
        location: 'A1-B2-C4',
        requiresPrescription: false,
        isControlled: false,
        activeIngredient: 'Paracetamol',
        dosage: '750mg',
        instructions: 'Tomar 1 comprimido a cada 8 horas',
        salesCount: 200,
        rating: 4.7,
        reviewsCount: 40,
      },
      {
        name: 'Vitamina C 1g',
        description: 'Suplemento vitamínico',
        barcode: '7891234567892',
        sku: 'VIT-C-001',
        category: ProductCategory.SUPPLEMENTS,
        brand: 'Vitafor',
        manufacturer: 'Vitafor',
        price: 25.90,
        costPrice: 12.95,
        stock: 60,
        minStock: 20,
        maxStock: 300,
        status: ProductStatus.ACTIVE,
        unit: 'comprimidos',
        expirationDate: new Date('2026-06-30'),
        batch: 'L001236',
        location: 'B1-C2-D3',
        requiresPrescription: false,
        isControlled: false,
        activeIngredient: 'Ácido Ascórbico',
        dosage: '1g',
        instructions: 'Tomar 1 comprimido ao dia',
        salesCount: 75,
        rating: 4.3,
        reviewsCount: 15,
      },
      {
        name: 'Protetor Solar FPS 60',
        description: 'Proteção solar facial',
        barcode: '7891234567893',
        sku: 'PROT-60-001',
        category: ProductCategory.COSMETICS,
        brand: 'La Roche-Posay',
        manufacturer: 'L\'Oréal',
        price: 89.90,
        costPrice: 45.00,
        stock: 30,
        minStock: 5,
        maxStock: 100,
        status: ProductStatus.ACTIVE,
        unit: 'ml',
        expirationDate: new Date('2026-03-31'),
        batch: 'L001237',
        location: 'C1-D2-E3',
        requiresPrescription: false,
        isControlled: false,
        instructions: 'Aplicar 30 minutos antes da exposição solar',
        salesCount: 45,
        rating: 4.8,
        reviewsCount: 12,
      },
      {
        name: 'Shampoo Anticaspa',
        description: 'Shampoo para tratamento de caspa',
        barcode: '7891234567894',
        sku: 'SHA-AC-001',
        category: ProductCategory.HYGIENE,
        brand: 'Head & Shoulders',
        manufacturer: 'P&G',
        price: 18.50,
        costPrice: 9.25,
        stock: 5, // Estoque baixo para teste
        minStock: 10,
        maxStock: 200,
        status: ProductStatus.ACTIVE,
        unit: 'ml',
        expirationDate: new Date('2025-09-30'),
        batch: 'L001238',
        location: 'D1-E2-F3',
        requiresPrescription: false,
        isControlled: false,
        instructions: 'Aplicar no cabelo molhado, massagear e enxaguar',
        salesCount: 30,
        rating: 4.2,
        reviewsCount: 8,
      },
    ];

    for (const productData of products) {
      const product = this.productsRepository.create(productData);
      await this.productsRepository.save(product);
    }

    console.log('💊 Produtos criados com sucesso!');
  }

  private async seedLeads() {
    const existingLeads = await this.leadsRepository.count();
    if (existingLeads > 0) {
      console.log('🎯 Leads já existem, pulando seed...');
      return;
    }

    const leads = [
      {
        firstName: 'Carlos',
        lastName: 'Oliveira',
        email: 'carlos.oliveira@email.com',
        phone: '+5511999888777',
        company: 'Farmácia Central',
        position: 'Proprietário',
        source: LeadSource.WEBSITE,
        temperature: LeadTemperature.HOT,
        score: 85,
        status: LeadStatus.NEW,
        notes: 'Interessado em sistema completo para farmácia',
        interests: ['medicamentos', 'gestão de estoque'],
        estimatedValue: 2500.00,
        tags: ['farmacia-grande', 'urgente'],
      },
      {
        firstName: 'Ana',
        lastName: 'Costa',
        email: 'ana.costa@email.com',
        phone: '+5511888777666',
        company: 'Drogaria Saúde',
        position: 'Gerente',
        source: LeadSource.REFERRAL,
        temperature: LeadTemperature.WARM,
        score: 65,
        status: LeadStatus.CONTACTED,
        notes: 'Quer conhecer melhor as funcionalidades',
        interests: ['suplementos', 'cosméticos'],
        estimatedValue: 1800.00,
        tags: ['farmacia-media'],
        lastContactAt: new Date(),
      },
      {
        firstName: 'Roberto',
        lastName: 'Silva',
        email: 'roberto.silva@email.com',
        phone: '+5511777666555',
        company: 'Farmácia Popular',
        position: 'Farmacêutico',
        source: LeadSource.SOCIAL_MEDIA,
        temperature: LeadTemperature.COLD,
        score: 35,
        status: LeadStatus.NEW,
        notes: 'Ainda avaliando opções no mercado',
        interests: ['medicamentos'],
        estimatedValue: 800.00,
        tags: ['farmacia-pequena'],
      },
      {
        firstName: 'Mariana',
        lastName: 'Santos',
        email: 'mariana.santos@email.com',
        phone: '+5511666555444',
        company: 'Rede Farma+',
        position: 'Diretora',
        source: LeadSource.EMAIL_CAMPAIGN,
        temperature: LeadTemperature.HOT,
        score: 92,
        status: LeadStatus.QUALIFIED,
        notes: 'Pronta para fechar contrato, aguardando proposta',
        interests: ['medicamentos', 'suplementos', 'cosméticos', 'gestão'],
        estimatedValue: 5000.00,
        tags: ['rede-farmacias', 'vip', 'urgente'],
        lastContactAt: new Date(),
      },
      {
        firstName: 'José',
        lastName: 'Pereira',
        email: 'jose.pereira@email.com',
        company: 'Farmácia do Bairro',
        source: LeadSource.PHONE_CALL,
        temperature: LeadTemperature.WARM,
        score: 58,
        status: LeadStatus.NEW,
        notes: 'Ligou perguntando sobre preços',
        interests: ['medicamentos'],
        estimatedValue: 1200.00,
        tags: ['farmacia-pequena'],
      },
    ];

    for (const leadData of leads) {
      const lead = this.leadsRepository.create(leadData);
      await this.leadsRepository.save(lead);
    }

    console.log('🎯 Leads criados com sucesso!');
  }

  private async seedCampaigns() {
    const existingCampaigns = await this.campaignsRepository.count();
    if (existingCampaigns > 0) {
      console.log('📧 Campanhas já existem, pulando seed...');
      return;
    }

    const campaigns = [
      {
        name: 'Campanha Black Friday 2025',
        description: 'Campanha promocional para Black Friday',
        type: CampaignType.EMAIL,
        status: CampaignStatus.COMPLETED,
        objective: CampaignObjective.SALES,
        subject: '🔥 Black Friday: Até 70% OFF em medicamentos!',
        content: `
          <h1>Black Friday Farmynex!</h1>
          <p>Aproveite nossa super promoção de Black Friday com descontos de até 70% em medicamentos selecionados.</p>
          <ul>
            <li>Medicamentos genéricos com 50% OFF</li>
            <li>Suplementos vitamínicos com 40% OFF</li>
            <li>Produtos de higiene com 30% OFF</li>
          </ul>
          <p>Oferta válida até 30/11/2025 ou enquanto durarem os estoques.</p>
        `,
        ctaText: 'Aproveitar Oferta',
        ctaUrl: 'https://farmynex.com/black-friday',
        targetCount: 500,
        sentCount: 500,
        deliveredCount: 475,
        openedCount: 142,
        clickedCount: 38,
        convertedCount: 12,
        revenue: 1800.00,
        startedAt: new Date('2024-11-25'),
        completedAt: new Date('2024-11-30'),
        tags: ['black-friday', 'promocional'],
      },
      {
        name: 'Newsletter Dezembro',
        description: 'Newsletter mensal com novidades',
        type: CampaignType.EMAIL,
        status: CampaignStatus.RUNNING,
        objective: CampaignObjective.ENGAGEMENT,
        subject: '📰 Novidades Farmynex - Dezembro 2024',
        content: `
          <h1>Newsletter Farmynex</h1>
          <p>Confira as principais novidades do mês:</p>
          <ul>
            <li>Novos produtos em estoque</li>
            <li>Dicas de saúde para o verão</li>
            <li>Promoções especiais</li>
          </ul>
        `,
        ctaText: 'Ler Mais',
        ctaUrl: 'https://farmynex.com/newsletter',
        targetCount: 300,
        sentCount: 300,
        deliveredCount: 285,
        openedCount: 85,
        clickedCount: 22,
        convertedCount: 3,
        revenue: 450.00,
        startedAt: new Date(),
        tags: ['newsletter', 'mensal'],
      },
      {
        name: 'Campanha Natal 2024',
        description: 'Campanha especial de Natal',
        type: CampaignType.EMAIL,
        status: CampaignStatus.SCHEDULED,
        objective: CampaignObjective.SALES,
        subject: '🎄 Presentes de Natal para cuidar de quem você ama',
        content: `
          <h1>Natal Farmynex 2024</h1>
          <p>Neste Natal, cuide de quem você ama com produtos especiais da Farmynex.</p>
          <p>Kits especiais de presente:</p>
          <ul>
            <li>Kit Família Saudável</li>
            <li>Kit Beleza e Bem-estar</li>
            <li>Kit Cuidados Especiais</li>
          </ul>
        `,
        ctaText: 'Ver Kits de Natal',
        ctaUrl: 'https://farmynex.com/natal',
        targetCount: 400,
        scheduledAt: new Date('2024-12-20'),
        tags: ['natal', 'promocional', 'kits'],
      },
    ];

    for (const campaignData of campaigns) {
      const campaign = this.campaignsRepository.create(campaignData);
      await this.campaignsRepository.save(campaign);
    }

    console.log('📧 Campanhas criadas com sucesso!');
  }
}

