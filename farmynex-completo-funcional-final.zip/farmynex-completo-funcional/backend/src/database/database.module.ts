import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InitialDataSeed } from './seeds/initial-data.seed';
import { User } from '../users/entities/user.entity';
import { Product } from '../products/entities/product.entity';
import { Lead } from '../leads/entities/lead.entity';
import { Campaign } from '../campaigns/entities/campaign.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([User, Product, Lead, Campaign]),
  ],
  providers: [InitialDataSeed],
  exports: [InitialDataSeed],
})
export class DatabaseModule {}

