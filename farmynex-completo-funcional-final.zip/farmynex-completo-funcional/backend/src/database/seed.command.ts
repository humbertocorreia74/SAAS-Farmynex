import { NestFactory } from '@nestjs/core';
import { AppModule } from '../app.module';
import { InitialDataSeed } from './seeds/initial-data.seed';

async function runSeed() {
  const app = await NestFactory.createApplicationContext(AppModule);
  
  try {
    const seeder = app.get(InitialDataSeed);
    await seeder.run();
    console.log('🎉 Seed executado com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao executar seed:', error);
  } finally {
    await app.close();
  }
}

runSeed();

