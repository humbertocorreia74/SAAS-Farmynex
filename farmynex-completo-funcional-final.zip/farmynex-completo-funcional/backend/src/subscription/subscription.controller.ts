import { Controller, Get, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { SubscriptionService } from './subscription.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('subscription')
@Controller('subscription')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class SubscriptionController {
  constructor(private readonly subscriptionService: SubscriptionService) {}

  @Get()
  @ApiOperation({ summary: 'Obter assinaturas do usuário' })
  @ApiResponse({ status: 200, description: 'Assinaturas retornadas com sucesso' })
  async getUserSubscriptions(@Request() req) {
    try {
      const subscriptions = await this.subscriptionService.findByUserId(req.user.id);
      
      return {
        success: true,
        data: subscriptions,
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Get('active')
  @ApiOperation({ summary: 'Obter assinatura ativa do usuário' })
  @ApiResponse({ status: 200, description: 'Assinatura ativa retornada com sucesso' })
  async getActiveSubscription(@Request() req) {
    try {
      const subscription = await this.subscriptionService.findActiveByUserId(req.user.id);
      
      return {
        success: true,
        data: subscription,
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }
}

