# 🏥 Farmynex Backend API

Backend NestJS completo para sistema SaaS de farmácias com autenticação JWT, gestão de produtos, leads com IA, campanhas automatizadas e analytics avançados.

## 🚀 Funcionalidades

### 🔐 **Autenticação & Autorização**
- ✅ JWT Authentication com refresh tokens
- ✅ Registro e login de usuários
- ✅ Perfis de usuário (Admin, Farmacêutico, Funcionário)
- ✅ Guards de proteção de rotas
- ✅ Middleware de autorização

### 👥 **Gestão de Usuários**
- ✅ CRUD completo de usuários
- ✅ Listagem de farmacêuticos
- ✅ Estatísticas de usuários
- ✅ Controle de status (ativo/inativo)

### 💊 **Gestão de Produtos**
- ✅ CRUD completo de medicamentos
- ✅ Busca por código de barras
- ✅ Controle de estoque avançado
- ✅ Alertas de produtos vencidos
- ✅ Produtos com estoque baixo
- ✅ Categorização automática

### 🎯 **Sistema de Leads com IA**
- ✅ Classificação automática (Hot/Warm/Cold)
- ✅ Score de leads baseado em IA
- ✅ Produtos sugeridos automaticamente
- ✅ Follow-up automático
- ✅ Atribuição de leads
- ✅ Bulk operations

### 📧 **Campanhas de Marketing**
- ✅ Criação de campanhas email
- ✅ Geração de conteúdo com IA
- ✅ Agendamento de campanhas
- ✅ Métricas de performance
- ✅ A/B Testing
- ✅ Automação de regras

### 📊 **Analytics & Relatórios**
- ✅ Dashboard executivo
- ✅ Analytics de vendas
- ✅ Performance de leads
- ✅ Métricas de campanhas
- ✅ Relatórios de estoque
- ✅ KPIs principais

## 🛠️ Tecnologias

- **Framework**: NestJS 10.x
- **Database**: SQLite (dev) / PostgreSQL (prod)
- **ORM**: TypeORM
- **Authentication**: JWT + Passport
- **Documentation**: Swagger/OpenAPI
- **Validation**: Class Validator
- **Testing**: Jest

## 📦 Instalação

```bash
# Instalar dependências
npm install

# Configurar variáveis de ambiente
cp .env.example .env

# Executar migrations e seed
npm run seed

# Iniciar em desenvolvimento
npm run start:dev

# Build para produção
npm run build
npm run start:prod
```

## 🌐 Endpoints Principais

### Autenticação
```
POST /api/auth/login          # Login
POST /api/auth/register       # Registro
GET  /api/auth/profile        # Perfil do usuário
POST /api/auth/refresh        # Renovar token
```

### Usuários
```
GET    /api/users             # Listar usuários
GET    /api/users/pharmacists # Listar farmacêuticos
GET    /api/users/stats       # Estatísticas
PATCH  /api/users/:id/status  # Atualizar status
```

### Produtos
```
GET    /api/products          # Listar produtos
POST   /api/products          # Criar produto
GET    /api/products/barcode/:code # Buscar por código
GET    /api/products/low-stock     # Estoque baixo
GET    /api/products/expiring      # Próximos ao vencimento
PATCH  /api/products/:id/stock     # Atualizar estoque
```

### Leads
```
GET    /api/leads             # Listar leads
POST   /api/leads             # Criar lead
GET    /api/leads/by-temperature  # Por temperatura
GET    /api/leads/follow-up       # Precisam follow-up
PATCH  /api/leads/:id/score       # Atualizar score
PATCH  /api/leads/bulk/assign     # Atribuição em massa
```

### Campanhas
```
GET    /api/campaigns         # Listar campanhas
POST   /api/campaigns         # Criar campanha
POST   /api/campaigns/generate-ai # Gerar com IA
GET    /api/campaigns/stats       # Estatísticas
PATCH  /api/campaigns/:id/start   # Iniciar campanha
```

### Analytics
```
GET    /api/analytics/dashboard    # Dashboard geral
GET    /api/analytics/sales        # Analytics de vendas
GET    /api/analytics/leads        # Analytics de leads
GET    /api/analytics/campaigns    # Analytics de campanhas
GET    /api/analytics/kpis         # KPIs principais
```

## 📚 Documentação da API

Acesse a documentação interativa em:
```
http://localhost:3000/api/docs
```

## 🗄️ Estrutura do Banco

### Entidades Principais

#### User
- ID, nome, email, senha
- Role (admin, pharmacist, employee)
- Status (active, inactive)
- Último login, avatar

#### Product
- ID, nome, descrição, código de barras
- Categoria, marca, fabricante
- Preço, preço de custo
- Estoque atual, mínimo, máximo
- Data de validade, lote

#### Lead
- ID, nome, email, telefone
- Status (new, contacted, qualified, lost)
- Temperatura (hot, warm, cold)
- Score (0-100), produtos sugeridos
- Último contato, próximo follow-up

#### Campaign
- ID, nome, descrição, tipo
- Status (draft, scheduled, running, completed)
- Objetivo, público-alvo
- Métricas (enviados, abertos, cliques)
- Configuração A/B, regras de automação

## 🧪 Testes

```bash
# Executar todos os testes
npm run test

# Testes com coverage
npm run test:cov

# Testes e2e
npm run test:e2e

# Testes em modo watch
npm run test:watch
```

## 🚀 Deploy

### Desenvolvimento
```bash
npm run start:dev
# API: http://localhost:3000
# Docs: http://localhost:3000/api/docs
```

### Produção
```bash
# Build
npm run build

# Configurar PostgreSQL
export DB_HOST=your-postgres-host
export DB_USERNAME=your-username
export DB_PASSWORD=your-password

# Iniciar
npm run start:prod
```

## 🔧 Configuração

### Variáveis de Ambiente

```env
# Aplicação
NODE_ENV=development
PORT=3000

# JWT
JWT_SECRET=your-super-secret-key
JWT_EXPIRES_IN=1h
JWT_REFRESH_SECRET=your-refresh-secret
JWT_REFRESH_EXPIRES_IN=7d

# Database (PostgreSQL - Produção)
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=farmynex
DB_PASSWORD=farmynex123
DB_DATABASE=farmynex
DB_SSL=false

# APIs Externas (Opcional)
OPENAI_API_KEY=your-openai-key
SENDGRID_API_KEY=your-sendgrid-key
```

## 📈 Performance

- **Indexação**: Índices otimizados em campos de busca
- **Paginação**: Implementada em todas as listagens
- **Cache**: Redis para dados frequentes (opcional)
- **Validação**: Pipes de validação eficientes
- **Logs**: Sistema de logs estruturado

## 🔒 Segurança

- **Autenticação**: JWT com refresh tokens
- **Autorização**: Guards baseados em roles
- **Validação**: Sanitização de inputs
- **CORS**: Configurado para frontend
- **Rate Limiting**: Proteção contra spam
- **Helmet**: Headers de segurança

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT.

---

**Desenvolvido com ❤️ para revolucionar a gestão de farmácias!**

