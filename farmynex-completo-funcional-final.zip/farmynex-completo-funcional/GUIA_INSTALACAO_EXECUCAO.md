# Guia de Instalação e Execução - Farmynex v2.0

## Pré-requisitos

### Software Necessário

**Node.js e npm**
- Node.js versão 18.x ou superior
- npm versão 9.x ou superior
- Verificação: `node --version` e `npm --version`

**Git**
- Git versão 2.x ou superior
- Verificação: `git --version`

**Editor de Código (Recomendado)**
- Visual Studio Code com extensões TypeScript e React
- Ou qualquer editor de sua preferência

### Contas e Chaves de API

**Stripe (Obrigatório para pagamentos)**
1. Criar conta em https://stripe.com
2. Obter chaves de API (Publishable Key e Secret Key)
3. Configurar webhooks para eventos de assinatura

**Expo (Para desenvolvimento mobile)**
1. Criar conta em https://expo.dev
2. Instalar Expo CLI: `npm install -g @expo/cli`

## Instalação

### 1. Clonagem do Repositório

```bash
# Extrair o arquivo ZIP fornecido
unzip farmynex-integrated-complete-with-manual.zip
cd farmynex-integrated
```

### 2. Configuração do Backend

```bash
# Navegar para o diretório do backend
cd backend

# Instalar dependências
npm install

# Criar arquivo de configuração
cp .env.example .env
```

**Configurar variáveis de ambiente (.env):**

```env
# Configurações do Banco de Dados
DATABASE_TYPE=sqlite
DATABASE_PATH=./farmynex.db

# Configurações JWT
JWT_SECRET=seu_jwt_secret_super_seguro_aqui
JWT_EXPIRES_IN=24h

# Configurações Stripe
STRIPE_SECRET_KEY=sk_test_sua_chave_secreta_stripe
STRIPE_PUBLISHABLE_KEY=pk_test_sua_chave_publica_stripe
STRIPE_WEBHOOK_SECRET=whsec_seu_webhook_secret

# URLs da aplicação
FRONTEND_URL=http://localhost:5174
BACKEND_URL=http://localhost:3000

# Configurações SNGPC (opcional)
SNGPC_USUARIO=seu_usuario_sngpc
SNGPC_SENHA=sua_senha_sngpc

# Configurações da farmácia
FARMACIA_CNPJ=00000000000000
FARMACIA_NOME=Farmácia Exemplo
```

### 3. Configuração do Frontend

```bash
# Navegar para o diretório do frontend
cd ../farmynex-dashboard

# Instalar dependências
pnpm install
# ou npm install

# Criar arquivo de configuração
cp .env.example .env.local
```

**Configurar variáveis de ambiente (.env.local):**

```env
VITE_API_URL=http://localhost:3000/api
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_sua_chave_publica_stripe
```

### 4. Configuração do Mobile

```bash
# Navegar para o diretório do mobile
cd ../FarmynexMobile

# Instalar dependências
npm install

# Configurar arquivo de configuração
cp app.config.example.js app.config.js
```

**Configurar app.config.js:**

```javascript
export default {
  expo: {
    name: "Farmynex Mobile",
    slug: "farmynex-mobile",
    version: "1.0.0",
    orientation: "portrait",
    icon: "./assets/icon.png",
    userInterfaceStyle: "light",
    splash: {
      image: "./assets/splash.png",
      resizeMode: "contain",
      backgroundColor: "#ffffff"
    },
    extra: {
      apiUrl: "http://localhost:3000/api",
      // Para desenvolvimento em dispositivo físico, use o IP da máquina
      // apiUrl: "http://192.168.1.100:3000/api",
    },
    plugins: [
      "expo-camera",
      "expo-notifications"
    ]
  }
};
```

## Execução

### 1. Iniciar o Backend

```bash
cd backend

# Desenvolvimento (com hot reload)
npm run start:dev

# Produção
npm run build
npm run start:prod
```

**Verificação:**
- API disponível em: http://localhost:3000
- Documentação Swagger: http://localhost:3000/api/docs

### 2. Iniciar o Frontend

```bash
cd farmynex-dashboard

# Desenvolvimento
pnpm run dev
# ou npm run dev

# Build para produção
pnpm run build
pnpm run preview
```

**Verificação:**
- Dashboard disponível em: http://localhost:5174

### 3. Iniciar o Mobile

```bash
cd FarmynexMobile

# Desenvolvimento
npx expo start

# Para dispositivo físico
npx expo start --tunnel

# Para emulador Android
npx expo start --android

# Para simulador iOS (apenas macOS)
npx expo start --ios
```

**Verificação:**
- Escaneie o QR code com o app Expo Go
- Ou use emulador/simulador

## Configuração de Desenvolvimento

### Banco de Dados

O sistema usa SQLite por padrão para desenvolvimento. O banco será criado automaticamente na primeira execução.

**Comandos úteis:**

```bash
# Gerar migration
npm run typeorm:migration:generate -- -n NomeDaMigration

# Executar migrations
npm run typeorm:migration:run

# Reverter migration
npm run typeorm:migration:revert
```

### Stripe Webhooks (Desenvolvimento)

Para testar webhooks localmente, use o Stripe CLI:

```bash
# Instalar Stripe CLI
# https://stripe.com/docs/stripe-cli

# Login na conta Stripe
stripe login

# Encaminhar webhooks para desenvolvimento local
stripe listen --forward-to localhost:3000/api/stripe/webhook
```

### Configuração de Proxy (Opcional)

Para desenvolvimento mobile em dispositivo físico, configure um proxy ou use ngrok:

```bash
# Instalar ngrok
npm install -g ngrok

# Expor backend local
ngrok http 3000

# Atualizar app.config.js com a URL do ngrok
```

## Testes

### Backend

```bash
cd backend

# Testes unitários
npm run test

# Testes com coverage
npm run test:cov

# Testes e2e
npm run test:e2e
```

### Frontend

```bash
cd farmynex-dashboard

# Testes unitários
pnpm run test

# Testes com interface
pnpm run test:ui
```

### Mobile

```bash
cd FarmynexMobile

# Testes unitários
npm run test

# Testes no dispositivo
npx expo test
```

## Deployment

### Backend (Produção)

```bash
# Build da aplicação
npm run build

# Configurar variáveis de ambiente de produção
# Usar PostgreSQL ou MySQL em produção

# Executar migrations
npm run typeorm:migration:run

# Iniciar aplicação
npm run start:prod
```

### Frontend (Produção)

```bash
# Build para produção
pnpm run build

# Os arquivos estarão em ./dist
# Servir com nginx, Apache ou CDN
```

### Mobile (Produção)

```bash
# Build para Android
npx eas build --platform android

# Build para iOS
npx eas build --platform ios

# Publicar na loja
npx eas submit
```

## Solução de Problemas

### Problemas Comuns

**Erro de conexão com banco de dados**
- Verificar se o arquivo .env está configurado corretamente
- Verificar permissões de escrita no diretório

**Erro de CORS no frontend**
- Verificar se FRONTEND_URL está configurado no backend
- Verificar se o backend está rodando na porta correta

**Erro de certificado SSL em desenvolvimento**
- Usar HTTP em desenvolvimento
- Configurar certificados SSL se necessário

**App mobile não conecta com backend**
- Verificar se o IP está correto no app.config.js
- Verificar se o firewall permite conexões na porta 3000
- Usar ngrok ou túnel para testes

### Logs e Debug

**Backend:**
```bash
# Logs detalhados
DEBUG=* npm run start:dev

# Logs específicos
DEBUG=farmynex:* npm run start:dev
```

**Frontend:**
- Abrir DevTools do navegador (F12)
- Verificar aba Console e Network

**Mobile:**
- Usar Flipper para debug avançado
- Logs disponíveis no terminal do Expo

### Performance

**Backend:**
- Monitorar uso de CPU e memória
- Verificar queries lentas no banco
- Usar cache para consultas frequentes

**Frontend:**
- Usar React DevTools Profiler
- Verificar bundle size com `pnpm run analyze`
- Otimizar imagens e assets

**Mobile:**
- Usar Expo DevTools
- Monitorar performance com Flipper
- Otimizar renderizações desnecessárias

## Suporte e Documentação

### Documentação Adicional

- **API Documentation**: http://localhost:3000/api/docs
- **React Documentation**: https://react.dev
- **NestJS Documentation**: https://nestjs.com
- **Expo Documentation**: https://docs.expo.dev

### Contato e Suporte

Para dúvidas técnicas ou suporte:
- Consulte a documentação técnica completa
- Verifique os logs de erro
- Consulte as issues conhecidas no repositório

### Atualizações

Para manter o sistema atualizado:

```bash
# Verificar atualizações de dependências
npm outdated

# Atualizar dependências
npm update

# Verificar vulnerabilidades
npm audit
npm audit fix
```

---

*Este guia será atualizado conforme novas versões e funcionalidades são lançadas.*

